define(['app', 'angularAMD'], function (app, CertificationModule) {

    CertificationModule.controller('CertificationController', 
		function ($scope, $location, $state, CertificationService) {
                    
	    	$scope.searchfilterby = function() {
	    	    var filterval = $scope.selectedUser1;
	    	    if (filterval != 'all' && filterval != '') {
	    	        $(".mail-list-pane").find(".mail-list-item").each(function() {
	    	            if ($(this).hasClass("mailstatus-"+filterval)) {
	    	                $(this).show();
	    	            } else {
	    	                $(this).hide();
	    	            }
	    	        });
	    	    } else {
	    	        $(".mail-list-pane").find(".mail-list-item").show();
	    	    }
	    	};
	
	    	$scope.accordion_dialog_toggle = function(event)
	    	{
	    	    console.log($("body").find(".app-table-in").attr("id"));
	    	   
	    	    $(".app-table-in").find(".accordion-container").removeClass("SelectedAccordion");
	    	    $(event.target).parents(".accordion-container").addClass("SelectedAccordion");
	    	    var accordion = $(".app-table-in").find(".SelectedAccordion");
	    	    var accordionContent = accordion.next('.accordion-content');
	    	    var accordionToggleIcon = accordion.children('.toggle-icon');
	    	    var accordionToggleInfo = accordion.children('.toggle-info');
	
	    	    $(".app-table-in").find(".accordion-container").find(".accordion-toggle").removeClass("open");
	
	    	    $(".app-table-in").find(".accordion-container").find(".accordion-content").addClass("display-none");
	
	    	    $(".app-table-in").find(".accordion-container").find(".toggle-icon").html("<i class='icon-plus-sign'></i>");
	    	    $(".app-table-in").find(".accordion-container").find(".toggle-info").html("<span class='info-text'>Show Details</span>");
	    	    // toggle accordion link open class
	    	    // toggle accordion content
	    	    if($(".app-table-in").find(".SelectedAccordion").find(".accordion-content").hasClass("display-block"))
	    	    {
	    	        $(".app-table-in").find(".SelectedAccordion").find(".toggle-icon").html("<i class='icon-plus-sign'></i>");
	    	        $(".app-table-in").find(".SelectedAccordion").find(".accordion-content").removeClass("display-block");
	    	        $(".app-table-in").find(".SelectedAccordion").find(".accordion-content").addClass("display-none");    
	    	    }        
	    	    else
	    	    {
	    	        $(".app-table-in").find(".SelectedAccordion").find(".toggle-icon").html("<i class='icon-minus-sign'></i>");
	    	        $(".app-table-in").find(".SelectedAccordion").find(".accordion-content").removeClass("display-none");
	    	        $(".app-table-in").find(".SelectedAccordion").find(".accordion-content").addClass("display-block");    
	    	    }
	    		
	    		if($("body").hasClass("certifications"))
	    		{
	    	        if ($(".content-wrapper").find(".certifications").find(".vertical-topalign").hasClass("hide")) {
	    	    		$(".content-wrapper").find(".certifications").find(".access-info-table").removeClass("hide");
	    	    		$(".content-wrapper").find(".certifications").find(".access-not-found").addClass("hide");
	    	        }
	    	        else {
	    	            return false;
	    	        }
	    		}
	    	    
	    	};
	
	    	$scope.complete_access = function(event)
	    	{
	    		//$location.url("/");
	    		$state.go('inbox.list');
	    		setTimeout(function(){
	    			$("#alert-access-success").removeClass("hide");
	    			setTimeout(function(){
	    				$("#alert-access-success").addClass("hide");
	    				$("#apps").find(".mail-list-expanded").hide();
	    			},2500);
	    		},500);
	    	}
	
	    	$scope.certifyAllAccess = function(event)
	    	{
	    		$('.radio-switch.certify').prop('checked',true);
	    		$('.radio-switch.revoke').prop('checked',false);
	    		
	    		//$(".content-wrapper").find(".certifications").find(".optionC-text").addClass("active");
	    		$(".content-wrapper").find(".certifications").find(".submit_button").removeAttr("disabled","disabled");
	    	}
	    	
	    	$scope.revokeAllAccess = function(event)
	    	{
	    		$('.radio-switch.certify').prop('checked',false);
	    		$('.radio-switch.revoke').prop('checked',true);
	    		$(".content-wrapper").find(".certifications").find(".submit_button").attr("disabled","disabled");
	    	}
	    	
	    	$scope.certifySingleAccess = function(event)
	    	{
	    		$(".content-wrapper").find(".certifications").find(".submit_button").removeAttr("disabled");
	    	}
	    	
	    	$scope.revokeSingleAccess = function(event)
	    	{
	    		$(".content-wrapper").find(".certifications").find(".submit_button").attr("disabled","disabled");
	    	}
	
	    	$scope.editAccess = function(event)
	    	{
	    		$(".content-wrapper").find(".certifications").find(".submit_button").attr("disabled","disabled");
	    	}
	    	
	    	$scope.showalertsuccess = function(event)
	    	{
	    		$(".content-wrapper").find(".certifications").find(".access-info-table").addClass("hide");
	    		$(".content-wrapper").find(".certifications").find(".vertical-topalign.submit").removeClass("hide");
	    	    $(".content-wrapper").find(".certifications").find(".accordion .status-icon").attr("src","assets/images/icon_status-full.png");
	    		setTimeout(function(){
	    			$(".content-wrapper").find(".certifications").find(".vertical-topalign.submit").addClass("hide");
	    			$(".content-wrapper").find(".certifications").find(".access-not-found").removeClass("hide");
	    			$(".content-wrapper").find(".certifications").find(".dlt-row").removeClass("active");
	
	    		},2800);
	    		$(".content-wrapper").find(".certifications").find(".complete_button").removeAttr("disabled","disabled");
	    	}
	    	
	    	$scope.savecertification = function(event)
	    	{
	    		$(".content-wrapper").find(".certifications").find(".access-info-table").addClass("hide");
	    		$(".content-wrapper").find(".certifications").find(".vertical-topalign.save").removeClass("hide");
	    	    //$(".content-wrapper").find(".certifications").find(".accordion .status-icon").attr("src","assets/images/icon_status-full.png");
	    		setTimeout(function(){
	    			$(".content-wrapper").find(".certifications").find(".vertical-topalign.save").addClass("hide");
	    			$(".content-wrapper").find(".certifications").find(".access-not-found").removeClass("hide");
	    			$(".content-wrapper").find(".certifications").find(".dlt-row").removeClass("active");
	
	    		},2800);
	    		//$(".content-wrapper").find(".certifications").find(".complete_button").removeAttr("disabled","disabled");
	    	}
	    	
	    	$scope.showcertification_table = function(event,app) {
				$scope.app = app;
	    	    if ($(".content-wrapper").find(".certifications").find(".vertical-topalign").hasClass("hide")) {
	    	        $(".certifications").find(".dlt-row").removeClass("active");
	    	        $(event.target).parent().addClass("active");
	    	        $(".content-wrapper").find(".certifications").find(".access-info-table").removeClass("hide");
	    	        $(".content-wrapper").find(".certifications").find(".access-not-found").addClass("hide");
	    	    } else {
	    	        return false;
	    	    }
	    	};
	
	    	$scope.showapp_table = function(event) {
	    	    $("body.my-access").find(".dlt-row").removeClass("active");
	    	    $(event.target).parent().addClass("active");
	    	    $(".access-not-found").addClass("hide");
	    	    $(".access-info-table").removeClass("hide");
	    	};
	
	    	$scope.readmoretext = function() {
	    	    $(".remaining_text").show();
	    	    $(".read_more").hide();
	    	    $(".less_more").show();
	    	};
	
	    	$scope.lessmoretext = function() {
	    	    $(".remaining_text").hide();
	    	    $(".read_more").show();
	    	    $(".less_more").hide();
	    	};
	
	    	$scope.statusby = function() {
	    	    var statusval = $scope.selectedUser2;
	    	    if (statusval != '') {
	    	        $(".mail-list-pane").find(".mail-list-item").each(function() {
	    	            console.log($(this));
	    	            if ($(this).hasClass("mailstatus-"+statusval)) {
	    	                $(this).show();
	    	            } else {
	    	                $(this).hide();
	    	            }
	    	        });
	    	    } else {
	    	        $(".mail-list-pane").find(".mail-list-item").show();
	    	    }
	    	};
                   
        });
});