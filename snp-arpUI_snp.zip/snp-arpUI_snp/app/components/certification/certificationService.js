define(['app','angularAMD'], function(app, CertificationModule){
    
	CertificationModule.service('CertificationService', 
		function(){
            var service = {};
            return service;
        });
});