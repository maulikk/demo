define(['app','angularAMD'], function(app, UserModule){
    
	UserModule.factory("Users", ["Restangular", function(Restangular) 
	{
		var service = Restangular.service("requests");  
		service.validateData = function(request) {
		   //process / validate data
		}
		return service;
	}]);
	
	UserModule.service("UserService", ["Restangular", function(Restangular) 
	{
		var service = {};
		
		var getUserDetails = function (userId) {
			var user = Restangular.one('users',userId).get();
			return user;
		};
		
		var getGroupDetails = function (groupId) {
			var groupDetails = Restangular.one('groups',groupId).get();
			//var groupDetails = Restangular.one('groups',groupId).get({},{OAM_REMOTE_USER:groupId});
			return groupDetails;
		};
		
		return {
			getUserDetails : getUserDetails,
			getGroupDetails : getGroupDetails,
			service: service
		};
        
	}]);
});
