define(['app','angularAMD'], function(app, userModule){
    userModule
        .controller('UserController', function($scope, $rootScope, UserService, _currentUser){

        	/* Get Profile of logged in user */
        	$scope.getUserProfile = function (userId) {
			
				UserService.getUserDetails(userId).then( function(req)
				{
					$scope.profile = req.data.plain();
					
				},function(response) {
					console.log("Error with status code", response.status);
				});
			};
			
			$scope.getUserProfile(_currentUser['userId']);
			
		});
});
