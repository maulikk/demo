define(['app', 'angularAMD'], function (app, RequestsModule) {

    RequestsModule.factory("Requests", ["Restangular", function (Restangular)
        {
            var service = Restangular.service("requests");
            service.validateData = function (request) {
                //process / validate data
            }
            return service;

        }]);

    RequestsModule.service('RequestsService', function () {
        var service = {};
        return service;
    });
    
    /* Service for Request Details controller */
    RequestsModule.service('RequestDetailsService', function ($rootScope, $state, $mdDialog, $filter, VIEW_PATH, REQUEST_STATUS, AllReferenceDataService, Restangular, INCLUDE, ROLE_REQUESTABLE, _currentUser) {
        var service = {};
        var self = this;
        
        // Sort JSON Array service
        service.sortJSONArray = function (arr, prop, asc) {
            if (!arr || !arr.length) {
                return arr;
            }
			
            /*arr = arr.sort(function(a, b) {
             if (asc) {
             return (a[prop] > b[prop]);
             } else { 
             return (b[prop] > a[prop]);
             }
             });*/
            arr = arr.sort(function (a, b) {
                if (asc) {
                    return (a[prop] > b[prop] ? 1 : -1);
                } else {
                    return (a[prop] == undefined || b[prop] > a[prop] ? 1 : -1);
                }
            });
			
            return arr;
        }
        
        // Service to get Users to ask questions to during approval
        service.getQuestionUsers = function ($scope) {
            var questionUsers = [];

            var assignedArray = service.sortJSONArray($scope.request.assignedTo, 'assignedOn', true);

            /* Seperate discussion array to change sequence */
            var assignedToArray = angular.copy(assignedArray);

            var owner = $scope.request.Operations[0].owner;
            questionUsers.push({"value": owner.value, "display": owner.display});

            angular.forEach(assignedToArray, function (assignedUser, assignIndex) {
                //console.log('assignedUser',assignedUser);
                if (assignedUser.category.toLowerCase() == 'user' && (INCLUDE.QUESTION_STATUS.indexOf(assignedUser.status) !== -1)) {
                    questionUsers.push({"value": assignedUser.value, "display": assignedUser.display});
                }
            });

            return questionUsers;
        }

        /* Get Discussions of a request */
        service.getDiscussion = function ($scope) {
            var discussions = [];

            //var approverArray = service.sortJSONArray($scope.request.assignedTo,'assignedOn',true);
            var approverArray = $scope.request.assignedTo || [];
            if (approverArray.length) {
                approverArray = service.sortJSONArray(approverArray, 'assignedOn', true);
            }

            /* Seperate discussion array to change sequence */
            var discussionApproverArray = angular.copy(approverArray);
            discussionApproverArray.reverse();

            angular.forEach(discussionApproverArray, function (approver, approverIndex) {
                if (angular.isDefined(approver.comments)) {
                    var approverCommentsArray = approver.comments;
                    angular.forEach(approverCommentsArray, function (comment, commentIndex) {
                        discussions.push(comment);
                    });
                }
            });

            /*var task = Restangular.one("tasks", approver['task-value']).get();
             
             task.then(function(res) {
             var comments = res.data.comments;
             angular.forEach(comments, function(comment,commentIndex){
             discussions.push(comment);
             });
             },function(response) {
             console.log("Error with status code ", response.status);
             });*/

            return discussions;
        };

        /* Process request for Approve & Reject */
        service.processRequest = function ($scope, type) {
        	var actionComment = {};

            if (type != 'cancel') {
                // Create request object
                var task = Restangular.one("tasks", $scope.approver['task-value']);

                // Post Nomination form data before Approval
                if (type == 'approve' && $scope.processNominationForm === true) {
                    var attachment = {
                        'time': $scope.nomination.time,
                        'rights': $scope.nomination.rights,
                        'yearsOfExperience': $scope.nomination.yearsOfExperience,
                        'explanation': $scope.nomination.explanation,
                        'nominationClass': $scope.nomination.nominationClass,
                        'nominationSubclass': $scope.nomination.nominationSubclass,
                        'completionAdvTests': $scope.nomination.completionAdvTests,
                        'completedAnalystRoleTraining': $scope.nomination.completedAnalystRoleTraining,
                        'advanceTests': $scope.nomination.advanceTests
                    };
                    var postData = {
                        "action": "attach",
                        "parameters": {
                            "attachment": angular.toJson(attachment)
                        }
                    };
                    //console.log('postData',postData);

                    //Restangular.all("tasks/" + $scope.approver['task-value'] + "/.action").post(postData).then(
                    task.customPOST(postData, ".action", {}, {}).then(
                        function (res) {
                            $scope.proceedtoApproval = true;
                        }, function (error) {
                        	console.log("Error with status code", error.status);
                        });
                } else {
                    $scope.proceedtoApproval = true;
                }

                $scope.$watch('proceedtoApproval', function (newvalue, oldvalue) {
                    if (newvalue === true) {
                        // Proceed to Approval
                        actionComment = {
                            "action": type,
                            "message": $scope.comment
                        };

                        task.customPOST(actionComment, ".action", {}, {}).then(function () {

                            //$state.go('inbox.list', {}, {reload: true});
                            $rootScope.changeClass('', "notfolded");

                            // Show Message
                            if (type == 'approve') {
                            	$state.go('inbox.list', {'alertType':'approve_success'}, {reload: true});
                                /*setTimeout(function () {
                                    $("#alert-approve-success").removeClass("hide");
                                    setTimeout(function () {
                                        $("#alert-approve-success").addClass("hide");
                                    }, 2000);
                                }, 2500);*/
                            } else if (type == 'reject') {
                            	$state.go('inbox.list', {'alertType':'reject_success'}, {reload: true});
                                /*setTimeout(function () {
                                    $("#alert-reject-success").removeClass("hide");
                                    setTimeout(function () {
                                        $("#alert-reject-success").addClass("hide");
                                    }, 2000);
                                }, 2500);*/
                            } else if (type == 'complete') {
                            	$state.go('inbox.list', {'alertType':'complete_success'}, {reload: true});
                            }

                        }, function () {
                            console.log("There was an error approving!");
                        });
                    }
                });

            }// EO if(type!='cancel')
            
            // Cancel request API logic
            if (type == 'cancel') {

                //Restangular.one("bulk", $scope.requestId).remove().then(function () {
                Restangular.one('bulk', $scope.requestId).get({'method':"DELETE"}).then(function () {

                    $state.go('inbox.list', {'alertType':'cancel_success'}, {reload: true});
                    $rootScope.changeClass('', "notfolded");

                    // Show Message
                    /*setTimeout(function () {
                        $("#alert-cancel-success").removeClass("hide");
                        setTimeout(function () {
                            $("#alert-cancel-success").addClass("hide");
                        }, 2000);
                    }, 2500);*/

                }, function () {
                    console.log("There was an error Deleting!");
                });

            } // EO if(type=='cancel')

        } // EO service.processRequest()
       
        self.setDisplayFormat = function (objFieldElement, tempObjStoreDetails) {
            //Arrange the display as in the meta-data//
            var arrStoreSequence = {};
            angular.forEach(objFieldElement.templateOptions.fields[0].fieldGroup, function (element) {
                arrStoreSequence[element.templateOptions.label] = "";
            })
            var arrTemp = {};
            angular.forEach(arrStoreSequence, function (innerElement, innerKey) {
                arrTemp[innerKey] = tempObjStoreDetails[innerKey];
            })
            return arrTemp;
            //Arrange the display as in the meta-data//
        }
        
        // Function to get the form display data //
        var displayForm = {};
        service.getDisplayForm = function (formFileds, requestedAccess, mode, isRecursive, globalReferenceData, profile) {
            if (!isRecursive || isRecursive !== true) {
                displayForm = {};
            }
            var excludeFormTypes = ["formdescription", "forminformation", "helper"];
            var excludeFormFields = ["Justification"];

            angular.forEach(formFileds, function (formFiled, elementIndex) {
                if (excludeFormTypes.indexOf(formFiled.type) !== -1) {
                    return true;
                }
                if (excludeFormFields.indexOf(formFiled.name) !== -1) {
                    return true;
                }

                var refDataChildren = [];
                if (formFiled.key && formFiled.data && (formFiled.data.refData || formFiled.data.refDataHidden)) {
                    //console.log(formFiled.type, formFiled.key);
                    var refData = (formFiled.data.refDataHidden) ? formFiled.data.refDataHidden : formFiled.data.refData;
                    if (refData == 'dynamic') {

                        //refData = "snp.refData.roles." + ROLE_REQUESTABLE[policyCode] + "Roles.data";
                        refData = "snp.refData.roles.analyticalRoles.data"; // Business Rule: Analytical Roles form will be available ONLY to analytical Policy Role
                    }
                    if (globalReferenceData && globalReferenceData[refData]) {
                        var refDataChildren = globalReferenceData[refData].children;
                    }
                }

                // Switch for various formly metadata JSON form fields to split display logic
                switch (formFiled.type) {
                    case "comma":
                        break;

                    case "multicheckbox":
                    case "multiselect":
                        var pushArray = {
                            type: formFiled.type,
                            key: formFiled.templateOptions.key,
                            details: []
                        };
                        /* If mode=access to display user access details screen like my access/manage user/user access */
                        if (mode != undefined && mode == 'access') {	//for access
                            angular.forEach(requestedAccess[formFiled.key], function (accessValues, accessIndex) {
                                //console.log('accessValues: ',accessValues);
                                var fieldValue = accessValues[formFiled.templateOptions.key].display;
                                if (refDataChildren) {
                                    var dispSingleValue = accessValues[formFiled.templateOptions.key].value;
                                    var fieldDetails = AllReferenceDataService.processHierarchialData(dispSingleValue, refDataChildren);
                                    fieldValue = fieldDetails.singleValueLabel;
                                }

                                //if (fieldValue) {
                                pushArray.details.push(fieldValue);
                                //}
                            });
                            if (pushArray.details.length) {
                            	pushArray.details.sort();
                            }
                            displayForm[formFiled.name] = pushArray;
                        } else {	//for request
                            if (requestedAccess.Operations) {
                                var valueObj = {};
                                angular.forEach(requestedAccess.Operations, function (accessValues, accessIndex) {
                                    //console.log('MSaccessValues: ',accessValues.values);
                                    angular.forEach(accessValues.values, function (values, valuesIndex) {
                                        if (values[formFiled.templateOptions.key]) {

                                            var fieldValue = values[formFiled.templateOptions.key].display;
                                            if (refDataChildren) {
                                                var dispSingleValue = values[formFiled.templateOptions.key].value;
                                                var fieldDetails = AllReferenceDataService.processHierarchialData(dispSingleValue, refDataChildren);
                                                fieldValue = fieldDetails.singleValueLabel;
                                            }

                                            valueObj = {
                                                "op": accessValues.op,
                                                "display": fieldValue
                                            }
                                            pushArray.details.push(valueObj);
                                        }
                                    });
                                });
                                if (pushArray.details.length) {
                                	pushArray.details = angular.sortByKey(pushArray.details, 'display');
                                }
                                displayForm[formFiled.name] = pushArray;
                            }
                        }
                        break;

                    case "customaddselect":
                        var pushArray = {
                            type: formFiled.type,
                            key: formFiled.key,
                            details: []
                        };
                        /* If mode=access to display user access details screen like my access/manage user/user access */
                        if (mode != undefined && mode == 'access') {	//for access
                            angular.forEach(requestedAccess[formFiled.key], function (accessValues, accessIndex) {
                                //console.log('accessValues: ',accessValues);
                                if (accessValues.value) {
                                    delete accessValues.value;
                                }
                                pushArray.details.push(accessValues);
                            });
                        } else {	//for request
                            var valueObj = {};
                            angular.forEach(requestedAccess.Operations, function (accessValues, accessIndex) {
                                //console.log('CASaccessValues: ',accessValues.values);
                                angular.forEach(accessValues.values, function (values, valuesIndex) {
                                    if (values.value) {
                                        delete values.value;
                                    }

                                    //pushArray.details.push(values);
                                    valueObj = {
                                        "op": accessValues.op,
                                        "display": values
                                    }
                                    pushArray.details.push(valueObj);
                                });
                            });
                        }
                        displayForm[formFiled.name] = pushArray;
                        break;
                        
                    case "customaddtextbox":
                        var pushArray = {
                            type: formFiled.type,
                            key: formFiled.key,
                            details: []
                        };
                        /* If mode=access to display user access details screen like my access/manage user/user access */
                        if (mode != undefined && mode == 'access') {	//for access
                            angular.forEach(requestedAccess[formFiled.key], function (accessValues, accessIndex) {
                                //console.log('accessValues: ',accessValues);
                                if (accessValues.value) {
                                    delete accessValues.value;
                                }
                                pushArray.details.push(accessValues);
                            });
                        } else {	//for request
                            var valueObj = {};
                            angular.forEach(requestedAccess.Operations, function (accessValues, accessIndex) {
                                //console.log('CASaccessValues: ',accessValues);
                                
                                if (accessValues.path && accessValues.path==formFiled.key) {
                                	angular.forEach(accessValues.values, function (values, valuesIndex) {
                                        if (values.value) {
                                            delete values.value;
                                        }
                                        valueObj = {
                                            "op": accessValues.op,
                                            "display": values
                                        }
                                        pushArray.details.push(valueObj);
                                    });
                                }
                            });
                        }
                        displayForm[formFiled.name] = pushArray;
                        break;

                    case "treedropdownselect":
                        var pushArray = {
                            type: formFiled.type,
                            key: formFiled.key,
                            details: []
                        };

                        /* If mode=access to display user access details screen like my access/manage user/user access */
                        var metadataFieldGroup = formFiled.templateOptions.fields[0].fieldGroup;
                        if (mode != undefined && mode == 'access') {	//for access
                            angular.forEach(requestedAccess[formFiled.key], function (accessValues, accessIndex) {
                                //console.log('treedropdownselect accessValues: ',accessValues);
                                if (accessValues.value) {
                                    delete accessValues.value;
                                }

                                var accessValuesProcessed = {};
                                for (var accessKey in accessValues) {
                                    var accessName = accessKey;
                                    var fieldValue = accessValues[accessKey].display;
                                    if ($filter('filter')(metadataFieldGroup, {"key": accessKey}, true).length) {
                                        var foundField = $filter('filter')(metadataFieldGroup, {"key": accessKey}, true)[0];
                                        accessName = foundField.templateOptions.label;
                                        if (foundField.data && foundField.data.refData) {
                                            var accessRefData = foundField.data.refData;
                                            if (globalReferenceData[accessRefData] && globalReferenceData[accessRefData].children) {
                                                refDataChildren = globalReferenceData[accessRefData].children;
                                                var dispSingleValue = accessValues[accessKey].value;
                                                //console.log('dispSingleValue',dispSingleValue);
                                                //console.log('refDataChildren',refDataChildren);
                                                var fieldDetails = AllReferenceDataService.processHierarchialData(dispSingleValue, refDataChildren);
                                                fieldValue = fieldDetails.singleValueLabel;
                                            }
                                        }
                                    }

                                    var tmpObj = {};
                                    tmpObj[accessName] = {
                                        "display": fieldValue
                                    };
                                    angular.extend(accessValuesProcessed, tmpObj);
                                }
                                ;
//								console.log('accessValuesProcessed',accessValuesProcessed);
//								console.log(angular.setDisplayFormat(formFiled,accessValuesProcessed));
                                pushArray.details.push(self.setDisplayFormat(formFiled, accessValuesProcessed));
                            });
                        } else {	//for request
                            //var valueObj = {};
                            //console.log('requestedAccess.Operations: ',requestedAccess.Operations);
                            angular.forEach(requestedAccess.Operations, function (accessValues, accessIndex) {
                                if (accessValues.path != formFiled.key) {
                                    return true;
                                }
                                angular.forEach(accessValues.values, function (values, valuesIndex) {
                                    //console.log('values: ',values);
                                    if (values.value) {
                                        delete values.value;
                                    }

                                    var accessValuesProcessed = {};
                                    for (var accessKey in values) {
                                        var accessName = accessKey;
                                        var fieldValue = values[accessKey].display;
                                        if ($filter('filter')(metadataFieldGroup, {"key": accessKey}, true).length) {
                                            var foundField = $filter('filter')(metadataFieldGroup, {"key": accessKey}, true)[0];
                                            accessName = foundField.templateOptions.label;
                                            if (foundField.data && foundField.data.refData) {
                                                var accessRefData = foundField.data.refData;
                                                if (globalReferenceData[accessRefData] && globalReferenceData[accessRefData].children) {
                                                    refDataChildren = globalReferenceData[accessRefData].children;
                                                    var dispSingleValue = values[accessKey].value;
                                                    //console.log('dispSingleValue',dispSingleValue);
                                                    //console.log('refDataChildren',refDataChildren);
                                                    var fieldDetails = AllReferenceDataService.processHierarchialData(dispSingleValue, refDataChildren);
                                                    fieldValue = fieldDetails.singleValueLabel;
                                                }
                                            }
                                        }

                                        var tmpObj = {};
                                        tmpObj[accessName] = {
                                            "display": fieldValue,
                                            "op": accessValues.op
                                        };
                                        //tmpObj["op"] = accessValues.op;
                                        angular.extend(accessValuesProcessed, tmpObj);
                                    }
                                    ;
                                    //console.log('accessValuesProcessed',accessValuesProcessed);

                                    pushArray.details.push(self.setDisplayFormat(formFiled, accessValuesProcessed));
                                });
                            });
                        }
                        displayForm[formFiled.name] = pushArray;
                        break;

                    case undefined:
                        if (formFiled.fieldGroup != undefined && formFiled.fieldGroup.length) {
                            displayForm = service.getDisplayForm(formFiled.fieldGroup, requestedAccess, mode, true, globalReferenceData, profile);
                        }
                        break;

                        /*case "label":
                         if (formFiled.data.addToModel) {
                         var pushArray = {
                         type: formFiled.type,
                         key: formFiled.key,
                         details: [requestedAccess[formFiled.key]] 
                         };
                         if(requestedAccess[formFiled.key]){
                         displayForm[formFiled.name] = pushArray;
                         }
                         }
                         break;*/

                    case "customcheckbox":
                    	if (requestedAccess[formFiled.key]) {
	                    	var dispSingleValue = requestedAccess[formFiled.key];
                            // Replace boolean values with Yes/No while display
	                    	if (Boolean(dispSingleValue) == true) {
	                            dispSingleValue = 'Yes';
	                        } else if (Boolean(dispSingleValue) == false) {
	                            dispSingleValue = 'No';
	                        }
	                    	
	                    	if (refDataChildren) {
	                            if ($filter('filter')(refDataChildren, {"name": formFiled.name}, true).length) {
	                                var refDataElement = $filter('filter')(refDataChildren, {"name": formFiled.name}, true)[0];
	                                formFiled.name = refDataElement.attributes.label;
	                            }
	                        }
	                    	var pushArray = {
	                            type: formFiled.type,
	                            key: formFiled.key,
	                            details: [dispSingleValue]
	                        };
                            displayForm[formFiled.name] = pushArray;
                        }
                    	break;
                    	
                    default:
                        var dispSingleValue = requestedAccess[formFiled.key];
                        // Replace boolean values with Yes/No while display
                    	if (requestedAccess[formFiled.key] == true || requestedAccess[formFiled.key] == "true") {
                            dispSingleValue = 'Yes';
                        } else if (requestedAccess[formFiled.key] == false || requestedAccess[formFiled.key] == "false") {
                            dispSingleValue = 'No';
                        } else if (refDataChildren) {
                            if ($filter('filter')(refDataChildren, {"name": dispSingleValue}, true).length) {
                                var refDataElement = $filter('filter')(refDataChildren, {"name": dispSingleValue}, true)[0];
                                dispSingleValue = refDataElement.attributes.label;
                            }
                        }
                        
                        var pushArray = {
                            type: formFiled.type,
                            key: formFiled.key,
                            details: [dispSingleValue]
                        };
                        if (requestedAccess[formFiled.key]) {
                            displayForm[formFiled.name] = pushArray;
                        }
                } // EO switch (formFiled.type) 

            });
            
            if (!isRecursive || isRecursive !== true) {
                if (requestedAccess.endDate) {
                    //var dateFormatted = $filter('date')(requestedAccess.endDate, "MM/dd/yyyy HH:mm:ss");
                	var dateFormatted = $filter('date')(requestedAccess.endDate, "MM/dd/yyyy h:mma Z");
                    var pushArray = {
                        type: "customselect",
                        key: "endDate",
                        details: [dateFormatted]
                    };
                    displayForm['End Date'] = pushArray;
                }
            }
            return displayForm;
        } // EO getDisplayForm

        service.formatRequestDetails = function (apiRequestData) {
            var formattedJSON = {};
            console.log(apiRequestData.assignedTo);
            return formattedJSON;
        }

        /* Get standard status to display across application */
        service.getAccessStatusText = function (status, requestMethod) {
            var accessStatus = status;

            /* Logic to determine request status to display */
            if (status.toLowerCase() == REQUEST_STATUS.COMPLETED.toLowerCase() && requestMethod.toLowerCase() == REQUEST_STATUS.DELETE.toLowerCase()) {
                accessStatus = REQUEST_STATUS.REVOKED; // Show as Revoked (Red)
            } else if (INCLUDE.STATUS_PENDING.indexOf(status.toLowerCase()) !== -1) {
                accessStatus = REQUEST_STATUS.PENDING; // Show as PENDING (Orange)
            } else if (status.toLowerCase() == REQUEST_STATUS.COMPLETED.toLowerCase()) {
                accessStatus = REQUEST_STATUS.PROVISIONED; // Completed requests show as PROVISIONED text (Green)
            } else if (status.toLowerCase() == REQUEST_STATUS.QUESTIONED.toLowerCase()) {
                accessStatus = "Info Requested";
            }

            return accessStatus;
        };
        
        // Service to Get text class of request status
        service.getRequestStatusClass = function (status) {
            //console.log('status',status);
            var className;
            switch (status.toUpperCase()) {
                case REQUEST_STATUS.COMPLETED.toUpperCase():
                case REQUEST_STATUS.PROVISIONED.toUpperCase():
                    className = 'green-status';
                    break;

                case REQUEST_STATUS.REJECTED.toUpperCase():
                case REQUEST_STATUS.REVOKED.toUpperCase():
                case REQUEST_STATUS.QUESTIONED.toUpperCase():
                case REQUEST_STATUS.D_INFOREQUESTED.toUpperCase():
                case REQUEST_STATUS.WITHDRAWN.toUpperCase():
                    className = 'red-status';
                    break;

                case REQUEST_STATUS.EXPIRED.toUpperCase():
                case REQUEST_STATUS.STALE.toUpperCase():
                    className = 'yellow-status';
                    break;

                case REQUEST_STATUS.CANCELLED.toUpperCase():
                    className = 'dark-grey-status';
                    break;

                case REQUEST_STATUS.WAITING.toUpperCase():
                case REQUEST_STATUS.PENDING.toUpperCase():
                case REQUEST_STATUS.INPROGRESS.toUpperCase():
                case REQUEST_STATUS.PROVISIONING.toUpperCase():
                case REQUEST_STATUS.ASSIGNED.toUpperCase():
                    className = 'orange-status';
                    break;

                default:
                    className = 'default-status';
            }
            return className;
        };
        
        // Service to Get background class of request status
        service.getRequestStatusBGClass = function (status) {

            var className;
            switch (status.toUpperCase()) {
                case REQUEST_STATUS.COMPLETED.toUpperCase():
                case REQUEST_STATUS.PROVISIONED.toUpperCase():
                    className = 'green-status';
                    break;

                case REQUEST_STATUS.REJECTED.toUpperCase():
                case REQUEST_STATUS.REVOKED.toUpperCase():
                case REQUEST_STATUS.QUESTIONED.toUpperCase():
                case REQUEST_STATUS.WITHDRAWN.toUpperCase():
                case REQUEST_STATUS.CANCELLED.toUpperCase():
                    className = 'red-status';
                    break;

                case REQUEST_STATUS.EXPIRED.toUpperCase():
                case REQUEST_STATUS.STALE.toUpperCase():
                    className = 'yellow-status';
                    break;

                case REQUEST_STATUS.ASSIGNED.toUpperCase():
                case REQUEST_STATUS.FUTURE.toUpperCase():
                    className = 'grey-status';
                    break;

                case REQUEST_STATUS.WAITING.toUpperCase():
                case REQUEST_STATUS.PENDING.toUpperCase():
                case REQUEST_STATUS.INPROGRESS.toUpperCase():
                case REQUEST_STATUS.PROVISIONING.toUpperCase():
                    className = 'orange-status';
                    break;

                default:
                    className = 'default-status';
            }
            return className;
        };
        
        // Service to Get stage name of request to display
        service.getRequestStageDisplay = function (assigned) {
            var stage;
            if (assigned.status == REQUEST_STATUS.COMPLETED && assigned.result) {
                stage = $filter('titleCase')(assigned.result);
            } else if (assigned.status.toLowerCase() == REQUEST_STATUS.QUESTIONED.toLowerCase()) {
                stage = "Info Requested";
            } else {
                stage = $filter('titleCase')(assigned.status);

                /* Overwrite stage in case of Future status */
                if (assigned.status.toUpperCase() == REQUEST_STATUS.FUTURE.toUpperCase()) {
                    stage = assigned.stage;
                }
            }

            return stage;
        };

        service.toggleaccordion = function (event) {
            //event.preventDefault();
            // create accordion variables
            if ($(event.target).hasClass("info-text"))
            {
                var accordion = $(event.target);
                var accordionContent = accordion.parents(".accordion-toggle").next('.accordion-content').not('.fixed');
                var accordionToggleIcon = accordion.parents(".accordion-toggle").children('.toggle-icon').not('.toggle-access-icon');
                var accordionToggleInfo = accordion.parents(".accordion-toggle").children('.toggle-info').not('.toggle-access-icon');
            }
            else if ($(event.target).hasClass("icons-plus-circle"))
            {
                var accordion = $(event.target);
                var accordionContent = accordion.parents(".accordion-toggle").next('.accordion-content').not('.fixed');
                var accordionToggleIcon = accordion.parents(".accordion-toggle").children(".toggle-icon").not('.toggle-access-icon');
                var accordionToggleInfo = accordion.parents(".accordion-toggle").children('.toggle-info').not('.toggle-access-icon');
            }
            else
            {
                var accordion = $(event.target);
                var accordionContent = accordion.next('.accordion-content').not('.fixed');
                var accordionToggleIcon = $(event.target).children('.toggle-icon').not('.toggle-access-icon');
                var accordionToggleInfo = $(event.target).children('.toggle-info').not('.toggle-access-icon');
            }

            $(".accordion-container").find(".accordion-toggle").removeClass("open");

            $(".accordion-container").find(".accordion-content").not('.fixed').hide(100);

            $(".accordion-container").find(".toggle-icon").not('.toggle-access-icon').html("<i class='icon-style icons-plus-circle'></i>");
            $(".accordion-container").find(".toggle-info").not('.toggle-access-icon').html("<span class='info-text'>Show Details</span>");
            // toggle accordion link open class
            // toggle accordion content
            if (accordionContent.is(":visible"))
            {
                accordionToggleIcon.html("<i class='icon-style icons-plus-circle'></i>");
                accordionToggleInfo.html("<span class='info-text'>Show Details</span>");
                accordionContent.hide(100);
            }
            else
            {
                accordionToggleIcon.html("<i class='icon-style icons-minus-circle'></i>");
                accordionToggleInfo.html("<span class='info-text'>Hide Details</span>");
                accordionContent.show(100);
            }
        };

        // Service for all ARP application dialog modal popups
        service.opendialog = function ($event, $scope, type) {
            var template;
            switch (type) {
                case 'approve':
                    template = 'approved-dialog.tmpl.html';
                    break;

                case 'reject':
                    template = 'warn.tmpl.html';
                    break;

                case 'complete':
                    template = 'manual-complete.tmpl.html';
                    break;

                case 'cancel':
                    template = 'request-cancel.tmpl.html';
                    break;

                case 'user-table-info':
                    template = 'user-table-info.tmpl.html';
                    break;

                case 'review-access':
                    template = 'review-access-dialog.tmpl.html';
                    break;
            }

            var viewPath = VIEW_PATH.mainview + 'requests/dialog/';

            $mdDialog.show({
                controller: DialogCtrl,
                scope: $scope,
                preserveScope: true,
                controllerAs: 'ctrl',
                templateUrl: viewPath + template,
                targetEvent: $event,
                clickOutsideToClose: false
            }).then(function (actionData) {
                $scope.comment = actionData;
            }, function () {
                $scope.comment = '';
            });
            ;

            function DialogCtrl() {
                var self = this;
                // list of `state` value/display objects
                //self.states        = loadAll();
                //self.querySearch   = querySearch;
                // ******************************
                // Template methods
                // ******************************
                self.cancel = function ($event) {
                    $mdDialog.cancel();
                };
                self.finish = function ($event) {
                    $mdDialog.hide();
                    service.processRequest($scope, type);
                };
            }
        };

        return service;
    });
});
