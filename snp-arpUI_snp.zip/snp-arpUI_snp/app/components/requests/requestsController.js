define(['app', 'angularAMD'], function (app, RequestsModule) {

    RequestsModule.controller('RequestsController',
		function ($scope, $rootScope, $state, RequestsService) {

		});
    
    /* Controller for Request Details screen view */
    RequestsModule.controller('RequestDetailsController',
            function ($scope, $rootScope, $stateParams, $filter, $mdDialog, $http, RequestDetailsService, AccessService, AllReferenceDataService, VIEW_PATH, Restangular, TmpRestangular, REQUEST_STATUS,_currentUser,UserService, SCROLLBAR_DIV_HEIGHT, LIMITS, NOMINATION,INCLUDE,BrowserService) {
    			
		    	$scope.requestId = $stateParams.requestId;
		    	$scope.requestName = $stateParams.requestName;
		        
		        $scope.viewPath = VIEW_PATH.mainview + 'requests/dialog/';
				$scope.REQUEST_STATUS = REQUEST_STATUS;
				$scope.request = "";
				$scope.approver = {};
				$scope.requestableName = "";
				$scope._currentUser = _currentUser;
				$scope.TEXTLIMIT = LIMITS.TEXT_CHARS;
					
				if (!$scope.requestId) {
					$scope.request = false;
				} else {
					$scope.isLoading = true;
					/* Get Single Request Details from API */
					var requestObj = Restangular.one('bulk',$scope.requestId).get();
					
					requestObj.then(function(req){
						if(!angular.isUndefined(req.data)){
							$scope.request = req.data;
							$scope.showApproveReject = false;
							$scope.showComplete = false;
							$scope.showApprove = false;
							$scope.showReject = false;
							$scope.showAddQuestion = false;
							$scope.showAddComment = false;
							$scope.LAMApprover = false;
                            
                            /* Get status to display */
                            $scope.requestStatus = RequestDetailsService.getAccessStatusText($scope.request.status,$scope.request.Operations[0].method);
							
							/* Array to store all applicable only Approvers for a request */
							//$scope.assignedApprovers = [];
							$scope.assignedApprovers = $scope.request.assignedTo || [];
                            
							/* Get assigned User/Group */
							angular.forEach($scope.request.assignedTo, function(assigned,index){
								
                                if(assigned.status==$scope.REQUEST_STATUS.ASSIGNED || assigned.status.toUpperCase()==$scope.REQUEST_STATUS.QUESTIONED.toUpperCase()){
									$scope.approver = assigned;
								}
                                
                                if(NOMINATION.APPROVER_STAGES.indexOf(assigned.stage)!=-1){
                                    $scope.LAMApproverName = assigned.display;
                                }
                                
							});
							
							$scope.requestableName = $scope.request.Operations[0].target;
							$scope.requestedAccess = $scope.request.Operations[0].data;
							$scope.owner = $scope.request.Operations[0].owner;
							
							$scope.allComments = RequestDetailsService.getDiscussion($scope);
                           
                            $scope.discussions = $scope.allComments.filter(function( commentObj ) {
                                return commentObj.type !== 'attachment';
                            });
                            
							if($scope.approver){
								// Check signed in User is approver
								if($scope.approver.category && $scope.approver.category.toLowerCase()=='group'){
                                    
                                    /* Check for group members */
                                    Restangular.one('groups',$scope.approver.value).get().then(function(req){
                                        
                                        var groupMembers = req.data.members;
                                        // Search for logged in user is member of a group
                                        var groupMember = $filter('filter')(groupMembers, {value: _currentUser.userId});
                                        if (groupMember.length) {
                                            /*** YES, Signed In User belongs to Approver Group ***/
                                            
                                             /* Get details from Task APIs for actions */
                                            var task = Restangular.one("tasks", $scope.approver['task-value']).get();

                                            task.then(function(res) {
                                                //console.log('group task details: ',res.data.plain());
                                                var approverTask = res.data.plain();
                                                
                                                // Check for valid applicable tasks actions and take decision on showing Approve, Reject or Complete buttons
                                                angular.forEach(approverTask.operations, function(taskOperation,opindex){
                                                    if(INCLUDE.REQUEST_ACTIONS.indexOf(taskOperation.toLowerCase()) !== -1){
                                                        
                                                        if(taskOperation.toLowerCase()=='claim'){
                                                            
                                                            if(INCLUDE.COMPLETE_ACTION_STAGES.indexOf(approverTask.processDetails.stage.toLowerCase()) !== -1){
                                                                $scope.showComplete = true;
                                                            }else{
                                                                $scope.showApproveReject = true;
                                                                $scope.showAddQuestion = true;
                                                            }
                                                        }else if(taskOperation.toLowerCase()=='approve'){
                                                            $scope.showApproveReject = true;
                                                            $scope.showAddQuestion = true;
                                                        }else if(taskOperation.toLowerCase()=='complete'){
                                                            $scope.showComplete = true;
                                                        }
                                                    }
                                                });
                                                
                                                if($scope.showAddQuestion){
                                                    /* Applicable only to waiting for approval Request */
                                                    if(INCLUDE.QUESTION_REQUEST.indexOf($scope.request.status.toLowerCase()) !== -1){
                                                        $scope.questionUsers = RequestDetailsService.getQuestionUsers($scope);
                                                    }
                                                }// EO if($scope.showAddQuestion)
                                                
                                            },function(response) {
                                                console.log("Error with status code ", response.status);
                                            });
                                            
                                            // Check for valid Nomination approver stages defined in appShared file to show nomination form.
                                            if(NOMINATION.APPROVER_STAGES.indexOf($scope.approver.stage)!=-1){
                                                $scope.LAMApprover = true;
                                                $scope.LAMApproverName = groupMember[0].displayName;
                                                
                                                $scope.showEditNominationForm();
                                            }
                                            
                                        } // EO if (groupMember.length) Signed In User belongs to Approver Group - Ends
                                        
                                    },function(response) {
						                  console.log("Error with status code", response.status);
					                });
								}else{
                                    // This else is for single user approver
                                    
									if($scope.approver.value && $scope.approver.value.toUpperCase()==_currentUser.userId.toUpperCase()){
										
										// If request Not assigned to beneficiary
										if($scope.request.Operations[0].owner.value.toUpperCase()!=_currentUser.userId.toUpperCase()){
											/*** YES, Signed In User is Approver ***/
                                            
                                            /* Get details from Task APIs for actions */
                                            var task = Restangular.one("tasks", $scope.approver['task-value']).get();

                                            task.then(function(res) {
                                                //console.log('task details: ',res.data.plain());
                                                var approverTask = res.data.plain();
                                                
                                                // Check for valid applicable tasks actions and take decision on showing Approve, Reject or Complete buttons
                                                angular.forEach(approverTask.operations, function(taskOperation,opindex){
                                                    if(INCLUDE.REQUEST_ACTIONS.indexOf(taskOperation.toLowerCase()) !== -1){
                                                        //console.log(taskOperation);
                                                        if(taskOperation.toLowerCase()=='claim'){
                                                            if(INCLUDE.COMPLETE_ACTION_STAGES.indexOf(approverTask.processDetails.stage.toLowerCase()) !== -1){
                                                                $scope.showComplete = true;
                                                            }else{
                                                                $scope.showApproveReject = true;
                                                                $scope.showAddQuestion = true;
                                                            }
                                                        }else if(taskOperation.toLowerCase()=='approve'){
                                                            $scope.showApproveReject = true;
                                                            $scope.showAddQuestion = true;
                                                        }else if(taskOperation.toLowerCase()=='complete'){
                                                            $scope.showComplete = true;
                                                        }
                                                    }
                                                });
                                                
                                                if($scope.showAddQuestion){
                                                    /* Applicable only to waiting for approval Request */
                                                    if(INCLUDE.QUESTION_REQUEST.indexOf($scope.request.status.toLowerCase()) !== -1){
                                                        $scope.questionUsers = RequestDetailsService.getQuestionUsers($scope);
                                                    }
                                                }// EO if($scope.showAddQuestion)
                                                
                                            },function(response) {
                                                console.log("Error with status code ", response.status);
                                            });
                                            
                                            // Check for valid Nomination approver stages defined in appShared file to show nomination form.
                                            if(NOMINATION.APPROVER_STAGES.indexOf($scope.approver.stage)!=-1){
                                                $scope.LAMApprover = true;
                                                $scope.LAMApproverName = $scope.approver.display;
                                                
                                                $scope.showEditNominationForm();
                                            }
                                            
										} // Signed In User is Approver - Ends
										
										// If request assigned to beneficiary for information by Approver
										if($scope.approver.status.toUpperCase()==$scope.REQUEST_STATUS.QUESTIONED.toUpperCase()){
											$scope.showAddComment = true;
										}
									}
								} // EO else
							}// EO if($scope.approver)     
                            
						} // EO if(!angular.isUndefined(req.data))
						else {
							$scope.request = false;
						}
                        
					},function(response) {
						console.log("Error with status code", response.status);
					}).finally(function () {
						$scope.isLoading = false;
					});
				}
				
				// Nomination Process
				$scope.displayNominationForm = false;
				$scope.editableNominationForm = true;
				
				/* Show Nomination in Read Only mode */
				$scope.showReadOnlyNominationForm = function () {
					//console.log('$scope.allComments',$scope.allComments);
					var attachmentComments = $filter('filter')($scope.allComments, {type: 'attachment'});
					if (attachmentComments && attachmentComments.length) {
                        /* Show Nomination in READ mode if form found */
						$scope.nomination = angular.fromJson(attachmentComments[0].message);
						$scope.nomination.time = new Date(attachmentComments[0].time);
						$scope.displayNominationForm = true;
						$scope.editableNominationForm = false;
					}
				};
                
                /* Show Nomination in Edit mode for LAM Approver */
                $scope.showEditNominationForm = function () {
                    
                    var currentDate = new Date();
                    $scope.minNominationDate = new Date(
                            currentDate.getFullYear(),
                            currentDate.getMonth(),
                            currentDate.getDate()
                        );
                    //console.log('$scope.minNominationDate',$scope.minNominationDate);

                    $scope.nomination = {};
                    $scope.nomination.time = currentDate;

                    $scope.nomination.advanceTests = {
                            'corporate' : [],
                            'financialInstitutions' : [],
                            'sovereignPublicFinance' : [],
                            'structuredFinance' : [],
                            'insurance' : [],
                            'usPublicFinance' : []
                        };
                    
                    $scope.displayNominationForm = true;
                };
	            
        
				// Fetch All Reference Data
				AllReferenceDataService.getGlobalReferenceData().then(
		        		function (response) {
		        			$scope.globalReferenceData = response;
                            //console.log('$scope.globalReferenceData',$scope.globalReferenceData);
                            
                            /* Get Requestable Ref Data - Start */
                            $scope.resourceTypes = $scope.globalReferenceData['snp.refData.requestables.data'].children;
                            $scope.requestableNameList = [];
                            angular.forEach($scope.resourceTypes, function (value, key) {
                                $scope.requestableNameList[value.name] = {
                                        'requestDisplayName': value.attributes.label
                                    };
                            });
                            /* Get Requestable Ref Data - End */
							
		        		}, function (error) {
							console.log("Error with status code", response.status);
						}
		        );
				
                // Wait for requestableName to load metadata
				$scope.$watch('requestableName', function(newRequestableName, oldRequestableName) {
					if (newRequestableName === oldRequestableName) { return; }
					
					/* Fetch form metadata */
					var metadataForm = Restangular.one('/config/idmprovider', 'snp.Form.' + newRequestableName).get();
					//var metadataForm = $http.get('app/components/forms/json/local/' + newRequestableName + '.json');
					metadataForm.then(function (res) {
						var resData = typeof res.data=='string' ? angular.fromJson(res.data) : res.data;
						$scope.formFields = resData.elements;
						//console.log('form fields: ',$scope.formFields);
						//StorageService.putData('formFields', $scope.formFields, STORAGE_TYPES.local);
						$scope.displayForm = RequestDetailsService.getDisplayForm($scope.formFields,$scope.requestedAccess,'request',false,$scope.globalReferenceData);
						//console.log('displayForm: ',$scope.displayForm);
						
						$scope.showReadOnlyNominationForm();
						
					});
				});
				
				/* Display Assigned To Name */
				$scope.showAssignedApprover = function(assigned){
					
					//var assignedCategory = assigned.category.toLowerCase();
					if(assigned.category){
					if(assigned.category.toLowerCase()!='group'){
						return assigned.display;
					}else if(assigned.category.toLowerCase()=='group' && assigned.status==REQUEST_STATUS.EXPIRED){
						return '---';
					}else{
						return 'TBD';
					}
					}else{
						return assigned.display;
					}
				}
				
                // Get text class of request status
				$scope.getRequestStatusClass = function (status) {
                    
                    if(angular.isUndefined(status)){ return; }
                    
					return RequestDetailsService.getRequestStatusClass(status);
				}
                
                // Get background class of request status
                $scope.getRequestStatusBGClass = function (status) {
                    
                    if(angular.isUndefined(status)){ return; }
                    
					return RequestDetailsService.getRequestStatusBGClass(status);
				}
				
				// Get stage name of request to display
				$scope.getRequestStageDisplay = function (assigned) {
					return RequestDetailsService.getRequestStageDisplay(assigned);
				}
				
				// get Requestor User
				$scope.getUserRequestor = function (userId) {
				
					UserService.getUserDetails(userId).then( function(req)
					{
						$scope.requestor = req.data.plain();
					},function(response) {
						console.log("Error with status code", response.status);
					});
				}
				
				// get Beneficiary User
				$scope.getUserBeneficiary = function (userId) {
				
					UserService.getUserDetails(userId).then( function(req)
					{
						$scope.beneficiary = req.data.plain();
					},function(response) {
						console.log("Error with status code", response.status);
					});
				}
				
				// get User Profile
				$scope.getUserProfileRequest = function (userId) {
				
					UserService.getUserDetails(userId).then( function(req)
					{
						$scope.userMember = req.data.plain();
					},function(response) {
						console.log("Error with status code", response.status);
					});
				}
				
				// get Group Members
				$scope.getGroupDetails = function (groupId) {
					UserService.getGroupDetails(groupId).then( function(req)
					{
						$scope.group = req.data.plain();
					},function(response) {
						console.log("Error with status code", response.status);
					});
				}
				
		        $scope.accordion_toggle = function (event) {
		        	RequestDetailsService.toggleaccordion(event);
		        };
		
		        $scope.openDialog = function ($event) {
		        	$scope.processNominationForm = false;
		        	if ($scope.LAMApprover && $scope.editableNominationForm) {
		        		$scope.processNominationForm = true;
		        	}
		            RequestDetailsService.opendialog($event,$scope,'approve');
		        };
        
                $scope.openCompleteDialog = function ($event) {
		        	RequestDetailsService.opendialog($event,$scope,'complete');
		        };
		
		        $scope.openwarnDialog = function ($event) {
		        	RequestDetailsService.opendialog($event,$scope,'reject');
		        };
		
		        $scope.userInfoTblDialog = function ($event) {
		            RequestDetailsService.opendialog($event,'user-table-info');
		        };
		
		        $scope.reviewAccessDialog = function ($event) {
		            RequestDetailsService.opendialog($event,'review-access');
		        };
        
        
		        //Get Scrollbar config
		        //$scope.scrollConfig = angular.scrollbarConfig(SCROLLBAR_DIV_HEIGHT.OFFSET);
		        
		        // Resize window height on viewport change
		        function resizePage() {
		            var page_height = $(window).height() - SCROLLBAR_DIV_HEIGHT.DEFAULT_SCROLL_OFFSET - 13;
		            //console.log('page_height',page_height);
		            $('.content-wrapper').height(page_height);
		        }
		        $(window).resize(resizePage);
		        //resizePage();
		        setTimeout(resizePage,100);
		        
		        $scope.disableApproveBtn = true;
		        $scope.enableBtn = function (event) {
		        	$scope.disableApproveBtn = false;
		        };
		        
		        // Get User's Current Access Details on demand
		        $scope.selectedAccess = {};
		        $scope.loadAccess = false;
		        $scope.displayForm = {};
		        $scope.editAccess = false;
		        
		        $scope.getAccessDetails = function() {
		        	$scope.myAccess = {};
		        	$('.access-info-table').addClass("hide");
		        	$('.access-not-found').removeClass("hide");
		        	//console.log('$scope.request.Operations[0].owner',$scope.request.Operations[0].owner);
			        $scope.userDetails = {
	            			"id": $scope.request.Operations[0].owner.value,
	            			"displayName": $scope.request.Operations[0].owner.display
	            		};
			        $scope.loadAccessList = true;
		        	AccessService.getCurrentAccessDetails($scope.request.Operations[0].owner.value, 'user', $scope)
	            		.then(function(resp) {
	            			var accessDetails = resp.currentAccess;
	            			$scope.myAccess = !angular.isObjectEmpty(accessDetails) ? accessDetails : false;
	                    	//console.log('$scope.myAccess',$scope.myAccess);
	            			
	            			$scope.profile = resp.profile;
	            			//console.log('$scope.profile',$scope.profile);
	            			$scope.loadAccessList = false;
	            		},
	            		function (error) {
	            			console.log("Error with status code", error.status);
	            			$scope.loadAccessList = false;
							//$scope.error = error.statusText;
	            		});
	            };
		        
            });
    
    RequestsModule.controller('DiscussionController', 
    		function ($scope, $element, $filter,_currentUser, Restangular,$state) {

		        $scope.discussionresponseanswer = discussionresponseanswer;
		        $scope.raisenewquestion = raisenewquestion;
		        $scope.postquestionresponse = postquestionresponse;
		        $scope.discussionquestion = discussionquestion;
		        $scope.postdiscussionresponse = postdiscussionresponse;
		        $scope.homePopoverPostdiscussionresponse = homePopoverPostdiscussionresponse;
		        $scope.closediscussion = closediscussion;
		        $scope.addcomment = addcomment;
		        $scope.postcomment = postcomment;
		        $scope.closeAddComment = closeAddComment;
                
                
		
		        /*Textarea KeyUp Event to Enable the Response Button and Find No of Characters used*/
		        function discussionresponseanswer(event) {
		        	//var content_length = $(event.target).val().length;
		        	var content_str = $.trim($(event.target).val());
		            var content_length = content_str.length;
                    $(event.target).removeClass('green-textarea');
		            $("#add-comment").find(".content-length-change").html(content_length);
		            if (content_length != 0) {
		                $(".response-button").removeAttr('disabled');
		            }
		            else
		            {
		                $(".response-button").attr('disabled', 'disabled');
		            }
		        };
        
                function discussionquestion(event) {
		            //var content_length = $(event.target).val().length;
                	var content_str = $.trim($(event.target).val());
		            var content_length = content_str.length;
		            $(event.target).removeClass('green-textarea');
		            $("#discuss-question").find(".content-length-change").html(content_length);
		            /*if (content_length != 0) {
		                $(".post-button").removeAttr('disabled');
		            }
		            else
		            {
		                $(".post-button").attr('disabled', 'disabled');
		            }*/
		        };
		
		        /*Raise a New Question Click event*/
		        function raisenewquestion(event) {
		            $("#discuss-question").removeClass("hide");
		            //$(".post-button").attr("disabled", "disabled");
		            $("#discuss-question").find(".discussion-question-textarea").addClass("green-textarea");
		            $scope.selectedUser3 = "";
		            $scope.discussionQuestionContent = "";
		            $(".discussion-header-question").addClass('hide');
		        };
		
		        /*Add Comment Click event*/
		        function addcomment(event) {
		            $("#add-comment").removeClass("hide");
		            $(".post-button").attr("disabled", "disabled");
		            $("#add-comment").find(".discussion-question-textarea").val('').addClass("green-textarea");
		            $scope.selectedUser3 = "";
		            $(".discussion-header-question").addClass('hide');
		        };
		
		        /*Close Discussion >> Add Comment*/
		        function closeAddComment()
		        {
		        	$(".discussion-header-question").removeClass('hide');
					$("#add-comment").addClass("hide");
		        }
		        
		        /*Close Discussion >> Add Question*/
		        function closediscussion(event)
		        {
                    var content_length = $(event.target).val().length;
		            $("#discuss-question").find(".content-length-change").html(content_length);
		            $(".discussion-header-question").removeClass('hide');
		        	$("#discuss-question").addClass("hide");
		        	
		        }
		
		        function postquestionresponse(event)
		        {
		            $("#add-comment").addClass("hide");
		
		            //var content = $("#discuss-question").find(".discussion-question-textarea").val();
		            var content = $scope.discussionQuestionContent;
		            var userval = $scope.selectedUser3;
		            var currentdate = new Date();
		            var datetime = $filter('date')(currentdate, 'MM/dd/yyyy h:mma');
		
		            var question_template = '<div class="discussion-header"><i class="icon-style icons-comments-question"></i><p><span class="blue-text">'+_currentUser.displayName+'</span> to <strong>' + userval +'</strong><strong>' + datetime + '</strong></p></div><div class="discussion-content"><p class="triangle-border left-top tb-success">' + content + '</p></div>';
		            $("#discuss-question").addClass("hide");
		            $(question_template).insertAfter($(".discussion-new-post"));
		            $(".success-discussion-content").find(".alert-success").html("Your question has been successfully posted to " + userval + ".");
		            $(".success-discussion-content").find(".alert-success").removeClass("hide");
		            
		            $(".discussion-header-question").removeClass('hide');
					
					/* Post Question to API */
					var task = Restangular.one("tasks", $scope.approver['task-value']);
					
					actionComment = { 
							"action":"request-info",
							"message":content,
							"parameters" : {
								"assignee" : [
										{
											"value": userval,
											"category" : "user"
										}
									]
							}
						};
                    
					task.customPOST(actionComment, ".action", {}, {}).then(function() {
					
						$state.go('inbox.list', {'alertType':'question_success'}, {reload: true});
						
					}, function() {
						console.log("There was an error posting Question!");
					});
		        };
		
		        function postcomment(event)
		        {
		            $("#discuss-question").addClass("hide");
		
		            var content = $("#add-comment").find(".discussion-question-textarea").val();
		            var currentdate = new Date();
		            var datetime = $filter('date')(currentdate, 'MM/dd/yyyy h:mma');
		
		            var question_template = '<div class="discussion-header"><i class="icon-style icons-comments-question"></i><p><span class="blue-text">'+_currentUser.displayName+'</span> <strong>' + datetime + '</strong></p></div><div class="discussion-content"><p class="triangle-border left-top tb-success">' + content + '</p></div>';
		            $("#add-comment").addClass("hide");
		            $(question_template).insertAfter($(".discussion-new-post"));
		            $(".success-discussion-content").find(".alert-success").html("Your comment has been successfully posted.");
		            $(".success-discussion-content").find(".alert-success").removeClass("hide");
		            
		            $(".discussion-header-question").removeClass('hide');
					
					/* Post Question to API */
					var task = Restangular.one("tasks", $scope.approver['task-value']);
					
					actionComment = { 
							"action":"submit-info",
							"message":content
						};
					
					task.customPOST(actionComment, ".action", {}, {}).then(function() {
						
                        $state.go('inbox.list', {'alertType':'answered_success'}, {reload: true});
						
						/*setTimeout(function () {
							$("#alert-answered-success").removeClass("hide");
							setTimeout(function () {
								$("#alert-answered-success").addClass("hide");
							}, 1000);
						}, 2000);*/
                        
					}, function() {
						console.log("There was an error posting comment!");
					});
		
		        };
		
		        
		        /*Post Response click event*/
		        function postdiscussionresponse(event) {
		            var content = $("#discussion-responseanswer").find(".discussion-textarea").val();
		            var currentdate = new Date();
					var datetime = $filter('date')(currentdate, 'MM/dd/yyyy h:mma');
		
		            var answer_template = '<div class="discussion-header bg-ct"><p><span class="blue-text">'+_currentUser.displayName+'</span> <strong>' + datetime + '</strong></p></div><div class="discussion-content"><p class="triangle-border right-top">' + content + '</p></div>';
		            $("#discussion-responseanswer").addClass("hide");
		            $(".response-button").addClass('hide');
		            $(answer_template).insertBefore($("#discussion-responseanswer"));
		            //$("#discussion-responseanswer").find(".discussion_content").append(answer_template);
		        }
		
		
		        function homePopoverPostdiscussionresponse(event) {
		            $("#discussion-responseanswer").hide();
		            $("#popover-discussions").find(".poD-content").hide();
		            $("#popover-discussions").find(".response-button").addClass('hide');
		            $("#popover-discussions").find(".success-discussion-content").find(".alert-success").find(".success-link").html("Your question has been successfully posted to Greg Knowlton");
		            $("#popover-discussions").find(".success-discussion-content").find(".alert-success").removeClass("hide");
		            $("#popover-discussions").find(".ok-button").removeClass("hide");
		            $("#popover-discussions").find(".discussion-header").hide();
		        }
				
    	});
        
});
