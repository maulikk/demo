define(['app', 'angularAMD', 'smartTable'], function (app, AccessModule, smartTable) {

	// Controller for Current Access tab in My Access page
    AccessModule.controller('AccessController', 
		function ($scope, $rootScope, $state, AccessService, RequestDetailsService, AllReferenceDataService, Restangular, _currentUser, _requestableType, REQUEST_STATUS, SCROLLBAR_DIV_HEIGHT) {
    	
	    	$scope.STATUS = REQUEST_STATUS;
	    	$scope.selectedAccess = {};
	    	
	    	// Show tab selected depending on the current url state
			$scope.selectedIndex = 0;
            if ($state.current.name === 'access' || $state.current.name === 'access.current') {
                $scope.selectedIndex = 0;
            } else if ($state.current.name === 'access.history') {
                $scope.selectedIndex = 1;
            }

            // Watch for changes in selectedIndex to navigate between My Access & History tabs
            $scope.$watch('selectedIndex', function (current, old) {
            	//console.log('current',current);
                if (current === 0) {
                    $state.go('access.current');
                } else if (current === 1) {
                    $state.go('access.history');
                }
            });
            
            // Reset previously selected access data, if not coming from New Request - Access page
            /*if($rootScope.previousState!='request.form') {
            	sessionStorage.removeItem('userAccessSelectedUserAccess');
            }*/
            
            // Get User's Current Access Details on navigating to My Access tab
            $scope.loadAccess = false;
            $scope.displayForm = false;
            $scope.editAccess = true;
            $scope.userDetails = {
        			"id": _currentUser.userId,
        			"displayName": _currentUser.firstName + " "	+ _currentUser.lastName
        		};
            $scope.getAccessDetails = function() {
            	$scope.loadAccessList = true;
            	AccessService.getCurrentAccessDetails(_currentUser.userId, 'user', $scope).then(
            		function(resp) {
            			var accessDetails = resp.currentAccess;
            			$scope.myAccess = !angular.isObjectEmpty(accessDetails) ? accessDetails : false;
                    	//console.log('$scope.myAccess',$scope.myAccess);
            			
            			$scope.profile = resp.profile;
            			//console.log('$scope.profile',$scope.profile);
                        
            			$scope.loadAccessList = false;
            		},
            		function (error) {
            			console.log("Error with status code", error.status);
            			$scope.loadAccessList = false;
						//$scope.error = error.statusText;
            		}
        		);
            	
            };
            
            $scope.resetHistoryPagination = function() {
            	$scope.historyPagination = {
                		startIndex : 1,
                		count : 20
                	};
            };
        
            $scope.getRequestStatusClass = function (status) {
                return RequestDetailsService.getRequestStatusClass(status);
            }
            
            /* Display timeline dots as per status */
            $scope.getHistoryDotClass = function (status) {
                var className;
                switch (status.toUpperCase()) {
                    case $scope.STATUS.COMPLETED.toUpperCase():
                    case $scope.STATUS.PROVISIONED.toUpperCase():
                        className = 'history-timeline-dot-green';
                        break;

                    case $scope.STATUS.REJECTED.toUpperCase():
                    case $scope.STATUS.REVOKED.toUpperCase():
                        className = 'history-timeline-dot-red';
                        break;
                        
                    case $scope.STATUS.CANCELLED.toUpperCase():
                        className = 'history-timeline-dot-grey';
                        break;

                    case $scope.STATUS.WAITING.toUpperCase():
                    case $scope.STATUS.PENDING.toUpperCase():
                    case $scope.STATUS.INPROGRESS.toUpperCase():
                    case $scope.STATUS.PROVISIONING.toUpperCase():
                        className = 'history-timeline-dot-orange';
                        break;

                    default:
                        className = 'history-timeline-dot';
                }
                return className;
            }
            
            // Get User's History on navigating to History tab
            $scope.getHistoryDetails = function() {
            	$scope.loadAccess = true; 
            	$scope.error = '';
            	$scope.myHistory = {};
            	$scope.resetHistoryPagination();
    			//console.log('$scope.historyPagination',$scope.historyPagination);
    			
            	// Get Request Type/Category
            	$scope.requestableName = {};
		        AllReferenceDataService.getGlobalReferenceData().then(
		        		function (res) {
		        			//$scope.resourceTypes = res.children;
		        			$scope.resourceTypes = res['snp.refData.requestables.data'].children;
		        			//console.log('$scope.resourceTypes',$scope.resourceTypes);
		        			
		        			angular.forEach($scope.resourceTypes, function (value, key) {
								
								// Always fetch attribute "type" from requestableData if present, else fetch typeLabel for display
			                    if(value.attributes.type){
			                        accessType = value.attributes.type;
			                    }else{
			                    	accessType = value.attributes.typeLabel;
			                    }
								$scope.requestableName[value.name] = {
										'resourceType': accessType,
										'requestDisplayName': value.attributes.label
									};
							});
							
							// Get Request History
				        	AccessService.getHistoryDetails(_currentUser.userId, $scope.requestableName, $scope.historyPagination)
					    		.then(function(resp) {
					    			$scope.loadAccess = false;
					    			$scope.error = '';
					    			var historyDetails = resp;
					    			//historyDetails = angular.sortJSONArray(historyDetails,'dateRequested',false);
					    			$scope.myHistory = (!angular.isObjectEmpty(historyDetails) && !angular.isUndefinedOrNull(historyDetails)) ? historyDetails : false;
					            	//console.log('$scope.myHistory',$scope.myHistory);
					    		});
				        	
		        		}, function (error) {
							console.log("Error with status code", response.status);
							$scope.loadAccess = false;
							$scope.error = error.statusText;
						}
		        ).finally(function () {
                    //console.log('Complete');
                });
            	
            };
        });
    
    /*
     * Navigate the list and select the user using keybaord
     * DO NOT MOVE this arrowselector directive
     */
    AccessModule.directive('arrowSelector', ['$document', function ($document) {
            return{
                restrict: 'A',
                link: function (scope, elem, attrs, ctrl) {
                    var elemFocus = false;
                    elem.on('mouseenter', function () {
                        elemFocus = true;
                    });
                    elem.on('mouseleave', function () {
                        elemFocus = false;
                    });
                    $document.bind('keydown', function (e) {
                        var elmnt = document.getElementById("scrolldiv");
                        if (elemFocus) {
                            if (e.keyCode == 38) {
                                if (scope.selectedRow == 0) {
                                    elmnt.scrollTop = 0;
                                    return;
                                }
                                //console.log("up...")
                                elmnt.scrollTop -= 28;
                                scope.selectedRow--;
                                scope.$apply();
                                e.preventDefault();
                            }
                            if (e.keyCode == 40) {
                                if (scope.selectedRow == scope.reportees.length - 1) {
                                    elmnt.scrollTop = elmnt.scrollHeight;
                                    return;
                                }
                                //console.log("down...")
                                elmnt.scrollTop += 28;
                                scope.selectedRow++;
                                scope.$apply();
                                e.preventDefault();
                            }
                            if (e.keyCode == 13) {
                                scope.selectedItemChange(scope.reportees[scope.selectedRow]);
                                scope.$apply();
                                e.preventDefault();
                            }
                        }
                    });
                }
            };
        }]);

    // Controller for Manage User Access page
    AccessModule.controller('UserAccessController', 
		function ($scope, $rootScope, $state, $window, $q, AccessService, userAccessDetailsFactory, Restangular, _currentUser, _requestableType, REQUEST_STATUS, SCROLLBAR_DIV_HEIGHT, PAGINATION_COUNT) {
    	
	    	$scope.STATUS = REQUEST_STATUS;
	    	$scope.loadAccess = true;
	    	$scope.editAccess = true;
	    	$scope.selectedAccess = {};
	    	
	    	/*$scope.resetUserAccessStorageData = function () {
            	sessionStorage.removeItem('userAccessSelectedUser');
            	sessionStorage.removeItem('userAccessSelectedUserAccess');
            }
            if($rootScope.previousState!='request.form') {
            	$scope.resetUserAccessStorageData();
            }*/
            
	    	/////////////////////////////////////
	    	/****** Ajax Smart table ****************/
	    	// Fetch Manager's Reportees to get their Accesses
            $scope.paginationPageSizes = [10, 20, 50, 100];
            $scope.itemsByPage = 200;
            $scope.reportees = [];
            $scope.isDisabled = false;
            $scope.searchPlaceholder = "Search Reportees";
            var abortGet;
            
            $scope.getManagerReportees = function (tableState) {
            	var pagination = tableState.pagination;
                var start = pagination.start || 1;     // This is NOT the page number, but the index of item in the list that you want to use to display the table.
                var number = pagination.number || false;  // Number of entries showed per page. if pagination.number not found set false .

                var searchText = tableState.search.predicateObject ? tableState.search.predicateObject.displayName : '';
                if (searchText && searchText.length) {
                    $scope.selectedRow = 0;
                    $scope.reportees = null;
                }
                //console.log('searchText',searchText);
                if (number && searchText && searchText.length > 2) {
                    $scope.isLoading = true;
                    number = 20;
                    
                    var objReportees = {
   	                 	"id": "reportees",
   	                 	"startIndex": start,
   	                 	"count": PAGINATION_COUNT.DEFAULT,		//number
   	                 	"searchParameters": {
   	                 		"name": searchText
   	                 	}
                    };
                    /*var objReportees = {
                        "id": "userAccessSearch",
                        "searchParameters": {
                            "name": searchText
                        }
                    };*/
                    
                    var addlHeaders = {
                		//'mhcSegment': 'MCGRAW-HILL CORPORATE',
                        //'mhcGroup': '',
                        //'mhcRatingAttributeARPProfile': 'DSC',
                        'X-Midas-Service-Name': 'default-ldap'
                    };
                    
                    // Aborting any previous unresolved request and proceed
                    if (abortGet) {
                    	abortGet.resolve();
                    }
                    abortGet = $q.defer();
                    var resultPromise = Restangular.all("users/.search").withHttpConfig({timeout: abortGet.promise}).post(objReportees, {}, addlHeaders); // ?midas-service=default-ldap
                    
                    resultPromise.then(function (result) {
                        if (result.error) {
                        	$scope.isDisabled = true;
                        	$scope.searchPlaceholder = "No Reportees";
                        	$scope.reportees = null;
                            /*if (result.error.status == 404) {
                                $scope.reportees = null;
                                $scope.error = 'No Records';
                            } else {
                                $scope.reportees = null;
                            }*/
                        } else if (result.data) {
                        	var reportees = result.data.plain();
                            $scope.reportees = (reportees.length) ? reportees : false;
                        }
                    }).finally(function () {
                        $scope.isLoading = false;
                    });
                } else {
                    $scope.reportees = null;
                    searchText = "";
                }
            };
            
	    	$scope.openDropdown = false;
            $scope.getDropdownIconClass = function () {
            	this.search = "";
                if (!$scope.openDropdown) {
                    $scope.openDropdown = true;
                    $scope.reportees = null;
                    return "arrow-down";
                }
                $scope.openDropdown = false;
                $scope.reportees = null;
                return "arrow-up";
            };

            // Close dropdown on clicking anywhere outside
            function closeWhenClickingElsewhere(event, callbackFn, parentClass) {

                var element = event.target;
                if (!element)
                    return;

                var clickedOnPopup = false;
                
                // Check up to 10 levels up the DOM tree
                for (var i = 0; i < 20 && element && !clickedOnPopup; i++) {
                    var elementClasses = element.classList;
                    if (elementClasses !== undefined && elementClasses.contains(parentClass)) {
                        clickedOnPopup = true;
                        break;
                    }
                    else {
                        element = element.parentElement;
                    }
                }

                if (!clickedOnPopup) {
                    //alert('inside callback!');
                    callbackFn();
                }
            }
            $window.onclick = function (event) {
                closeWhenClickingElsewhere(event, function () {
                    $scope.openDropdown = false;
                    $scope.reportees = null;
                    this.search = "";
                    $scope.$apply();
                }, 'landingbox1');
            };
            /****** Ajax smart table ends ************/
	    	
            // Triggered on selecting an user from dropdown to get his/her access details
	    	$scope.selectedItemChange = function (item) {
            	$scope.myAccess = {};
            	$scope.profile = {};
            	$scope.displayForm = false;
            	$scope.loadAccess = false;
            	
            	if (!angular.isUndefinedOrNull(item)) {
            		//sessionStorage.setItem('userAccessSelectedUser', angular.toJson(item));
            		//console.log('SelectedUser', item);
            		$scope.userDetails = item;
            		$scope.userId = item.id;
            		$scope.userDisplay = item.cn;
            		item.selected = true;
            		$scope.openDropdown = false;
            		$scope.loadAccessList = true;
            		$(".access-not-found").addClass("hide");
    	    	    $(".access-info-table").removeClass("hide");
    	    	    
                    // Get Selected User's Access Details on demand
                    AccessService.getCurrentAccessDetails($scope.userId, 'reportee', $scope).then(
                    	function(resp) {
                    		var accessDetails = resp.currentAccess;
	            			$scope.myAccess = !angular.isObjectEmpty(accessDetails) ? accessDetails : false;
	                    	//console.log('$scope.myAccess',$scope.myAccess);
	            			
	            			$scope.profile = resp.profile;
	            			//console.log('$scope.profile',$scope.profile);
	            			$scope.loadAccessList = false;
	            			$(".access-not-found").removeClass("hide");
	        	    	    $(".access-info-table").addClass("hide");
	            		},
	            		function (error) {
	            			console.log("Error with status code", error.status);
	            			$scope.loadAccessList = false;
							//$scope.error = error.statusText;
	            		}
	            	);
                }
            }
            
            /*if (sessionStorage.getItem('userAccessSelectedUser')!=null) {
            	var item = angular.fromJson(sessionStorage.getItem('userAccessSelectedUser'));
            	$scope.selectedItemChange(item);
            }*/
	    	
            // Resize Search box width as per viewport change
            function resizeAutocompleteBox () {
            	//console.log('Resizing...');
            	setTimeout(function(){
            		var $box = $('.search.user-access .auto-complete md-autocomplete');
                	$box.width('auto');
                	setTimeout(function(){
                		var searchbarWidth = $('.search.user-access').width();
                        //console.log('searchbarWidth',searchbarWidth);
                		$box.width(searchbarWidth);
                	},500);
            	});
            }
            //resizeAutocompleteBox();
            $scope.$watch('navMenuState', resizeAutocompleteBox);
            $(window).resize(resizeAutocompleteBox);
        });
    
    // Shared Controller for My Access/ Manage User Access pages
    AccessModule.controller('CurrentAccessController', 
		function ($scope, $rootScope, $state, $filter, $location, $q, Restangular, RefRestangular, RequestDetailsService, userAccessDetailsFactory, DeleteAccessService, AllReferenceDataService, SCROLLBAR_DIV_HEIGHT, EXCLUDE) {
    	
    		$scope.formFields = {};
			$scope.requestableName = "";
			$scope.EXCLUDE = EXCLUDE;
			
			// Get Current/Selected user's access details for the access clicked
			$scope.showAccessDetails = function(access, event) {
				//console.log('access',access);
				$scope.$parent.loadAccess = true; 
				$scope.$parent.displayForm = false;
				$scope.isLocked = false;
				
				// Movers logic
                $scope.isAuthorized = access.isAuthorized;
                $scope.updateAccess = access.updateAccess;
                
                $scope.$parent.selectedAccess = access;
				/*if(angular.isDefined($scope.$parent.selectedAccess)) {
					$scope.$parent.selectedAccess = access;
					sessionStorage.setItem('userAccessSelectedUserAccess',angular.toJson(access));
				}*/
				$scope.processMetaData = false;
				var requestableName = access['target_name-value'];
				//console.log('requestableName',requestableName);
				var accessDetailsObj = Restangular.one('users', access.value).get({'midas-target':requestableName});
				accessDetailsObj.then(function(accessDetails) {
						if(!angular.isUndefined(accessDetails.data)) {
							$scope.accessDetails = accessDetails.data.plain();
							$scope.requestableName = requestableName;
							$scope.processMetaData = true;
						}
					},function(response) {
						console.log("Error with status code", response.status);
					});
				
	    	    $(".app-table-in").find(".dlt-row").removeClass("active");
	    	    
	    	    if(event) {
	    	    	$(event.target).parent().addClass("active");
	    	    }
	    	    
	    	    $(".access-not-found").addClass("hide");
	    	    $(".access-info-table").removeClass("hide");
	    	};
		
	    	// Fetch All Reference Data for name-label mapping for display purpose
			AllReferenceDataService.getGlobalReferenceData().then(
	        		function (response) {
	        			$scope.globalReferenceData = response;
	        			//console.log('$scope.globalReferenceData',$scope.globalReferenceData);
						
	        		}, function (error) {
						console.log("Error with status code", response.status);
					}
	        );
			
			// Wait for User's Access details response
	    	$scope.$watch('processMetaData', function() {
				if (!$scope.processMetaData) { return; }
	    		
	    		/* Fetch form metadata */
	    		var metadataForm = Restangular.one('/config/idmprovider', 'snp.Form.' + $scope.requestableName).get();
				metadataForm.then(function (res) {
					var resData = angular.fromJson(res.data);
					if(!angular.isUndefined(resData)) {
						$scope.$parent.loadAccess = false;
						
						// Get form metadata fields of the access selected
						$scope.formFields = resData.elements;
						//StorageService.putData('formFields', $scope.formFields, STORAGE_TYPES.local);
						
						// Get Formatted Access details of the access selected to display in view
						$scope.$parent.displayForm = RequestDetailsService.getDisplayForm($scope.formFields,$scope.accessDetails,'access',false,$scope.globalReferenceData);
						
					}
				});
			});
	    	
	    	// Check if Access is locked
	    	$scope.checkIfAccessLocked = function () {
	    		var deferred = $q.defer();
	    		var isLocked = false;
	    		
	    		var currentAccessName = $scope.selectedAccess['target_name-value'];
	    		
	    		// Check status in local briefcase
                if (localStorage.getItem('brifcase.list') != null) {
                	var brifcaseList = angular.fromJson(localStorage.getItem('brifcase.list'));
                    //console.log('brifcaseList',brifcaseList);
                    //console.log('$scope.userDetails.id',$scope.userDetails.id);
                    brifcaseList.some(function (request) {
                        if (request.target==currentAccessName && request.owner.toLowerCase()==$scope.userDetails.id.toLowerCase()) {
                        	isLocked = true;
                        }
                    });
                }
                if (isLocked == true) {
                	deferred.resolve(isLocked);
                } else {
                	// Check status in requestable data
                	var objRequestables = {
                            "subjectName": $scope.userDetails.id,
                            "attributeName": "snp.refData.requestables.data",
                            "environmentVariables": {
//                                "returnAll": "Y", //only if you want all returned.
                                "requestedAccess": {
                                }
                            }
                        };
    	    		var getRequestablesPromise = RefRestangular.all("").post(objRequestables);
    	    		getRequestablesPromise.then(
                            function (res) {
                                //deferred.resolve(res);
                                var requestableData = res.data.plain().children;
                                //console.log('From API',requestableData);
                                
                                var currentAccessName = $scope.selectedAccess['target_name-value'];
                                if ($filter('filter')(requestableData, {'name':currentAccessName}, true).length) {
                                	var currentAccessDetails = $filter('filter')(requestableData, {'name':currentAccessName}, true)[0];
                                	if (angular.isDefined(currentAccessDetails.attributes.isLocked)) {
                                        if (!angular.equals(currentAccessDetails.attributes.isLocked, "")) {
                                        	isLocked = (currentAccessDetails.attributes.isLocked.toLowerCase()=="yes") ? true : false;
                                        }
                                    }
                                }
                                deferred.resolve(isLocked);
                            },
                            function (response) {
                                console.log("Error with status code", response.status);
                            }
                    );
                }
                return deferred.promise;
	    	};
	    	
	    	// Store access details in service and navigate to request.form for updating access
	    	$scope.updateAccessDetails = function () {
				userAccessDetailsFactory.reset();
	    		$scope.isLocked = false;
	    		$scope.disableAccessClick = true;
	    		
	    		// Check first if request is not locked already
				$scope.checkIfAccessLocked().then(
                        function (response) {
                        	$scope.isLocked = response;
                            
                            if ($scope.isLocked === false) {
								var userAccessData = {
									userDetails: $scope.$parent.userDetails,
									accessValue: $scope.$parent.selectedAccess['value'],
									accessTarget: $scope.$parent.selectedAccess['target_name-value'],
									accessType: $scope.$parent.selectedAccess['access_type'],
									accessKey: $scope.$parent.selectedAccess['access_key'],
									isMoverAuthorized: $scope.$parent.selectedAccess['isAuthorized'].toLowerCase()
								};
								if ($scope.requestId) {
									userAccessData.requestId = $scope.requestId;
								}
								//console.log('userAccessData',angular.toJson(userAccessData));
								userAccessDetailsFactory.set(userAccessData);
								$state.go('request.form');
							}
                        },
                        function (response) {
                            console.log("Error with status code", response.status);
                        }
                	).finally(function () {
                        $scope.disableAccessClick = false;
                    });
            };
            
            // Delete/Revoke access
            $scope.deleteAccessDetails = function ($event) {
            	$scope.isLocked = false;
            	$scope.disableAccessClick = true;
            	
            	// Check first if request is not locked already
				$scope.checkIfAccessLocked().then(
                        function (response) {
                        	//console.log('response',response);
                            $scope.isLocked = response;
                            if ($scope.isLocked === false) {
                            	$scope.openDeleteAccessDialog($event);
							}
                        },
                        function (response) {
                            console.log("Error with status code", response.status);
                        }
                ).finally(function () {
                    $scope.disableAccessClick = false;
                });
            };
            
            // Open dialog box on click of DELETE Access
            $scope.openDeleteAccessDialog = function ($event) {
            	DeleteAccessService.opendialog($event, $scope);
            };
            
            // Expand/Collapse Access categories
            $scope.accordion_dialog_toggle = function(event) {
	    	    //console.log($("body").find(".app-table-in").attr("id"));
	    	   
	    	    $(".app-table-in").find(".accordion-container").removeClass("SelectedAccordion");
	    	    $(event.target).parents(".accordion-container").addClass("SelectedAccordion");
	    	    var accordion = $(".app-table-in").find(".SelectedAccordion");
	    	    var accordionContent = accordion.next('.accordion-content');
	    	    var accordionToggleIcon = accordion.children('.toggle-icon');
	    	    var accordionToggleInfo = accordion.children('.toggle-info');
	
	    	    $(".app-table-in").find(".accordion-container").find(".accordion-toggle").removeClass("open");
	
	    	    $(".app-table-in").find(".accordion-container").find(".accordion-content").addClass("display-none");
	
	    	    $(".app-table-in").find(".accordion-container").find(".toggle-icon").html("<i class='icon-plus-sign'></i>");
	    	    $(".app-table-in").find(".accordion-container").find(".toggle-info").html("<span class='info-text'>Show Details</span>");
	    	    // toggle accordion link open class
	    	    // toggle accordion content
	    	    if($(".app-table-in").find(".SelectedAccordion").find(".accordion-content").hasClass("display-block"))
	    	    {
	    	        $(".app-table-in").find(".SelectedAccordion").find(".toggle-icon").html("<i class='icon-plus-sign'></i>");
	    	        var selectedAccordionContent = $(".app-table-in").find(".SelectedAccordion").find(".accordion-content");
	    	        selectedAccordionContent.removeClass("display-block").addClass("display-none");
	    	    }
	    	    else
	    	    {
	    	        $(".app-table-in").find(".SelectedAccordion").find(".toggle-icon").html("<i class='icon-minus-sign'></i>");
	    	        var selectedAccordionContent = $(".app-table-in").find(".SelectedAccordion").find(".accordion-content");
	    	        if (selectedAccordionContent.css('display') == 'none') {
	    	        	selectedAccordionContent.css("display","");
	    	        }
	    	        selectedAccordionContent.removeClass("display-none").addClass("display-block");
	    	    }
	    		
	    		if($("body").hasClass("certifications"))
	    		{
	    	        if ($(".content-wrapper").find(".certifications").find(".vertical-topalign").hasClass("hide")) {
	    	    		$(".content-wrapper").find(".certifications").find(".access-info-table").removeClass("hide");
	    	    		$(".content-wrapper").find(".certifications").find(".access-not-found").addClass("hide");
	    	        }
	    	        else {
	    	            return false;
	    	        }
	    		}
	    	};
	    	
	    	/*if (($rootScope.currentState=='access.user' || $rootScope.currentState=='access.current') 
	    			&& sessionStorage.getItem('userAccessSelectedUserAccess')!=null) {
	    		//$scope.accordion_dialog_toggle();
            	var item = angular.fromJson(sessionStorage.getItem('userAccessSelectedUserAccess'));
            	$scope.showAccessDetails(item);
            }*/
	    	
	    	$scope.readmoretext = function() {
	    	    $(".remaining_text").show();
	    	    $(".read_more").hide();
	    	    $(".less_more").show();
	    	};
	
	    	$scope.lessmoretext = function() {
	    	    $(".remaining_text").hide();
	    	    $(".read_more").show();
	    	    $(".less_more").hide();
	    	};
	    	    
	    	// Custom Scrollbar config
	        //$scope.scrollConfig = angular.scrollbarConfig(SCROLLBAR_DIV_HEIGHT.OFFSET);
	        
	    	// Resize window height on viewport change
	    	function resizePage () {
            	var page_height = $(window).height() - SCROLLBAR_DIV_HEIGHT.DEFAULT_SCROLL_OFFSET_INNER_PAGES;
            	//console.log('page_height',page_height);
                $('md-tab-content').height(page_height);
                $('.access-info-accordion').height(page_height);
                if ($rootScope.currentState=='access.current') {
                	var div_height = $(window).height() - SCROLLBAR_DIV_HEIGHT.DEFAULT_SCROLL_OFFSET_ACESSDETAILS;
                } else if ($rootScope.currentState=='access.user') {
                	var div_height = $(window).height() - SCROLLBAR_DIV_HEIGHT.DEFAULT_SCROLL_OFFSET_USERACESSDETAILS;
                }
                //console.log('div_height',div_height);
            	$('.access-details-content').height(div_height);
            }
	    	if ($rootScope.currentState=='access.current' || $rootScope.currentState=='access.user') {
	    		$(window).resize(resizePage);
	            setTimeout(resizePage,100);
	    	}
        });
    
    // Controller for History tab in My Access page
    AccessModule.controller('HistoryController', 
		function ($scope,AccessService,VIEW_PATH,SCROLLBAR_DIV_HEIGHT,_currentUser) {
    	
    		$scope.viewPath = VIEW_PATH.mainview + 'requests/dialog/';
    		$scope.currentUser = _currentUser.userId;
    		$scope.loadMore = true;
    		
    		// Load more results and append to existing History as we scroll down
    		$scope.more = function(){
    			if (!$scope.loadMore) {
    				return;
    			}
    			$scope.$parent.loadAccess = true; 
    			var recordsCount = $scope.$parent.historyPagination.count;
    			$scope.$parent.historyPagination.startIndex += recordsCount;
    			AccessService.getHistoryDetails($scope.currentUser, $scope.$parent.requestableName, $scope.$parent.historyPagination)
		    		.then(function(resp) {
		    			$scope.$parent.loadAccess = false;
		    			var newRequests = resp;
		    			if (!newRequests.length) {
		    				/*$scope.loadMore = false;
		    				$scope.$parent.resetHistoryPagination();*/
		    				$scope.$parent.historyPagination.startIndex -= recordsCount;
		    			} else {
		    				angular.forEach(newRequests, function(request){
			    				$scope.$parent.myHistory.push(request);
			    			});
			    			//console.log('$scope.$parent.myHistory',$scope.$parent.myHistory);
		    			}
		    			
		    		});
    		};
    	
    		$('.infinite-scroll').height( $(document).height() - SCROLLBAR_DIV_HEIGHT.OFFSET_INNER_PAGES );
    		
    		// Custom Scrollbar config
	        //$scope.scrollConfig = angular.scrollbarConfig(SCROLLBAR_DIV_HEIGHT.OFFSET_INNER_PAGES);
	        
        });
    
    // we create a simple directive to load contents as we scroll down (used in History)
    AccessModule.directive("whenScrolled", function(){
    	return{
	        restrict: 'A',
	        link: function(scope, elem, attrs){
	        
	          // we get a list of elements of size 1 and need the first element
	          raw = elem[0];
	        
	          // we load more elements when scrolled past a limit
	          elem.bind("scroll", function(){
	        	  
	        	  // position (offset) from bottom of container to trigger next event
		          var offset = 0;
		          
		          if(raw.scrollTop+raw.offsetHeight + offset >= raw.scrollHeight){
		        	  scope.loading = true;
	              
		        	  // we can give any function which loads more elements into the list
		        	  scope.$apply(attrs.whenScrolled);
		          }
	          });
	        }
    	}
    });
});
