define(['app','angularAMD'], function(app, AccessModule){
    
	// Service for getting Access/History data from back-end
	AccessModule.service('AccessService', function ($q,Restangular,RefRestangular,StorageService,EXCLUDE,REQUEST_STATUS,STORAGE_TYPES,INCLUDE,RequestDetailsService){
            var service = {};
            var self = this;
            //"use strict";
            
            service.getCurrentAccessDetails = function (user, accessFor, $scope) {
            	var deferred = $q.defer();
            	
            	$scope.requestableDataPromise = false;
            	var requestableData;
            	var useStorageService = false;
            	
            	/* NEW API call for RequestableName Start */
            	//StorageService.removeData('requestableStorage', STORAGE_TYPES.local, "");
                var requestableStorage = StorageService.getData('requestableStorage', STORAGE_TYPES.local, "");
                if (useStorageService && requestableStorage) {
                    requestableData = angular.fromJson(requestableStorage);
                    requestableData = angular.fromJson(requestableData.data);
                    //console.log('From Storage',requestableData);
                    $scope.requestableDataPromise = true;
                } else {
                	var objRequestables = {
                            "subjectName": user,
                            "attributeName": "snp.refData.requestables.data",
                            "environmentVariables": {
                                "returnAll":"Y",
                                "requestedAccess": {
                                }
                            }
                        };
                    var requestablePromise = RefRestangular.all("").post(objRequestables);
                    requestablePromise.then(
                            function (res) {
                                //deferred.resolve(res);
                                requestableData = res.data.plain();
                                //console.log('From API',requestableData);
                                StorageService.putData('requestableStorage', requestableData, STORAGE_TYPES.local);
                                $scope.requestableDataPromise = true;
                            },
                            function (response) {
                                console.log("Error with status code", response.status);
                            }
                    );
                }
            	
                // Wait for requestables data response
                var unwatchrequestableDataPromise = $scope.$watch('requestableDataPromise', function(newRequestableData,oldRequestableData){ 
                	if (newRequestableData === false) { return; }
                	
                	var userDetails = {
                		'currentAccess'	: {},
                		'profile' : {}
                	};
                	var isReportee = (accessFor && accessFor=='reportee') ? true : false;
                	var labelTypeMapping = [];
                	angular.forEach(requestableData.children, function (value, key) {
                    	var accessType, accessKey;
                    	
                        // Always fetch attribute "type" from requestableData if present, else fetch typeLabel for display
                        if(value.attributes.type){
                            accessType = value.attributes.type;
                        }else{
                        	accessType = value.attributes.typeLabel;
                        }
                        
                        // This will be used only for typeLabel mapping while updating access, and not for display
                        if(value.attributes.typeLabel){                               
                        	accessKey = value.attributes.typeLabel;
                        }else{                                
                        	accessKey = value.attributes.type;
                        }
                        
                    	//labelTypeMapping[value.name] = accessType;
                        labelTypeMapping[value.name] = {
                        		'accessType': accessType,
                        		'accessKey': accessKey,
                                'granted': value.attributes.granted
                        	};
                    });
                    //console.log('labelTypeMapping',labelTypeMapping);
                    
                	// Get User access data
                    var myAccess = Restangular.one('users', user);
                	myAccess.get().then(
            			function(response) {
    						if(!angular.isUndefined(response.data)) {
    							var myAccessDetails = response.data.plain();
    							userDetails.profile = myAccessDetails;
    							
    							var sortedAccounts = angular.sortByKey(myAccessDetails.accounts, 'category');
    							//console.log('User accounts',sortedAccounts);
    							sortedAccounts.forEach(function(access){
                                    
    								if (isReportee===true) {
    									// Don't show Reportee's Access, if it is Revoked 
    									if (access.status.toLowerCase() == REQUEST_STATUS.REVOKED) {
    										return;
    									}
    								}
    								var accessname = access['target_name-value'];
    								var categoryname = (labelTypeMapping[accessname] && labelTypeMapping[accessname].accessType) ? labelTypeMapping[accessname].accessType : 'undefined';
    								if(categoryname!='undefined' && EXCLUDE.CATALOGS.indexOf(categoryname.toLowerCase()) == -1 && access.status.toLowerCase() == REQUEST_STATUS.PROVISIONED.toLowerCase()){
    									access['access_type'] = categoryname;
    									access['access_key'] = labelTypeMapping[accessname].accessKey;
    									if (angular.isUndefined(userDetails.currentAccess[categoryname])){
    										userDetails.currentAccess[categoryname] = [];
    									}
                                        
                                        /* Logic of movers - starts */
                                        // Note: 'granted' false if user got access explicitly, still show in my access, but no modify (treat as DENY)
                                        if(!angular.isUndefined(access['isAuthorized'])){
                                          if(access['isAuthorized']==null){
                                                access['updateAccess'] = 'show';
                                                access['isAuthorized'] = 'PERMIT'; // null and PERMIT has same logic
                                            }else if((access['isAuthorized'].toLowerCase()=='violation' && labelTypeMapping[accessname].granted) || access['isAuthorized'].toLowerCase()=='permit') {
                                                access['updateAccess'] = 'show';
                                            }else if (access['isAuthorized'].toLowerCase()=='deny' || !labelTypeMapping[accessname].granted){
                                                access['updateAccess'] = 'hide';
                                                access['isAuthorized'] = 'deny';
                                            }else {
                                                access['updateAccess'] = 'show';
                                            }  
                                        }else{
                                            access['isAuthorized'] = 'PERMIT';
                                            access['updateAccess'] = 'show';
                                        }
                                        /* Logic of movers - ends */
                                        
    									userDetails.currentAccess[categoryname].push(access);
    								}
    							});
    							delete userDetails.profile.accounts;
    							deferred.resolve(userDetails);
    						}
    					},
                        function (error) {
                            console.log("Error with status code", error.status);
                        }
            		);
                	//deferred.resolve(userDetails);
                	unwatchrequestableDataPromise();
                });
            	return deferred.promise;
			};
            
            service.getHistoryDetails = function (user, requestableName, pagination) {
            	//console.log('pagination',pagination);
            	var deferred = $q.defer();
            	
            	var myHistoryFormatted = [];
            	var postdata = {
                        id: "requestForMe",
                        searchParameters: {
                        	"Operations.owner.value" : user
                        },
                        startIndex: pagination.startIndex,
                        count: pagination.count
                    };
            	
            	var historyPromise = Restangular.all('bulk/.search').post(postdata);
            	
            	historyPromise.then(
            		function(res) {
						if(!angular.isUndefined(res.data)) {
							myHistory = res.data.plain();
							if (myHistory.length>0) {
								//console.log('myHistory',myHistory);
								angular.forEach(myHistory, function(history){
									if (history.Operations && history.Operations.length) {
										var requestName = history.Operations[0].target;
										var requestDisplayName = (requestableName && requestableName[requestName]) ? requestableName[requestName].requestDisplayName : '---';
									} else {
										var requestName = '---';
										var requestDisplayName = '---';
									}
//									var requestName = history.Operations[0].target;
//									var requestDisplayName = requestableName[requestName].requestDisplayName;
                                    
                                    /* Get status to display */
                                    var historyStatus = RequestDetailsService.getAccessStatusText(history.status,history.Operations[0].method);
                                    
									var request = {
						                    "name": "Access to " + requestDisplayName,
						                    "id": history.id,
						                    "description": history.details.justification,
						                    "requestorName": history.requestor.display,
						                    "requestorId": history.requestor.value,
						                    "type": (requestableName && requestableName[requestName]) ? requestableName[requestName].resourceType : '---',
						                    "status": historyStatus,
						                    "dateRequested": history.details.created
						                };
									/*if (history.assignedTo) {
										history.assignedTo.reverse();
										var assignedArr = history.assignedTo[history.assignedTo.length - 1];
										request.assignedToType = assignedArr.category;	//Added for distinguishing betn user & group
										request.assignedTo = assignedArr.display ? assignedArr.display : assignedArr.value;
										request.dateAssigned = assignedArr.assignedOn;
									}*/
									myHistoryFormatted.push(request);
								});
							}
							deferred.resolve(myHistoryFormatted);
						}
		            }, function (response) {
		                console.log("Error with status code", response.status);
		            });
            	
            	return deferred.promise;
            };
            
            return service;
        });
	
	// Service for deleting/revoking access functionality
	AccessModule.service('DeleteAccessService', function ($state, $rootScope, $mdDialog, Restangular, VIEW_PATH) {
	        //var self = this;
	        var service = {};
	        service.opendialog = function ($event, $scope) {
	        	var viewPath = VIEW_PATH.mainview + 'access/dialog/delete-access-dialog.html';
	
	            $mdDialog.show({
	                controller: DialogCtrl,
	                scope: $scope,
	                preserveScope: true,
	                controllerAs: 'ctrl',
	                templateUrl: viewPath,
	                targetEvent: $event,
	                clickOutsideToClose: false
	            }).then(function (actionData) {
	                //$scope.comment = actionData;
	            }, function () {
	                //$scope.comment = '';
	            });
	            
	            function DialogCtrl() {
	                var self = this;
	                self.cancel = function ($event) {
	                    $mdDialog.cancel();
	                };
	                self.finish = function ($event) {
	                    $mdDialog.hide();
	                    service.processRequest($scope);
	                };
	            }
	        };
	        
	        /* Process request for Delete */
	        service.processRequest = function ($scope) {
	            var access = $scope.selectedAccess;
	        	var requestableName = access['target_name-value'];
	        	var postData = {
	        		    "details" :  {
	        		        "justification" : $scope.deleteJustification
	        		        },
	        		    "Operations": [
	        		        {
	        		            "method" : "DELETE",
	        		            "path":"/Users/" + access.value,
	        		            "target" : requestableName
	        		        }]
	        		};
	        	//console.log('postData',postData);
	        	var accessObj = Restangular.all('bulk');
	        	accessObj.post(postData).then(
	        		function(res) {
	        			localStorage.removeItem("inboxBulk");
	        			localStorage.removeItem("inboxTasks");
	        			$rootScope.requestId = res.data.id;
	        			$state.go('inbox.list', {'alertType':'delete_success'});
	        			// Show Message
	        			/*setTimeout(function () {
							$("#alert-delete-success").removeClass("hide");
							setTimeout(function () {
								$("#alert-delete-success").addClass("hide");
							}, 1500);
						}, 2000);*/
	        			
					},function(response) {
						console.log("There was an error in processing your request!");
					});
	        	
	        }; // EO service.processRequest()
	        
	        return service;
	    });
	
	// Getter-setter for access details of the access being edited
	AccessModule.factory('userAccessDetailsFactory', function ($q,Restangular,RefRestangular,EXCLUDE){
			
			var userAccessDetails = {};
	    	function set(data) {
	    		userAccessDetails = data;
	    	}
	    	function get() {
	    		return userAccessDetails;
	    	}
	    	function reset() {
	    		userAccessDetails = {};
	    	}
	    	return {
	            set: set,
	            get: get,
	            reset: reset
	        };
		
		});
});
