define(['app', 'angularAMD'], function (app, BriefcaseModule)
{
    BriefcaseModule.controller('BriefcaseController',
            function ($scope, $rootScope, $q, $state, $timeout, $mdDialog, BriefcaseService, VIEW_PATH, SCROLLBAR_DIV_HEIGHT)
            {
                $scope.myBriefcasePage = true;
                $scope.brifcaseList = angular.fromJson(localStorage.getItem('brifcase.list'));
                // In Queue the request to submit //
                $scope.arrInQueue = [];
                $scope.inQueueToSubmit = function (row) {
                    $scope.arrInQueue = BriefcaseService.inQueueToSubmit(row, $scope.arrInQueue);
                }

                // Resize window height on viewport change
                function resizePage() {
                    var page_height = $(window).height() - SCROLLBAR_DIV_HEIGHT.OFFSET_INNER_PAGES;
                    $('.content-panel-body').height(page_height);
                }
                $(window).resize(resizePage);
                $timeout(function () {
                    resizePage();
                }, 100);
                // Add to brifcase by call the REST Api // 
                var promises = [];
                $scope.submitBrifcase = function ()
                {
                    BriefcaseService.submitBrifcase($scope);

                    setTimeout(function () {
                        $scope.brifcaseList = angular.fromJson(localStorage.getItem('brifcase.list'));
                        $scope.brifcasePost = angular.fromJson(localStorage.getItem('brifcase.post'));
                        $rootScope.requestInBrifcaseCount = $scope.brifcaseList.length;
                    }, 1000);



                    $q.all(promises).then(
                            function (results) {
                                $rootScope.requestId = BriefcaseService.mergeRequest($scope.arrRequestId);
                                $state.go('inbox.list', {'alertType': 'newrequest_success'});
                                if (!angular.isUndefinedOrNull(localStorage.getItem('brifcase.list'))) {
                                    $rootScope.requestInBrifcaseCount = angular.fromJson(localStorage.getItem('brifcase.list')).length;
                                }
                            },
                            // error
                                    function (response) {
                                    }
                            );

                            /*setTimeout(function () {
                             $("#alert-briefcase-success").removeClass("hide");
                             //$("#apps").find(".mail-list-expanded").hide();
                             setTimeout(function () {
                             $("#alert-briefcase-success").addClass("hide");
                             }, 2500);
                             }, 4000);*/
                        };

                $scope.arrRequestId = [];
                $scope.submitFinalRequest = function (finaldata) {
                    promises.push(BriefcaseService.submitFinalRequest(finaldata, $scope));
                }

                $scope.removeFromBrifcase = function ($event) {
                    var viewPath = VIEW_PATH.mainview + 'requests/dialog/briefcase-delete.tmpl.html';
                    $mdDialog.show({
                        controller: DialogCtrl,
                        scope: $scope,
                        preserveScope: true,
                        controllerAs: 'ctrl',
                        templateUrl: viewPath,
                        targetEvent: $event,
                        clickOutsideToClose: false
                    }).then(function (actionData) {
                        //$scope.comment = actionData;
                    }, function () {
                        //$scope.comment = '';
                    });
                    ;
                    function DialogCtrl() {
                        var self = this;
                        self.cancel = function ($event) {
                            $mdDialog.cancel();

                        };
                        self.finish = function ($event) {
                            $mdDialog.hide();
                            BriefcaseService.removeFromBrifcase($scope);
                            setTimeout(function () {
                                $scope.brifcaseList = angular.fromJson(localStorage.getItem('brifcase.list'));
                                $scope.brifcasePost = angular.fromJson(localStorage.getItem('brifcase.post'));
                                $rootScope.requestInBrifcaseCount = $scope.brifcaseList.length;
                                $state.reload('briefcase');
                            }, 500);
                        };
                    }
                }


                //Mark the check boxes checked //
                $scope.checkAll = function () {
                    angular.forEach($scope.brifcaseList, function (item) {
                        item.Selected = true;
                    });

                };

            }
            );
        });
