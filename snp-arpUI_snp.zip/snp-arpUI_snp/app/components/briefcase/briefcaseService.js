define(['app', 'angularAMD'], function (app, BriefcaseModule) {

    BriefcaseModule.service('BriefcaseService',
            function (Restangular, $q, $mdDialog, $filter) {
                var service = {};
                service.inQueueToSubmit = function (row, arrInQueue) {
                    var index = arrInQueue.indexOf(row);
                    if (index == '-1') {
                        arrInQueue.push(row);
                    } else {
                        arrInQueue.splice(index, 1);
                    }
                    return arrInQueue;
                };
                service.submitFinalRequest = function (finaldata, $scope) {
                    var deferred = $q.defer();
                    Restangular.all("bulk").post(finaldata).then(
                            function (res) {
                                deferred.resolve(res);
                                $scope.arrRequestId.push(res.data.id);
                            }, function (response) {
                        console.log("Error with status code", response.status);
                        $mdDialog.show(
                                $mdDialog.alert()
                                .parent(angular.element(document.querySelector('#popupContainer')))
                                .clickOutsideToClose(true)
                                .title('ERROR!')
                                .content("Error with status code: " + response.status + " " + response.statusText + " > " + response.data.message)
                                .ariaLabel('New Request')
                                .ok('Ok')
                                );
                    });
                    return deferred.promise;
                };
                service.submitBrifcase = function ($scope) {
                    var arrbrifcaseList = [];
                    var arrbrifcasePost = [];
                    var brifcasePost = angular.fromJson(localStorage.getItem('brifcase.post'));
                    var brifcaseList = angular.fromJson(localStorage.getItem('brifcase.list'));
                    $scope.brifcasePost = angular.fromJson(brifcasePost);
                    $scope.brifcaseList = angular.fromJson(brifcaseList);


                    angular.forEach($scope.brifcasePost, function (postData) {
                        if ($scope.arrInQueue.length) {
                            if ($filter('filter')($scope.arrInQueue, {"uniqueRequestId": postData.uniqueRequestId}, true).length) {
                                var finaldata = angular.copy(postData);
                                delete finaldata['uniqueRequestId'];
                                $scope.submitFinalRequest(finaldata);

                            } else {
                                arrbrifcasePost.push(postData);
                                arrbrifcaseList.push($filter('filter')($scope.brifcaseList, {"uniqueRequestId": postData.uniqueRequestId}, true)[0]);
                            }
                        } else {
                            var finaldata = angular.copy(postData);
                            delete finaldata['uniqueRequestId'];
                            $scope.submitFinalRequest(finaldata);
                        }

                    })

                    localStorage.removeItem('brifcase.post');
                    localStorage.removeItem('brifcase.list');

                    localStorage.setItem('brifcase.post', angular.toJson(arrbrifcasePost));
                    localStorage.setItem('brifcase.list', angular.toJson(arrbrifcaseList));
                    if (!$scope.arrInQueue.length) {
                        $scope.checkAll();
                    }

                };

                service.removeFromBrifcase = function ($scope) {
                    var arrbrifcaseList = [];
                    var arrbrifcasePost = [];
                    //var arrInQueue = [];
                    var brifcasePost = angular.fromJson(localStorage.getItem('brifcase.post'));
                    var brifcaseList = angular.fromJson(localStorage.getItem('brifcase.list'));
                    $scope.brifcasePost = angular.fromJson(brifcasePost);
                    $scope.brifcaseList = angular.fromJson(brifcaseList);

                    if ($scope.arrInQueue.length) {
                        angular.forEach($scope.brifcasePost, function (postData) {
                            if (!$filter('filter')($scope.arrInQueue, {"uniqueRequestId": postData.uniqueRequestId}, true).length) {
                                arrbrifcasePost.push(postData);
                                arrbrifcaseList.push($filter('filter')($scope.brifcaseList, {"uniqueRequestId": postData.uniqueRequestId}, true)[0]);
                            } 

                        })
                    } else {
                        arrbrifcaseList = [];
                        arrbrifcasePost = [];
                        //arrInQueue = [];
                    }
                    $scope.arrInQueue = [];


                   

                    localStorage.removeItem('brifcase.post');
                    localStorage.removeItem('brifcase.list');

                    localStorage.setItem('brifcase.post', angular.toJson(arrbrifcasePost));
                    localStorage.setItem('brifcase.list', angular.toJson(arrbrifcaseList));


                }
                service.mergeRequest = function (arrRequestId) {
                    var strRequestId = "";
                    angular.forEach(arrRequestId, function (requestId) {
                        strRequestId += " #" + requestId + ","
                    })
                    return(strRequestId.substring(0, strRequestId.length - 1));
                };



                return service;
            });
});
