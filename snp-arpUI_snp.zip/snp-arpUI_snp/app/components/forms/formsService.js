define(['app', 'angularAMD'], function (app, formsModule)
{
//Form UtilityService to reuse the functionality    
    formsModule.service('FormUtilityService',
            [
                function () {
                    var self = this;
                    self.validIpAddress = function (value) {
                        return value && /(\d{1,3}\.){3}\d{1,3}/.test(value);
                    };
                    self.getRandomInt = function (min, max) {
                        return Math.floor(Math.random() * (max - min)) + min;
                    };
                    self.sortJson = function (arr) {
                        arr = arr.sort(function (a, b) {
                            return a.name > b.name;
                        })
                        for (var i = 0; i < arr.length; i++) {
                            if (arr[i].children) {
                                self.sortJson(arr[i].children)
                            }
                        }
                        return arr;
                    };
                    self.addRandomIds = function (fields, unique) {
                        unique++;
                        angular.forEach(fields, function (field, index) {
                            if (field.fieldGroup) {
                                self.addRandomIds(field.fieldGroup, unique);
                                return; // fieldGroups don't need an ID
                            }

                            if (field.templateOptions && field.templateOptions.fields) {
                                self.addRandomIds(field.templateOptions.fields, unique);
                            }

                            field.id = field.id || (field.key + '_' + index + '_' + unique + self.getRandomInt(0, 9999));
                        });
                    };


                }
            ]);



    formsModule.service('FormScopeService',
            [
                function () {
                    var self = this;
//its get called when you add new row in custom element "customaddtextbox,customaddselect,treedropdownselect"
                    self.addNew = function ($scope) {
                        $scope.model[$scope.options.key] = $scope.model[$scope.options.key] || [];
                        var customaddselect = $scope.model[$scope.options.key];
                        var lastSection = customaddselect[customaddselect.length - 1];
                        var newsection = {
                            value: ""
                        };
                        if (lastSection) {
                            newsection = angular.copy(lastSection);
                        }

                        //set the default value
                        var arrDefault = [];
                        if (angular.isDefined($scope.options.templateOptions.fields)) {
                            angular.forEach($scope.options.templateOptions.fields[0].fieldGroup, function (element) {
                                if (element.defaultValue && angular.equals(element.type, "hiddentext")) {
                                    arrDefault.push(element.key);
                                }
                            })
                        }


                        angular.forEach(newsection, function (val, key) {
                            if (arrDefault.indexOf(key) > -1) {
                                newsection[key] = val;
                            } else {
                                newsection[key] = '';
                            }

                        })
                        customaddselect.push(newsection);
                    };

//Set the tooltip to header icon
                    self.addTooltip = function ($scope, options) {
                        //Add header tooltip 
                        var header = "";
                        angular.forEach(options, function (data) {
                            if (!angular.isUndefinedOrNull(data.tooltip)) {
                                header += data.label + " : " + data.tooltip + "<br>";
                            }
                        })

                        //serach the drop down name in vm.field and add info to header
                        angular.forEach($scope.fields, function (element) {
                            if (angular.isDefined(element.data) && angular.isDefined(element.data.childKey)) {
                                if (angular.equals(element.data.childKey, $scope.options.key)) {
                                    if (!angular.equals(header, "")) {
                                        element.info = header;
                                    }

                                }
                            }
                        })
                    }
//Process the referenceData and reformat it
                    self.processReferenceData = function (referenceData) {
                        var options = [];
                        angular.forEach(referenceData, function (data) {
                            var item = {
                                "name": data.name,
                                "label": data.attributes.label,
                                "children": null,
                                "tooltip": data.attributes.tooltip
                            };
                            //console.log('data.children.length',data.children.length);
                            if (data.children && data.children.length > 0) {
                                //console.log('Pushing children...');
                                item.children = self.processReferenceData(data.children);
                            }

                            options.push(item);
                        });
                        return options;
                    };

                }
            ]);

    formsModule.factory('formFactory', function ($http, $filter, $q, FormUtilityService, FormScopeService) {

        var urlBase = 'app/components/forms/json/local/';
        var formFactory = {};
        formFactory.getFormData = function (state) {
            return $http.get(urlBase + state + '.json');
        };


//Formly service and custom elements
        formFactory.formlyService = function (formConfig, FORM_TEMPLATE, addParams, parentScope) {
            var deferred = $q.defer();
            var promises = [];
            //Sets the policy to model
            parentScope.vm.model.policyRole = parentScope.policyCode;

            formConfig.setWrapper({
                name: 'validation',
                types: ['input', 'customselect'],
                templateUrl: FORM_TEMPLATE.formvalidation,
            });
            // # MULTI SELECT DROP DOWN - CUSTOM # //
            formConfig.setType({
                name: 'multiselectdropdown',
                overwriteOk: true,
                templateUrl: FORM_TEMPLATE.multiselectdropdown,
                controller: function ($scope) {
                   // drop down logic here 
                }
            });
            // FormConfig and its verious parameters with scope
            formConfig.setType({
                name: 'appheader',
                overwriteOk: true,
                templateUrl: FORM_TEMPLATE.applicationheader,
                controller: function ($scope) {
                   // drop down logic here 
                    $scope.onExpandClicked = function (options, $event) {
                        $event.stopPropagation();
                        $scope.options.data.isExpanded = !$scope.options.data.isExpanded;

                        var searchedObj = $filter('filter')($scope.fields, {"key": $scope.options.data.childKey}, true);

                        searchedObj[0].hide = !searchedObj[0].hide;

                    };
                }
            });
            // # MULTI SELECT SINGLE BOX (SUPPORTS TREE LIST) - CUSTOM # //
            formConfig.setType({
                name: 'multiselectfullview',
                overwriteOk: true,
                templateUrl: FORM_TEMPLATE.multiselectfullview,
                controller: function ($scope, ARPService) {
                    
                    // validation code //
                   
                    $scope.$on('onSubmit', function (event, args) {
                         if(!$scope.options.data.submit)
                         $scope.options.data.submit = args.submit;
                    });

                    $scope.$watch("model." + $scope.options.key, function (newValue, oldValue) {
                        if (!angular.isUndefined(newValue)) {
                            var arrFilter = $filter('filter')($scope.fields, {"name": $scope.options.name}, true)[0];
                                if (arrFilter.templateOptions.required && newValue.length) {
                                     $scope.options.data.submit = true;
                                } else {
                                    if(angular.isDefined($scope.options.data.submit))
                                     $scope.options.data.submit = false;
                                }
                            }
                    }, true);                    
                    // validation code end//

                    var data = {"children": [{"children": [{"children": null, "name": "LOCRATINGS", "attributes": {"values": ["350", "440", "441"], "label": "LOC", "altLabel": "Structured Finance Ratings:LOC"}}, {"children": null, "name": "CORPSECRAT", "attributes": {"values": ["475"], "label": "Corporate Securitization", "altLabel": "Structured Finance Ratings:Corporate Securitization"}}, {"children": null, "name": "CDORAT", "attributes": {"values": ["474", "467", "442"], "label": "STRUCTURED CREDIT", "altLabel": "Structured Finance Ratings:Structured Credit"}}, {"children": null, "name": "ABSRAT", "attributes": {"values": ["349", "443", "444"], "label": "ABS", "altLabel": "Structured Finance Ratings:Asset-Backed Securities"}}, {"children": null, "name": "COVBONDSSF", "attributes": {"values": ["476"], "label": "Covered Bonds (SF)", "altLabel": "Structured Finance Ratings:Covered Bonds - SF"}}, {"children": null, "name": "SRVCREVAL", "attributes": {"values": ["454"], "label": "Servicer Evaluations", "altLabel": "Structured Finance Ratings:Servicer Evaluations"}}, {"children": null, "name": "ABCPRAT", "attributes": {"values": ["458"], "label": "ABCP", "altLabel": "Structured Finance Ratings:ABCP"}}, {"children": null, "name": "NEWASSTRAT", "attributes": {"values": ["477"], "label": "New Assets", "altLabel": "Structured Finance Ratings:New Assets"}}, {"children": null, "name": "CMBSRAT", "attributes": {"values": ["337", "450"], "label": "CMBS", "altLabel": "Structured Finance Ratings:CMBS"}}, {"children": null, "name": "RMBSRAT", "attributes": {"values": ["452", "345"], "label": "RMBS", "altLabel": "Structured Finance Ratings:RMBS"}}], "name": "SFRATINGS", "attributes": {"label": "Structured Finance Ratings", "altLabel": "Structured Finance Ratings"}}, {"children": [{"children": null, "name": "PUBLICFIN", "attributes": {"values": ["335", "309", "401", "404", "408", "410", "405", "419", "406", "407", "332", "402", "403", "319", "377", "330", "333", "310", "383"], "label": "Public Finance Ratings", "altLabel": "Corporate and Government Ratings:Public Finance Ratings"}}, {"children": null, "name": "INSURANCE", "attributes": {"values": ["374", "634", "635", "636", "637", "638", "473", "639", "516", "640", "641", "642", "409", "643", "609", "644", "471", "367", "382", "371"], "label": "Insurance Ratings", "altLabel": "Corporate and Government Ratings:Insurance Ratings"}}, {"children": [{"children": null, "name": "MANUFTRANS", "attributes": {"values": ["505", "517", "518", "568", "439", "567"], "label": "Manufacturing and Transportation", "altLabel": "Corporate and Government Ratings:Corporate Ratings:Manufacturing and Transportation"}}, {"children": null, "name": "COMMMATREA", "attributes": {"values": ["528", "506", "614", "527", "569"], "label": "Commodities - Materials - Real Estate", "altLabel": "Corporate and Government Ratings:Corporate Ratings:Commodities - Materials - Real Estate"}}, {"children": null, "name": "PROJECTFIN", "attributes": {"values": ["645"], "label": "Project Finance", "altLabel": "Corporate and Government Ratings:Corporate Ratings:Project Finance"}}, {"children": null, "name": "MIDMKTEVAL", "attributes": {"values": ["649"], "label": "Mid-Market Evaluations", "altLabel": "Corporate and Government Ratings:Corporate Ratings:Mid-Market Evaluations"}}, {"children": null, "name": "TECHMEDTEL", "attributes": {"values": ["501", "523", "524"], "label": "Technology - Media - Telecom", "altLabel": "Corporate and Government Ratings:Corporate Ratings:Technology - Media - Telecom"}}, {"children": null, "name": "CONSRETLHC", "attributes": {"values": ["513", "504", "503", "648"], "label": "Consumer - Retail - Healthcare", "altLabel": "Corporate and Government Ratings:Corporate Ratings:Consumer - Retail - Healthcare"}}, {"children": null, "name": "UTILINFRAS", "attributes": {"values": ["611", "525", "612", "526", "529", "373", "613", "615", "616", "386"], "label": "Utilities and Infrastructure", "altLabel": "Corporate and Government Ratings:Corporate Ratings:Utilities and Infrastructure"}}], "name": "CORPORATE", "attributes": {"label": "Corporate Ratings", "altLabel": "Corporate and Government Ratings:Corporate Ratings"}}, {"children": null, "name": "COVRDBONDS", "attributes": {"values": ["647"], "label": "Covered Bonds (CG)", "altLabel": "Corporate and Government Ratings:Covered Bonds (CG)"}}, {"children": null, "name": "FINSINSTIT", "attributes": {"values": ["617", "618", "619", "620", "621", "622", "623", "624", "625", "446", "626", "627", "628", "629", "630", "324", "445", "631", "632", "633", "447", "451", "355", "347", "380"], "label": "Financial Institutions Ratings", "altLabel": "Corporate and Government Ratings:Financial Institutions Ratings"}}, {"children": null, "name": "FUNDEVALS", "attributes": {"values": ["453", "375", "376", "348", "381"], "label": "Fund Ratings and Evaluations", "altLabel": "Corporate and Government Ratings:Fund Ratings and Evaluations"}}, {"children": null, "name": "INSLNKDSEC", "attributes": {"values": ["646"], "label": "Insurance Linked Securitizations", "altLabel": "Corporate and Government Ratings:Insurance Linked Securitizations"}}, {"children": null, "name": "SOVANDINTL", "attributes": {"values": ["326", "329", "370", "372", "384"], "label": "Sovereigns and Int-l Public Finance", "altLabel": "Corporate and Government Ratings:Sovereigns and Int-l Public Finance"}}], "name": "CGSRATINGS", "attributes": {"label": "Corporate and Government Ratings", "altLabel": "Corporate and Government Ratings"}}], "name": null, "attributes": null};
                    $scope.to.options = data.children;
                    var treePathByName = ARPService.getHierarchicalPaths($scope.to.options, "name");
                    var treePathByLabel = ARPService.getHierarchicalPaths($scope.to.options, "attributes.label");
                    var treePathNameLabel = ARPService.getHierarchicalPathNames($scope.to.options, 'name', 'attributes.label');
                    var arrPath = $scope.options.key.split("-");
                    var lastValue = arrPath[arrPath.length - 1];
                    localStorage.setItem('treedropdownModelByName-' + lastValue, angular.toJson(treePathByName));
                    localStorage.setItem('treedropdownModelByLabel-' + lastValue, angular.toJson(treePathByLabel));
                    localStorage.setItem('treedropdownModelByNameLabel-' + lastValue, angular.toJson(treePathNameLabel));
                }
            });
// # MULTI SELECT BOX - CUSTOM # //
            formConfig.setType({
                name: 'multiselect',
                overwriteOk: true,
                templateUrl: FORM_TEMPLATE.multiselect,
                controller: function ($scope, referenceDataFactory, ARPService) {
                    var multifield = $scope.options.templateOptions.key;
                    $scope.formOptions = {formState: $scope.formState};

                    //Process the referenceData data into multiselect plugin format
                    $scope.processMultiselect = function (options) {
                        //This is used for CORE application 
                        if (angular.isDefined($scope.options.data.watchKey)) {
                            $scope.$watch("options.templateOptions.options", function (newValue, oldValue) {
                                options = $scope.options.templateOptions.options;
                                $scope.multioptions = angular.copy($filter('filter')(options, {"name": "!" + $scope.model[$scope.options.data.watchKey]}));
                            });

                        } else {
                            $scope.multioptions = options;
                        }

                        $scope.$watch("multioptions", function (newValue, oldValue) {
                            if ($scope.multioptions.length) {
                                var treePathLabel = ARPService.getHierarchicalPaths(options, 'label');
                                var treePathName = ARPService.getHierarchicalPaths(options, 'name');
                                var treePathNameLabel = ARPService.getHierarchicalPathNames(options, 'name', 'label');

                                localStorage.setItem('multiselectModelLabel_' + multifield, angular.toJson(treePathLabel));
                                localStorage.setItem('multiselectModelName_' + multifield, angular.toJson(treePathName));
                                localStorage.setItem('multiselectModelNameLabel_' + multifield, angular.toJson(treePathNameLabel));

                                angular.keySort(options, 'label', false);

                                //Add header tooltip 
                                var header = "";
                                angular.forEach(options, function (data) {
                                    if (!angular.isUndefinedOrNull(data.tooltip)) {
                                        header += data.label + " : " + data.tooltip + "<br>";
                                    }
                                })

                                angular.forEach($scope.fields, function (element) {
                                    if (angular.isDefined(element.data) && angular.isDefined(element.data.childKey)) {
                                        if (angular.equals(element.data.childKey, $scope.options.key)) {
                                            if (!angular.equals(header, "")) {
                                                element.info = header;
                                            }

                                        }
                                    }
                                })
                                //Add header tooltip end
                                $scope.selectedOptions = {};
                                $scope.selectedOptions[$scope.options.key] = [];
                                if (angular.isUndefinedOrNull($scope.model[$scope.options.key])) {
                                    //console.log('No model value found');
                                    $scope.model[$scope.options.key] = [];
                                } else {
                                    //console.log('Multiselect Model', $scope.model[$scope.options.key]);
                                    angular.forEach($scope.model[$scope.options.key], function (modelelement) {
                                        //var searchObj = {name: modelelement[multifield]};
                                        //var searchObj = modelelement[multifield];
                                        var searchObj = ARPService.getElementFromPath(modelelement[multifield]);

                                        var filteredArray = $filter('filterTree')($scope.multioptions, searchObj, 'name', false);
                                        if (filteredArray.length) {
                                            //console.log('filteredArray',filteredArray);
                                            var selectedOptionName = filteredArray[0].name;
                                            var selectedOptionLabel = filteredArray[0].label;
                                            var selectedOptionChildren = filteredArray[0].children;
                                            var hashObject = {"isChecked": true};
                                            var objPush = {
                                                name: selectedOptionName,
                                                label: selectedOptionLabel,
                                                children: selectedOptionChildren,
                                                $treeView: hashObject
                                            };
                                            //console.log(modelelement[multifield] + '==' +selectedOptionName);
                                            $scope.selectedOptions[$scope.options.key].push(objPush);
                                            filteredArray[0].$treeView = hashObject;
                                        }
                                    });
                                }
                            }
                        })
                    }

//Loads the referenceData from API
                    $scope.loadMultiselect = function () {

                        if ($scope.options.data.refData) {
                            parentScope.formLoading = true;
                            var refPromise = referenceDataFactory.getData(addParams, $scope.options.data.refData);
                            refPromise.then(function (response) {
                                var resData = response.data.plain();
                                var options = FormScopeService.processReferenceData(resData.children);
                                //var options = [];
                                // Hide the header & multiselect if options is blank
                                if (Object.keys(options).length == 0) {
                                    angular.forEach($scope.fields, function (fieldElement) {
                                        fieldElement.hide = true;
                                    });
                                    //parentScope.requiredCheck = false;
                                    //parentScope.resetValidationVariables();
                                }
                                $scope.processMultiselect(options);

                            }).finally(function () {
                                parentScope.formLoading = false;
                                deferred.resolve(true);
                            });
                        }
                    }


                    if (angular.isDefined($scope.options.data.watchKey)) {
                        if (angular.isDefined($scope.model[$scope.options.data.watchKey])) {
                            $scope.$watch("model." + $scope.options.data.watchKey, function (newValue, oldValue) {
                                $scope.processMultiselect();
                            });
                        }

                    } else {
                        $scope.loadMultiselect();
                    }

                }
            });

            // # HEADER # //
            formConfig.setType({
                name: 'header',
                overwriteOk: true,
                templateUrl: FORM_TEMPLATE.formheader,
                controller: function ($scope, $rootScope, referenceDataFactory, ARPService) {
                   
                    if ($scope.options.data.refDataCore) {
                        parentScope.formLoading = true;
                        //Its get called in case of CORE application to show hide and assign referenceData to the "multiselect" and "customselect"
                        $scope.assignAndHideElement = function (resData) {
                            angular.forEach($scope.fields, function (element) {

                                if (angular.isDefined(element.fieldGroup)) {
                                    angular.forEach(element.fieldGroup, function (fieldElement) {
                                        if ($scope.options.data.loadCoreKey.indexOf(fieldElement.key) != '-1') {
                                            fieldElement.templateOptions.options = FormScopeService.processReferenceData(resData.children);
                                            // hide the multiselect header
                                            element.fieldGroup.some(function (element) {
                                                if (angular.isDefined(element.data.childKey) && angular.equals(element.data.childKey, fieldElement.key)) {
                                                    if (fieldElement.templateOptions.options.length <= 1) {
                                                        element.hide = true;
                                                        fieldElement.hide = true;
                                                    } else {
                                                        element.hide = false;
                                                        fieldElement.hide = false;
                                                    }
                                                }
                                            })

                                        }
                                    })
                                } else {
                                    if ($scope.options.data.loadCoreKey.indexOf(element.key) != '-1') {
                                        element.templateOptions.options = FormScopeService.processReferenceData(resData.children);
                                        // hide the customselect header & content
                                        if (element.templateOptions.options.length == 0) {
                                            $scope.fields.some(function (jsonElement) {
                                                if (angular.isDefined(jsonElement.data) && angular.isDefined(jsonElement.data.childKey) && angular.equals(jsonElement.data.childKey, element.key)) {
                                                    jsonElement.hide = true;
                                                    element.hide = true;
                                                }
                                            })
                                            $rootScope.primaryCoreRole = true;
                                        } else {
                                            $scope.fields.some(function (jsonElement) {
                                                if (angular.isDefined(jsonElement.data) && angular.isDefined(jsonElement.data.childKey) && angular.equals(jsonElement.data.childKey, element.key)) {
                                                    jsonElement.hide = false;
                                                    element.hide = false;
                                                }
                                            })
                                            $rootScope.primaryCoreRole = false;
                                        }
                                        var customselectNameLabel = ARPService.getHierarchicalPathNames(element.templateOptions.options, 'name', 'label');
                                        localStorage.setItem('customselectModelNameLabel_' + element.key, angular.toJson(customselectNameLabel));
                                    }
                                }

                            })
                        }
                        //Watch the questions radio key to fetch the dependent referenceData
                        //if (angular.isDefined($scope.model[$scope.options.data.radioKey])) {
                        $scope.$watch("model." + $scope.options.data.radioKey, function (newValue, oldValue) {

                            if (newValue != oldValue) {
                                var requestedAccess = {};

                                angular.forEach($scope.fields, function (fieldElement, Key) {
                                    if (angular.isDefined(fieldElement.data) && angular.isDefined(fieldElement.data.radioKey)) {
                                        requestedAccess[fieldElement.data.radioKey] = $scope.model[fieldElement.data.radioKey];
                                    }
                                    if (!angular.isUndefinedOrNull(oldValue) && angular.isDefined(fieldElement.data) && angular.isDefined(fieldElement.data.loadCoreKey)) {
                                        angular.forEach(fieldElement.data.loadCoreKey, function (loadValue) {
                                            delete $scope.model[loadValue];
                                        })

                                    }
                                })

                                //This is for the application CORE to deleting child if parent is having no value
                                if (angular.equals(requestedAccess[Object.keys(requestedAccess)[0]], 'no')) {
                                    if (!addParams.modeRequestId) {
                                        delete $scope.model[Object.keys(requestedAccess)[1]];
                                        delete $scope.model[Object.keys(requestedAccess)[2]];
                                    }

                                    delete requestedAccess[Object.keys(requestedAccess)[1]];
                                    delete requestedAccess[Object.keys(requestedAccess)[2]];
                                }

                                if (angular.equals(requestedAccess[Object.keys(requestedAccess)[1]], 'no')) {
                                    if (!addParams.modeRequestId) {
                                        delete $scope.model[Object.keys(requestedAccess)[2]];
                                    }

                                    delete requestedAccess[Object.keys(requestedAccess)[2]];
                                }


                                referenceDataFactory.getData(addParams, $scope.options.data.refDataCore, requestedAccess)
                                        .then(function (response) {
                                            var resData = response.data.plain();
                                            $scope.assignAndHideElement(resData);
                                        }).finally(function () {
                                    parentScope.formLoading = false;
                                    deferred.resolve(true);
                                });
                            }
                        })
                        //}
                    }
                    //if header element having attribute "refDataQuestion" 
                    if ($scope.options.data.refDataQuestion) {
                        parentScope.formLoading = true;
                        referenceDataFactory.getData(addParams, $scope.options.data.refDataQuestion)
                                .then(function (response) {
                                    var resData = response.data.plain();
                                    //Serach the question key in the API response
//                                    var searchedObj = $filter('filter')(resData.children, {"name": $scope.options.data.radioKey}, true);
//                                    if (searchedObj.length) {
                                    //check the question response is null if null show primary core role
                                    if (angular.isUndefinedOrNull(resData.children) && angular.isDefined($scope.options.data.refDataCore)) {

                                        referenceDataFactory.getData(addParams, $scope.options.data.refDataCore)
                                                .then(function (coreResponse) {
                                                    var resCoreData = coreResponse.data.plain();
                                                    $scope.assignAndHideElement(resCoreData);
                                                }).finally(function () {

                                        });
                                        //check the question response is not null but datacore is also null   
                                    } else if (!angular.isUndefinedOrNull(resData.children) && angular.isDefined($scope.options.data.refDataCore)) {

                                        // create a json to post with API
                                        var requestedAccess = {};
                                        angular.forEach($scope.fields, function (fieldElement, Key) {
                                            if (angular.isDefined(fieldElement.data) && angular.isDefined(fieldElement.data.radioKey)) {
                                                requestedAccess[fieldElement.data.radioKey] = $scope.model[fieldElement.data.radioKey];
                                            }
//                                            if (angular.isDefined(fieldElement.data) && angular.isDefined(fieldElement.data.loadCoreKey)) {
//                                                angular.forEach(fieldElement.data.loadCoreKey, function (loadValue) {
//                                                    delete $scope.model[loadValue];
//                                                })
//                                            }
                                        })

                                        referenceDataFactory.getData(addParams, $scope.options.data.refDataCore, requestedAccess)
                                                .then(function (coreResponse) {
                                                    var resCoreData = coreResponse.data.plain();
                                                    $scope.assignAndHideElement(resCoreData);
                                                    if (angular.isUndefinedOrNull(resCoreData.children)) {
                                                        angular.forEach($scope.fields, function (element) {
                                                            if ($scope.options.data.loadCoreKey.indexOf(element.key) != '-1') {
                                                                $scope.fields.some(function (jsonElement) {
                                                                    if (angular.isDefined(jsonElement.data) && angular.isDefined(jsonElement.data.childKey) && angular.equals(jsonElement.data.childKey, element.key)) {
                                                                        jsonElement.hide = true;
                                                                        element.hide = true;
                                                                    }
                                                                })
                                                            }
                                                        })

                                                    }
                                                }).finally(function () {

                                        });
                                    }

                                    var searchedObj = $filter('filter')(resData.children, {"name": $scope.options.data.radioKey}, true);

                                    $scope.options.name = angular.isUndefinedOrNull(searchedObj) ? "" : searchedObj[0].attributes.label;
                                    $scope.options.info = angular.isUndefinedOrNull(searchedObj) ? "" : searchedObj[0].attributes.label;

                                    if (!angular.isUndefinedOrNull(searchedObj)) {
                                        $scope.options.name = searchedObj[0].attributes.label;
                                        $scope.options.info = searchedObj[0].attributes.label;
                                    } else {
                                        $scope.options.hide = true;
                                        $scope.options.hideExpression = "true";
                                    }

                                    angular.forEach($scope.fields, function (fieldElement) {
                                        if (angular.equals(fieldElement.key, $scope.options.data.radioKey)) {
                                            if (!angular.isUndefinedOrNull(searchedObj)) {
                                                fieldElement.name = searchedObj[0].attributes.label;
                                            } else {
                                                fieldElement.hide = true;
                                                fieldElement.hideExpression = "true";
                                            }
                                        }
                                    })
//                                    } else {
//                                        //To hide the complete metadata element that are not found in API response
//                                        // For header
//                                        $scope.options.hide = true;
//                                        $scope.options.hideExpression = "!($scope.model[$scope.options.data.radioKey] && $scope.model[$scope.options.data.radioKey] =='yes')";
//                                        // For radio keys
//                                        $filter('filter')($scope.fields, {"key": $scope.options.data.radioKey}, true)[0].hide = true;
//                                        $filter('filter')($scope.fields, {"key": $scope.options.data.radioKey}, true)[0].hideExpression = "!($scope.model[$scope.options.data.radioKey] && $scope.model[$scope.options.data.radioKey] =='yes')";
//                                    }

                                }).finally(function () {
                            parentScope.formLoading = false;
                            deferred.resolve(true);
                        });

                    }
                    //if header element having attribute "refDataCrisil"
                    if ($scope.options.data.refDataCrisil) {
                        parentScope.formLoading = true;
                        $scope.model.hiddenFields = {};
                        $scope.model.hiddenFields['showCrisilQuestion'] = false;
                        referenceDataFactory.getData(addParams, $scope.options.data.refDataCrisil)
                                .then(function (response) {
                                    var resData = response.data.plain();
                                    //var resData = {"data":{"children":null,"name":null,"attributes":null}};
                                    resData = (resData.children && resData.children[0] && resData.children[0].attributes) ? resData.children[0].attributes : null;

                                    angular.forEach($scope.fields, function (fieldElement) {
                                        if (angular.equals(fieldElement.key, $scope.options.data.childKey)) {
                                            //$scope.options.label = "";
                                            $scope.options.name = "";
                                            if (resData && resData.label) {
                                                $scope.options.info = resData.label;
                                                $scope.options.name = resData.label;

                                                /*fieldElement.templateOptions.label = resData.label;
                                                 fieldElement.name = resData.label;*/
                                                fieldElement.hide = false;
                                                $scope.model.hiddenFields['showCrisilQuestion'] = true;

                                            } else {
                                                //$scope.options.hide = true;
                                                fieldElement.hide = true;
                                                $scope.options.hide = true;
                                            }
                                        }
                                    });

                                }).finally(function () {
                            parentScope.formLoading = false;
                            deferred.resolve(true);
                        });
                    }
                } // EO controller function
            });

            // # SIMPLE CHECKBOXES GROUP - CUSTOM # //
            formConfig.setType({
                name: 'customcheckbox',
                //extends: 'checkbox',
                overwriteOk: true,
                templateUrl: FORM_TEMPLATE.customcheckbox,
                controller: function ($scope, $rootScope, referenceDataFactory, ARPService) {
                    $scope.showHideForm = function (checked) {
                        //console.log('checked',checked);
                        var isChecked = false;
                        if (checked && !angular.isUndefined(checked)) {
                            isChecked = false;
                        } else {
                            isChecked = true;
                        }

                        if (!isChecked) {
                            var modelScopeKeys = $scope.options.data.modelScopeKeys;
                            for (var key in modelScopeKeys) {
                                var modelKey = modelScopeKeys[key];
                                if ($scope.model[modelKey]) {
                                    delete $scope.model[modelKey];
                                    //$scope.model[modelKey] = null;
                                }
                            }
                        }
                    }

                }
            });

            // # HEADER - CUSTOM : Used in KRA form # //
            formConfig.setType({
                name: 'mainheader',
                overwriteOk: true,
                templateUrl: FORM_TEMPLATE.formmainheader
            });

            // # FLAT SELECT DROPDOWN WITH ADD MORE FEATURE - CUSTOM # //
            var unique = 1;
            formConfig.setType({
                name: 'customaddselect',
                overwriteOk: true,
                templateUrl: FORM_TEMPLATE.customaddselect,
                controller: function ($scope) {
                    $scope.formOptions = {formState: $scope.formState};

                    $scope.copyFields = function (fields) {
                        fields = angular.copy(fields);
                        FormUtilityService.addRandomIds(fields, unique);
                        return fields;
                    };

                    $scope.addNew = function () {
                        FormScopeService.addNew($scope);
                    };

                }
            });
            
            
            // # 'LABEL' TO DISPLAY DYNAMIC VALUE AS READ ONLY IN FORM # //
            formConfig.setType({
                name: 'formdescription',
                overwriteOk: true,
                templateUrl: FORM_TEMPLATE.formdescription
            });
            formConfig.setType({
                name: 'forminformation',
                overwriteOk: true,
                templateUrl: FORM_TEMPLATE.forminformation
            });
            formConfig.setType({
                name: 'label',
                overwriteOk: true,
                templateUrl: FORM_TEMPLATE.customlabel,
                controller: function ($scope, referenceDataFactory) {
                    $scope.model[$scope.options.key] = $scope.options.info;
                    if ($scope.options.data) {
                        if ($scope.options.data.refData) {
                            parentScope.formLoading = true;
                            referenceDataFactory.getData(addParams, $scope.options.data.refData)
                                    .then(function (response) {
                                        var resData = response.data.plain();
                                        var labelDisplay = resData.children[0].attributes.label;
                                        var labelValue = resData.children[0].name;
                                        //$scope.options.name = labelDisplay;
                                        $scope.options.info = labelDisplay;
                                        if ($scope.options.data.addToModel && $scope.options.data.addToModel === true) {
                                            $scope.model[$scope.options.key] = labelValue;
                                            localStorage.setItem('customLabel-' + $scope.options.key, angular.toJson(labelDisplay));
                                        }
                                    }).finally(function () {
                                parentScope.formLoading = false;
                                deferred.resolve(true);
                            });
                        }
                        else if ($scope.options.data.showTooltipFromField) {
                            var tooltipField = $scope.options.data.showTooltipFromField;
                            var accessCategoryData = angular.fromJson(localStorage.getItem('multicheckboxLabel-' + tooltipField));
                            //console.log('accessCategoryData',accessCategoryData);
                            var optionName = $scope.options.key.split('-')[0];
                            if ($filter('filter')(accessCategoryData, {"name": optionName}, true).length) {
                                var arrFilter = $filter('filter')(accessCategoryData, {"name": optionName}, true)[0];
                                //$scope.options.name = arrFilter.tooltip;
                                $scope.options.info = arrFilter.tooltip;
                            }
                        }

                    }

                }
            });

            formConfig.setType({
                name: 'customselect',
                overwriteOk: true,
                templateUrl: FORM_TEMPLATE.customselect,
                controller: /* @ngInject */ function ($scope, referenceDataFactory, ARPService) {
                    addParams.field = $scope.options.key;
                    if ($scope.options.data.refData) {
                        parentScope.formLoading = true;
                        referenceDataFactory.getData(addParams, $scope.options.data.refData)
                                .then(function (response) {
                                    var customselectField = $scope.options.key;
                                    var resData = response.data.plain();
                                    $scope.to.options = FormScopeService.processReferenceData(resData.children);
                                    //$scope.to.options = [];
                                    var customselectNameLabel = ARPService.getHierarchicalPathNames($scope.to.options, 'name', 'label');
                                    //console.log('customselectNameLabel',customselectNameLabel);
                                    localStorage.setItem('customselectModelNameLabel_' + customselectField, angular.toJson(customselectNameLabel));
                                    if (!$scope.model[customselectField] && angular.isDefined($scope.options.data.showFirstSelected)
                                            && $scope.options.data.showFirstSelected === true && $scope.to.options[0]) {
                                        $scope.model[customselectField] = $scope.to.options[0].name;
                                    }
                                    FormScopeService.addTooltip($scope, $scope.to.options);

                                    // If Api returns empty response, then hide the customselect field along with its label 
                                    if (!$scope.to.options.length && $scope.options.data && $scope.options.data.hideWhenNoOptions) {
                                        $scope.options.hide = true;
                                        $scope.options.hideExpression = "true";
                                        angular.forEach($scope.fields, function (fieldElement) {
                                            //if (fieldElement.data && fieldElement.data.hideWhenNoOptions) {
                                            if (angular.equals($scope.options.key, fieldElement.data.childKey)) {
                                                fieldElement.hide = true;
                                                fieldElement.hideExpression = "true";
                                            }
                                            //}
                                        });
                                    }

                                }).finally(function () {
                            parentScope.formLoading = false;
                            deferred.resolve(true);
                        });

                        $scope.$watch("model." + $scope.options.key, function (newValue, oldValue) {
                            /*The below source is for CDOCFE spectator*/
                            // Concating 's' means creating dynamic variable from metadata 
                            if (angular.equals(addParams.application, "CDOCFE") && angular.isDefined(newValue) && angular.isDefined($scope.options.data.modelScopeKeys)) {
                                if (angular.equals($scope.model[$scope.options.key], Object.keys($scope.options.data.modelScopeKeys)[0])) {
                                    /* if selected value is spectator */
                                    if (addParams.modeRequestId) {
                                        if (angular.isDefined(parentScope.patchModel[Object.keys($scope.options.data.modelScopeKeys)[0] + 's'])) {
                                            $scope.model[Object.keys($scope.options.data.modelScopeKeys)[0] + 's'] = parentScope.patchModel[Object.keys($scope.options.data.modelScopeKeys)[0] + 's'];
                                        } else {
                                            var optionKey = {};
                                            if (angular.isUndefined($scope.model[Object.keys($scope.options.data.modelScopeKeys)[0] + 's'])) {
                                                $scope.model[Object.keys($scope.options.data.modelScopeKeys)[0] + 's'] = [optionKey]
                                            }

                                        }
                                    } else {
                                        var optionKey = {};
                                        if (angular.isUndefined($scope.model[Object.keys($scope.options.data.modelScopeKeys)[0] + 's'])) {
                                            $scope.model[Object.keys($scope.options.data.modelScopeKeys)[0] + 's'] = [optionKey]
                                        }


                                    }

                                } else {

                                    /* if selected value is other than spectator */
                                    if (addParams.modeRequestId) {
                                        if (angular.isDefined(parentScope.patchModel[Object.keys($scope.options.data.modelScopeKeys)[0]])) {
                                            $scope.model[parentScope.patchModel[Object.keys($scope.options.data.modelScopeKeys)[0]]];
                                        } else {
                                            var optionKey = {};
                                            if (angular.isDefined($scope.model[Object.keys($scope.options.data.modelScopeKeys)[0] + 's'])) {
                                                $scope.model[Object.keys($scope.options.data.modelScopeKeys)[0] + 's'] = [optionKey]
                                            }
                                        }

                                    } else {
                                        delete $scope.model[Object.keys($scope.options.data.modelScopeKeys)[0] + 's'];
                                    }

                                }
                            }

                        }, true);

                    }
                }
            });

            formConfig.setType({
                name: 'treedropdown',
                overwriteOk: true,
                templateUrl: FORM_TEMPLATE.treedropdown,
                controller: /* @ngInject */ function ($scope, $rootScope, referenceDataFactory, ARPService) {

                    // validation code //
                    
                    
                    $scope.$on('onSubmit', function (event, args) {
                        if(!$scope.options.data.submit)
                         $scope.options.data.submit = args.submit;
                    });

                    $scope.$watch("model." + $scope.options.key, function (newValue, oldValue) {
                       if (!angular.isUndefined(newValue)) {
                            var arrFilter = $filter('filter')($scope.fields, {"name": $scope.options.name}, true)[0];
                            if (arrFilter.templateOptions.required) {
                                if (newValue.length) {
                                     $scope.options.data.submit = true;

                                } else {
                                     $scope.options.data.submit = false;

                                }
                            }
                        }



                    }, true);
                    // validation code end//

                    $scope.formOptions = {formState: $scope.formState};
                    $scope.to.displayLabel = "Select " + $scope.to.label;
                    addParams.field = $scope.options.key;

                    //---------------DEMO CODE-------------------------//
                    var data = {"children": [{"children": [{"children": null, "name": "LOCRATINGS", "attributes": {"values": ["350", "440", "441"], "label": "LOC", "altLabel": "Structured Finance Ratings:LOC"}}, {"children": null, "name": "CORPSECRAT", "attributes": {"values": ["475"], "label": "Corporate Securitization", "altLabel": "Structured Finance Ratings:Corporate Securitization"}}, {"children": null, "name": "CDORAT", "attributes": {"values": ["474", "467", "442"], "label": "STRUCTURED CREDIT", "altLabel": "Structured Finance Ratings:Structured Credit"}}, {"children": null, "name": "ABSRAT", "attributes": {"values": ["349", "443", "444"], "label": "ABS", "altLabel": "Structured Finance Ratings:Asset-Backed Securities"}}, {"children": null, "name": "COVBONDSSF", "attributes": {"values": ["476"], "label": "Covered Bonds (SF)", "altLabel": "Structured Finance Ratings:Covered Bonds - SF"}}, {"children": null, "name": "SRVCREVAL", "attributes": {"values": ["454"], "label": "Servicer Evaluations", "altLabel": "Structured Finance Ratings:Servicer Evaluations"}}, {"children": null, "name": "ABCPRAT", "attributes": {"values": ["458"], "label": "ABCP", "altLabel": "Structured Finance Ratings:ABCP"}}, {"children": null, "name": "NEWASSTRAT", "attributes": {"values": ["477"], "label": "New Assets", "altLabel": "Structured Finance Ratings:New Assets"}}, {"children": null, "name": "CMBSRAT", "attributes": {"values": ["337", "450"], "label": "CMBS", "altLabel": "Structured Finance Ratings:CMBS"}}, {"children": null, "name": "RMBSRAT", "attributes": {"values": ["452", "345"], "label": "RMBS", "altLabel": "Structured Finance Ratings:RMBS"}}], "name": "SFRATINGS", "attributes": {"label": "Structured Finance Ratings", "altLabel": "Structured Finance Ratings"}}, {"children": [{"children": null, "name": "PUBLICFIN", "attributes": {"values": ["335", "309", "401", "404", "408", "410", "405", "419", "406", "407", "332", "402", "403", "319", "377", "330", "333", "310", "383"], "label": "Public Finance Ratings", "altLabel": "Corporate and Government Ratings:Public Finance Ratings"}}, {"children": null, "name": "INSURANCE", "attributes": {"values": ["374", "634", "635", "636", "637", "638", "473", "639", "516", "640", "641", "642", "409", "643", "609", "644", "471", "367", "382", "371"], "label": "Insurance Ratings", "altLabel": "Corporate and Government Ratings:Insurance Ratings"}}, {"children": [{"children": null, "name": "MANUFTRANS", "attributes": {"values": ["505", "517", "518", "568", "439", "567"], "label": "Manufacturing and Transportation", "altLabel": "Corporate and Government Ratings:Corporate Ratings:Manufacturing and Transportation"}}, {"children": null, "name": "COMMMATREA", "attributes": {"values": ["528", "506", "614", "527", "569"], "label": "Commodities - Materials - Real Estate", "altLabel": "Corporate and Government Ratings:Corporate Ratings:Commodities - Materials - Real Estate"}}, {"children": null, "name": "PROJECTFIN", "attributes": {"values": ["645"], "label": "Project Finance", "altLabel": "Corporate and Government Ratings:Corporate Ratings:Project Finance"}}, {"children": null, "name": "MIDMKTEVAL", "attributes": {"values": ["649"], "label": "Mid-Market Evaluations", "altLabel": "Corporate and Government Ratings:Corporate Ratings:Mid-Market Evaluations"}}, {"children": null, "name": "TECHMEDTEL", "attributes": {"values": ["501", "523", "524"], "label": "Technology - Media - Telecom", "altLabel": "Corporate and Government Ratings:Corporate Ratings:Technology - Media - Telecom"}}, {"children": null, "name": "CONSRETLHC", "attributes": {"values": ["513", "504", "503", "648"], "label": "Consumer - Retail - Healthcare", "altLabel": "Corporate and Government Ratings:Corporate Ratings:Consumer - Retail - Healthcare"}}, {"children": null, "name": "UTILINFRAS", "attributes": {"values": ["611", "525", "612", "526", "529", "373", "613", "615", "616", "386"], "label": "Utilities and Infrastructure", "altLabel": "Corporate and Government Ratings:Corporate Ratings:Utilities and Infrastructure"}}], "name": "CORPORATE", "attributes": {"label": "Corporate Ratings", "altLabel": "Corporate and Government Ratings:Corporate Ratings"}}, {"children": null, "name": "COVRDBONDS", "attributes": {"values": ["647"], "label": "Covered Bonds (CG)", "altLabel": "Corporate and Government Ratings:Covered Bonds (CG)"}}, {"children": null, "name": "FINSINSTIT", "attributes": {"values": ["617", "618", "619", "620", "621", "622", "623", "624", "625", "446", "626", "627", "628", "629", "630", "324", "445", "631", "632", "633", "447", "451", "355", "347", "380"], "label": "Financial Institutions Ratings", "altLabel": "Corporate and Government Ratings:Financial Institutions Ratings"}}, {"children": null, "name": "FUNDEVALS", "attributes": {"values": ["453", "375", "376", "348", "381"], "label": "Fund Ratings and Evaluations", "altLabel": "Corporate and Government Ratings:Fund Ratings and Evaluations"}}, {"children": null, "name": "INSLNKDSEC", "attributes": {"values": ["646"], "label": "Insurance Linked Securitizations", "altLabel": "Corporate and Government Ratings:Insurance Linked Securitizations"}}, {"children": null, "name": "SOVANDINTL", "attributes": {"values": ["326", "329", "370", "372", "384"], "label": "Sovereigns and Int-l Public Finance", "altLabel": "Corporate and Government Ratings:Sovereigns and Int-l Public Finance"}}], "name": "CGSRATINGS", "attributes": {"label": "Corporate and Government Ratings", "altLabel": "Corporate and Government Ratings"}}], "name": null, "attributes": null};
                    $scope.to.options = data.children;
                    var arrPath = $scope.options.key.split("-");
                    var lastValue = arrPath[arrPath.length - 1];
                    var treePathByName = ARPService.getHierarchicalPaths($scope.to.options, "name");
                    var treePathByLabel = ARPService.getHierarchicalPaths($scope.to.options, "attributes.label");
                    var treePathNameLabel = ARPService.getHierarchicalPathNames($scope.to.options, 'name', 'attributes.label');
                    localStorage.setItem('treedropdownModelByName-' + lastValue, angular.toJson(treePathByName));
                    localStorage.setItem('treedropdownModelByLabel-' + lastValue, angular.toJson(treePathByLabel));
                    localStorage.setItem('treedropdownModelByNameLabel-' + lastValue, angular.toJson(treePathNameLabel));
                    setTimeout(function () {
                        $(".tree-view").css('width', Math.round($('.dropdown-control').innerWidth() - 10));
                    }, 500);
                    parentScope.formLoading = false;
                    deferred.resolve(true);
                    //--------------DEMO CODE END-------------------------//                
                    //isExpanded is used to detect if it is new entry for tree drop down and if defined means revised case
//                    if ($scope.options.data.refData && (angular.isUndefinedOrNull($scope.model[$scope.options.key]) || angular.isUndefinedOrNull($scope.model[$scope.options.key].isExpanded))) {
//                        parentScope.formLoading = true;
//                        referenceDataFactory.getData(addParams, $scope.options.data.refData)
//                                .then(function (response) {
//
//                                    if (angular.isUndefinedOrNull(response.data)) {
//                                        $scope.options.templateOptions.disabled = true;
//                                    }
//                                    var resData = response.data.plain();
//
//                                    $scope.to.options = resData.children;
//
//                                    var arrPath = $scope.options.key.split("-");
//                                    var lastValue = arrPath[arrPath.length - 1];
//
//
//                                    var treePathByName = ARPService.getHierarchicalPaths($scope.to.options, "name");
//                                    var treePathByLabel = ARPService.getHierarchicalPaths($scope.to.options, "attributes.label");
//                                    var treePathNameLabel = ARPService.getHierarchicalPathNames($scope.to.options, 'name', 'attributes.label');
//                                    localStorage.setItem('treedropdownModelByName-' + lastValue, angular.toJson(treePathByName));
//                                    localStorage.setItem('treedropdownModelByLabel-' + lastValue, angular.toJson(treePathByLabel));
//                                    localStorage.setItem('treedropdownModelByNameLabel-' + lastValue, angular.toJson(treePathNameLabel));
//
//                                }).finally(function () {
//
//                            if (angular.isArray($scope.model[$scope.options.key]) && addParams.modeRequestId) {
//                                if ($scope.model[$scope.options.key].isExpanded) {
//                                    $scope.options.templateOptions.disabled = true;
//                                } else {
//                                    $scope.options.templateOptions.disabled = false;
//                                }
//                            } else {
//                                $scope.options.templateOptions.disabled = false;
//                            }
//
//                            setTimeout(function () {
//                                $(".tree-view").css('width', Math.round($('.dropdown-control').innerWidth() - 10));
//                            }, 1000);
//                            parentScope.formLoading = false;
//                            deferred.resolve(true);
//                        });
//                    } else {
//                        if (angular.isArray($scope.model[$scope.options.key]) && addParams.modeRequestId) {
//                            if ($scope.model[$scope.options.key].isExpanded) {
//                                $scope.options.templateOptions.disabled = true;
//                            } else {
//                                $scope.options.templateOptions.disabled = false;
//                            }
//                        } else {
//                            $scope.options.templateOptions.disabled = false;
//                        }
//
//                        setTimeout(function () {
//                            $(".tree-view").css('width', Math.round($('.dropdown-control').innerWidth() - 10));
//                        }, 1000);
//                        parentScope.formLoading = false;
//                        deferred.resolve(true);
//                    }
                }
            });

            formConfig.setType({
                name: 'multicheckbox',
                overwriteOk: true,
                templateUrl: FORM_TEMPLATE.multicheckbox,
                controller: /* @ngInject */ function ($scope, $timeout, $rootScope, referenceDataFactory, ROLE_REQUESTABLE, ARPService) {
                    function chunk(arr, size) {
                        var newArr = [];
                        for (var i = 0; i < arr.length; i += size) {
                            newArr.push(arr.slice(i, i + size));
                        }
                        return newArr;
                    }
                    function smallFirstLetter(string) {
                        return string.charAt(0).toLowerCase() + string.slice(1);
                    }
                    $scope.chunkedData = chunk($scope.to.options, 3);
                    localStorage.setItem('multicheckboxLabel-' + $scope.options.key, angular.toJson($scope.to.options));
                    var treePathNameLabel = ARPService.getHierarchicalPathNames($scope.to.options, 'name', 'label');
                    localStorage.setItem('multicheckboxModelByNameLabel-' + $scope.options.key, angular.toJson(treePathNameLabel));
                    //Check the required or not  and assign requiredCheck to true
//                    if (angular.isDefined($scope.model[$scope.options.key])) {
//                        var arrFilter = $filter('filter')($scope.fields, {"type": "multicheckbox"}, true)[0];
//                        angular.forEach($scope.fields, function (fieldElement) {
//                            if (angular.isDefined(fieldElement.data) && angular.equals(arrFilter.key, fieldElement.data.childKey)) {
//                                if (fieldElement.required) {
//                                    var arrFalse = [];
//                                    angular.forEach($scope.model[$scope.options.key], function (multicheckboxVal, multicheckboxKey) {
//                                        if (multicheckboxVal == true) {
//                                            arrFalse.push(multicheckboxVal);
//                                        }
//                                    })
//
//                                    if (arrFalse.length) {
//                                        $rootScope.requiredCheck = false;
//                                    } else {
//                                        $rootScope.requiredCheck = true;
//                                    }
//
//                                }
//                            }
//                        })
//                    } else {
//                        var arrFilter = $filter('filter')($scope.fields, {"type": "multicheckbox"}, true)[0];
//                        angular.forEach($scope.fields, function (fieldElement) {
//                            if (angular.isDefined(fieldElement.data) && angular.equals(arrFilter.key, fieldElement.data.childKey)) {
//                                if (fieldElement.required) {
//                                    $rootScope.requiredCheck = true;
//                                }
//                            }
//                        })
//                    }


                    $scope.appName = addParams.application;

                    if ($scope.options.data.refData) {
                        parentScope.formLoading = true;
                        if (angular.equals($scope.options.data.refData, 'dynamic')) {
                            //$scope.options.data.refData = "snp.refData.roles." + ROLE_REQUESTABLE[parentScope.policyCode] + "Roles.data";
                            $scope.options.data.refData = "snp.refData.roles.analyticalRoles.data"; // Business Rule: Analytical Roles form will be available ONLY to analytical Policy Role
                        }
                        referenceDataFactory.getData(addParams, $scope.options.data.refData)
                                .then(function (response) {
                                    var resData = response.data.plain();
                                    $scope.to.options = FormScopeService.processReferenceData(resData.children);
                                    $scope.chunkedData = chunk($scope.to.options, 3);
                                    localStorage.setItem('multicheckboxLabel-' + $scope.options.key, angular.toJson($scope.to.options));
                                    var treePathNameLabel = ARPService.getHierarchicalPathNames($scope.to.options, 'name', 'label');
                                    localStorage.setItem('multicheckboxModelByNameLabel-' + $scope.options.key, angular.toJson(treePathNameLabel));

                                }).finally(function () {

                            parentScope.formLoading = false;
                            deferred.resolve(true);
                        });
                    }


//Its get called when event triggers on multicheckbox
                    $scope.showHideForm = function (option, checked) {
                        var isChecked = false;
                        if (checked && !angular.isUndefined(checked)) {
                            isChecked = false;
                        } else {
                            isChecked = true;
                        }


                        $scope.$watch("model." + $scope.options.key, function (newValue, oldValue) {
                            var arrFalse = [];
                            angular.forEach(newValue, function (multicheckboxVal, multicheckboxKey) {
                                if (multicheckboxVal == true) {
                                    arrFalse.push(multicheckboxVal);
                                }
                            })

                            var arrFilter = $filter('filter')($scope.fields, {"name": $scope.options.name}, true)[0];
                            if (arrFilter.templateOptions.required) {
                                if (!arrFalse.length) {
                                    //arrFilter.formControl.$modelValue = "true";
                                    arrFilter.formControl.$error = {
                                        "required": true
                                    }
                                    arrFilter.formControl.$valid = false;
                                    arrFilter.formControl.$invalid = true;
                                } else {
                                    arrFilter.formControl.$error = {};
                                    arrFilter.formControl.$valid = true;
                                    arrFilter.formControl.$invalid = false;

                                }
                            }


                        }, true);







                    }
                    $scope.showHideFormOld = function (option, checked) {


                        var optionName = option.name;
                        var disabled = option.disable;
                        /* KRA Logic*/
                        if (disabled) {
                            return true;
                        }
                        var isChecked = false;
                        if (checked && !angular.isUndefined(checked)) {
                            isChecked = false;
                        } else {
                            isChecked = true;
                        }


                        if (angular.equals($scope.appName, "analyticalRoles")) {
                            if (isChecked) {
                                if (addParams.modeRequestId && parentScope.patchModel) {
                                    //console.log('parentScope.patchModel',parentScope.patchModel);
                                    $scope.restoreModelFromPatch(optionName);
                                    if (angular.isUndefinedOrNull($scope.model[optionName])) {
                                        var optionKey = {};
                                        optionKey[optionName + "-practiceArea"] = "ALL";
                                        $scope.model[optionName] = [optionKey];
                                    }
                                } else {
                                    var optionKey = {};
                                    optionKey[optionName + "-practiceArea"] = "ALL";
                                    $scope.model[optionName] = [optionKey];
                                }
                            } else {
                                var uncheckArray = [optionName];
                                $scope.updateModelByCriteria(uncheckArray);
                            }
                            return true;
                        }

                        var othersSelected = $scope.options.data.KRAcriteria[optionName];
                        //console.log('othersSelected: ', othersSelected);

                        //localStorage.setItem('selectedKRA-' + $scope.options.key, angular.toJson(optionName));
                        if (isChecked) {
                            angular.forEach(othersSelected, function (value) {
                                if ($filter('filter')($scope.to.options, {"name": value}, true).length) {
                                    if (angular.isUndefined($scope.model[$scope.options.key])) {
                                        $scope.model[$scope.options.key] = {};
                                    }

                                    var arrFilter = $filter('filter')($scope.to.options, {"name": value}, true)[0];
                                    /* Removing Disable checkbox functionality due to inconsistency in PATCH 
                                     * if (!addParams.modeRequestId) {
                                     arrFilter.disable = true;
                                     }*/
                                    //$scope.model[$scope.options.key][arrFilter.name] = true;
                                    if (arrFilter.name != optionName) {
                                        $scope.model[$scope.options.key][arrFilter.name] = true;
                                    }
                                    angular.extend($scope.model, $scope.model[$scope.options.key]);
                                }
                            });

                            if (addParams.modeRequestId && parentScope.patchModel) {
                                //console.log('parentScope.patchModel',parentScope.patchModel);
                                $scope.restoreModelFromPatch(optionName);
                            } else if ($scope.appName == "keyRatingsApplications") {
                                $scope.restoreRGAccessesForKRA(optionName);
                            }

                        } else {
                            /* Removing Disable checkbox functionality due to inconsistency in PATCH
                             * angular.forEach($scope.model[$scope.options.key], function (element, key) {
                             if (!angular.equals(key, optionName)) {
                             var arrFilter = $filter('filter')($scope.to.options, {"name": key}, true);
                             if (arrFilter.length) {
                             arrFilter[0].disable = false;
                             }
                             }
                             })
                             angular.forEach($scope.to.options, function (value) {
                             if (!angular.equals(value.name, optionName)) {
                             value.disable = false;
                             }
                             })*/

                            var uncheckArray = $scope.uncheckCategoriesByCriteria(optionName, isChecked);
                            angular.forEach(uncheckArray, function (uncheckOption) {
                                if (uncheckOption != optionName) {
                                    $scope.model[$scope.options.key][uncheckOption] = false;
                                }
                            });
                            $scope.updateModelByCriteria(uncheckArray);
                        }
                        angular.forEach($scope.model[$scope.options.key], function (element, key) {
                            delete $scope.model[key];
                        });
                    }

                    $scope.uncheckCategoriesByCriteria = function (optionName, isChecked) {
                        if (isChecked == true || !$scope.options.data.KRAcriteria) {
                            return;
                        }

                        var optionsUnchecked = [optionName];
                        //var optionsUnchecked = [];
                        var kraCriteria = $scope.options.data.KRAcriteria;
                        for (var criteriaKey in kraCriteria) {
                            var criteriaArr = kraCriteria[criteriaKey];
                            //console.log('criteriaArr',criteriaArr);
                            if (criteriaArr.indexOf(optionName) != -1) {
                                optionsUnchecked.push(criteriaKey);
                            }
                        }
                        return optionsUnchecked;
                    };

                    $scope.updateModelByCriteria = function (optionsUnchecked) {
                        if (!$scope.options.data.modelScopeKeys) {
                            return;
                        }

                        //var excludeResetKeys = ['wfmRGAccess','rpmRGAccess','rdrRGAccess','rampOnlineRGAccess'];
                        optionsUnchecked.forEach(function (option) {
                            var modelScopeKeys = $scope.options.data.modelScopeKeys[option];
                            //console.log('modelScopeKeys',modelScopeKeys);
                            for (var key in modelScopeKeys) {
                                var modelKey = modelScopeKeys[key];
                                // exclude some keys from resetting to null in KRA
                                /*if ($scope.appName == "keyRatingsApplications") {
                                 if (excludeResetKeys.indexOf(modelKey)==-1 && $scope.model[modelKey]) {
                                 $scope.model[modelKey] = null;
                                 }
                                 } else {*/
                                //console.log('Resetting...',modelKey);
                                if ($scope.model[modelKey]) {
                                    //delete $scope.model[modelKey];
                                    $scope.model[modelKey] = null;
                                }
                                //}
                            }
                        });
                    };

                    $scope.restoreRGAccessesForKRA = function (optionName) {
                        if (!$scope.options.data.modelScopeKeys) {
                            return;
                        }

                        var restoreKeysArray = [];
                        var RGAccessKeys = ['wfmRGAccess', 'rpmRGAccess', 'rdrRGAccess', 'rampOnlineRGAccess'];
                        if ($scope.options.data.KRAcriteria && $scope.options.data.KRAcriteria[optionName]) {
                            var selectedKraCategories = $scope.options.data.KRAcriteria[optionName];
                            if (selectedKraCategories.indexOf(optionName) == -1) {
                                selectedKraCategories.unshift(optionName);
                            }
                        } else {
                            var selectedKraCategories = [optionName];
                        }

                        selectedKraCategories.forEach(function (category) {
                            restoreKeysArray = restoreKeysArray.concat($scope.options.data.modelScopeKeys[category]);
                        });
                        //console.log('restoreKeysArray',restoreKeysArray);

                        restoreKeysArray.forEach(function (restoreKey) {
                            // exclude some keys from restoring from patch model in KRA
                            if (RGAccessKeys.indexOf(restoreKey) != -1) {
                                $scope.model[restoreKey] = true;
                            }
                        });
                    };

                    $scope.restoreModelFromPatch = function (optionName) {
                        if (!$scope.options.data.modelScopeKeys) {
                            return;
                        }

                        var restoreKeysFromPatchArray = [];
                        var excludeRestoreKeys = ['wfmRGAccess', 'rpmRGAccess', 'rdrRGAccess', 'rampOnlineRGAccess'];
                        if ($scope.options.data.KRAcriteria && $scope.options.data.KRAcriteria[optionName]) {
                            var selectedKraCategories = $scope.options.data.KRAcriteria[optionName];
                            if (selectedKraCategories.indexOf(optionName) == -1) {
                                selectedKraCategories.unshift(optionName);
                            }
                        } else {
                            var selectedKraCategories = [optionName];
                        }

                        selectedKraCategories.forEach(function (category) {
                            restoreKeysFromPatchArray = restoreKeysFromPatchArray.concat($scope.options.data.modelScopeKeys[category]);
                        });
                        //console.log('restoreKeysFromPatchArray',restoreKeysFromPatchArray);

                        restoreKeysFromPatchArray.forEach(function (restorePatchKey) {
                            // exclude some keys from restoring from patch model in KRA
                            if ($scope.appName == "keyRatingsApplications") {
                                if (excludeRestoreKeys.indexOf(restorePatchKey) != -1) {
                                    $scope.model[restorePatchKey] = true;
                                } else if (parentScope.patchModel[restorePatchKey]) {
                                    $scope.model[restorePatchKey] = parentScope.patchModel[restorePatchKey];
                                }
                            } else {
                                if (parentScope.patchModel[restorePatchKey]) {
                                    //console.log('Restoring...',restorePatchKey);
                                    $scope.model[restorePatchKey] = parentScope.patchModel[restorePatchKey];
                                }
                            }

                        });
                    };
                }

            });

            formConfig.setType({
                name: 'customdate',
                overwriteOk: true,
                templateUrl: FORM_TEMPLATE.customdate,
                controller: function ($scope) {
                    var currentDate = new Date();
                    $scope.minNominationDate = new Date(
                            currentDate.getFullYear(),
                            currentDate.getMonth(),
                            currentDate.getDate()
                            );
                    $scope.endDatePatch = false;
                    if (addParams.modeRequestId) {
                        $scope.model[$scope.options.key] = new Date(parentScope.patchModel[$scope.options.key]);
                        $scope.endDatePatch = true;
                    }

                }

            });

            formConfig.setType({
                name: 'treedropdownselect',
                overwriteOk: true,
                templateUrl: FORM_TEMPLATE.treedropdownselect,
                controller: function ($scope, $rootScope) {
                    $scope.formOptions = {formState: $scope.formState};

                    $scope.copyFields = function (fields) {
                        fields = angular.copy(fields);
                        FormUtilityService.addRandomIds(fields, unique);
                        return fields;
                    };
                    $scope.addNew = function () {
                        FormScopeService.addNew($scope);
                    };
                    //Check the duplicate entry in this type
                    $scope.showDuplicate = function () {
                        $scope.to.accessDuplicate = false;

                        if (angular.isDefined($scope.model[$scope.options.key])) {
                            var arrOldObj = [];
                            var foundDuplicate = false;
                            var keepGoing = true;
                            var modelValue = angular.copy($scope.model[$scope.options.key]);
                            angular.forEach(modelValue, function (accessElement) {
                                if (keepGoing) {
                                    delete accessElement['value'];
                                    angular.forEach(accessElement, function (innerElement, innerKey) {
                                        if (!angular.equals(accessElement[innerKey], "")) {
                                            delete innerElement[0]['isExpanded'];
                                            delete innerElement[0]['isActive'];
                                            delete innerElement[0]['selected'];
                                        }
                                    })
                                    if (Object.keys(arrOldObj).length) {
                                        var keepGoingNext = true;
                                        angular.forEach(arrOldObj, function (oldAccessElement) {
                                            if (keepGoingNext) {
                                                if (angular.equals(oldAccessElement, accessElement)) {
                                                    foundDuplicate = true;
                                                    keepGoing = false;
                                                    keepGoingNext = false;
                                                    $rootScope.requiredCheck = true;
                                                    $scope.to.accessDuplicate = true;
                                                } else {
                                                    var arrCheckAll = [];
                                                    angular.forEach(accessElement, function (access, key) {
                                                        if (!angular.equals(access, ""))
                                                            arrCheckAll[key] = true;
                                                    })
                                                    if (Object.keys(accessElement).length != Object.keys(arrCheckAll).length) {
                                                        $rootScope.requiredCheck = true;
                                                    } else {
                                                        //if (!angular.equals(addParams.application, "analyticalRoles")) {
                                                        $rootScope.requiredCheck = false;
                                                        //}
                                                    }

                                                    $scope.to.accessDuplicate = false;
                                                }
                                            }

                                        })
                                    } else {
                                        if (Object.keys(accessElement).length) {
                                            $rootScope.requiredCheck = false;
                                        }
                                    }
                                    arrOldObj.push(accessElement);
                                }

                            })
                            return foundDuplicate;
                        }

                    }

                    $scope.$watch("model", function (newValue, oldValue) {
                        //if(newValue[newValue.length-1].value==''){
                        $scope.showDuplicate();
                        //}

                    }, true);


                }
            })


            formConfig.setType({
                name: 'hiddentext',
                overwriteOk: true,
                templateUrl: FORM_TEMPLATE.hiddentext,
                controller: function ($scope, referenceDataFactory) {
                    parentScope.formLoading = false;
                    if ($scope.options.data.refData) {
                        parentScope.formLoading = true;
                        referenceDataFactory.getData(addParams, $scope.options.data.refData)
                                .then(function (response) {
                                    var resData = response.data.plain();
                                    var arrLabel = [];
                                    angular.forEach(resData.children, function (element) {
                                        arrLabel.push(element.attributes.label);
                                    })
                                    var str = "";
                                    angular.forEach(arrLabel, function (value) {
                                        str += value + ", ";
                                    })
                                    var mergedLabel = str.substring(0, str.length - 2);
                                    $scope.options.templateOptions.label = mergedLabel;
                                    $scope.model[$scope.options.key] = mergedLabel;


                                }).finally(function () {
                            parentScope.formLoading = false;
                            deferred.resolve(true);
                        });
                    }
                }
            });

            formConfig.setType({
                name: 'customradio',
                overwriteOk: true,
                extends: 'radio',
                controller: function ($scope, referenceDataFactory) {
                    if ($scope.options.data.modelScopeKeys) {
                        var modelScopeKeys = $scope.options.data.modelScopeKeys;
                        $scope.$watch("model." + $scope.options.key, function (newValue, oldValue) {
                            if (newValue === oldValue) {
                                return;
                            }
                            angular.forEach(modelScopeKeys, function (modelKey) {
                                if (angular.isDefined($scope.model[modelKey])) {
                                    //console.log(modelKey, $scope.model[modelKey]);
                                    delete $scope.model[modelKey];
                                }
                            });
                        });
                    }

                    if ($scope.options.data.refData) {
                        parentScope.formLoading = true;
                        referenceDataFactory.getData(addParams, $scope.options.data.refData)
                                .then(function (response) {
                                    var resData = response.data.plain();
                                    if ($scope.options.data.showSelectedFromApi) {
                                        if (!$scope.model[$scope.options.key]) {
                                            $scope.model[$scope.options.key] = FormScopeService.processReferenceData(resData.children)[0].name.toLowerCase();
                                        }

                                    } else {
                                        $scope.to.options = FormScopeService.processReferenceData(resData.children);
                                        localStorage.setItem('customradioLabel-' + $scope.options.key, angular.toJson($scope.to.options));
                                        if (!addParams.modeRequestId && !$scope.model[$scope.options.key] && $scope.options.data.showFirstChecked && $scope.to.options[0]) {
                                            $scope.model[$scope.options.key] = $scope.to.options[0].name;
                                        }
                                    }
                                    FormScopeService.addTooltip($scope, $scope.to.options);

                                }).finally(function () {
                            parentScope.formLoading = false;
                            deferred.resolve(true);
                        });
                    }

                }
            });

            formConfig.setType({
                name: 'customaddtextbox',
                overwriteOk: true,
                templateUrl: FORM_TEMPLATE.customaddtextbox,
                controller: function ($scope, $rootScope) {
                    $scope.formOptions = {formState: $scope.formState};

                    $scope.copyFields = function (fields) {
                        if (angular.isDefined(fields[0].fieldGroup[0].templateOptions.maxlength)) {
                            $scope.maxlength = fields[0].fieldGroup[0].templateOptions.maxlength;
                        }
                        fields = angular.copy(fields);
                        FormUtilityService.addRandomIds(fields, unique);
                        return fields;
                    };
                    $scope.addNew = function () {
                        FormScopeService.addNew($scope);
                    };


                    //Check the duplicate entry in this type
                    $scope.showDuplicate = function (newValue) {
                        $scope.to.accessDuplicate = false;
                        //Check the textbox for empty
                        var checkUndefined = true;
                        if (angular.isArray(newValue[$scope.options.key]) && !angular.equals(newValue[$scope.options.key][0], {})) {
                            checkUndefined = false;
                        }

                        //if (angular.isDefined($scope.model[$scope.options.key]) && !checkUndefined) {
                        if (!angular.isUndefinedOrNull($scope.model[$scope.options.key]) && !checkUndefined) {

                            var arrOldObj = [];
                            var keepGoing = true;
                            var modelValue = angular.copy($scope.model[$scope.options.key]);
                            angular.forEach(modelValue, function (accessElement) {
                                if (keepGoing) {
                                    delete accessElement['value'];
                                    if (arrOldObj.length) {
                                        var keepGoingNext = true;
                                        angular.forEach(arrOldObj, function (oldAccessElement) {
                                            if (keepGoingNext) {
                                                if (angular.equals(oldAccessElement, accessElement)) {
                                                    keepGoing = false;
                                                    keepGoingNext = false;
                                                    $rootScope.requiredCheck = true;
                                                    $scope.to.accessDuplicate = true;
                                                } else {
                                                    var arrCheckAll = [];
                                                    angular.forEach(accessElement, function (access, key) {
                                                        if (!angular.equals(access, ""))
                                                            arrCheckAll[key] = true;
                                                    })
                                                    if (Object.keys(accessElement).length != Object.keys(arrCheckAll).length) {
                                                        $rootScope.requiredCheck = true;
                                                    } else {
                                                        $rootScope.requiredCheck = false;
                                                    }

                                                    $scope.to.accessDuplicate = false;
                                                }
                                            }

                                        })
                                    } else {
                                        if (Object.keys(accessElement).length) {
                                            $rootScope.requiredCheck = false;
                                        }
                                    }
                                    arrOldObj.push(accessElement);
                                }

                            })

                        }

                    }

                    $scope.$watch("model", function (newValue, oldValue) {
                        $scope.showDuplicate(newValue);
                        //$rootScope.validateRequired();
                        //parentScope.validateRequired();
                    }, true);


                }
            })

            return deferred.promise;
        };

        return formFactory;
    });



//The common factory to get the referenceData from API
    formsModule.factory('referenceDataFactory', function (RefRestangular, $http, $q) {
        return {
            getData: getData
        };
        function getData(params, refData, requestedAccess) {
            var deferred = $q.defer();

            var requestedAccessMetaData = angular.isDefined(requestedAccess) ? requestedAccess : {};
            var objReference = {
                "subjectName": params.userId,
                "attributeName": refData,
                "environmentVariables": {
//                    "returnAll": "Y", //only if you want all returned.
                    "requestedAccess": requestedAccessMetaData
                }
            }

            var refData = RefRestangular.all("").withHttpConfig({cache: true}).post(objReference);
            deferred.resolve(refData);
            return deferred.promise;
        }

    });

});
