define(['app', 'angularAMD'], function (app, FormsModule) {

    FormsModule.controller('FormsController', 
		function ($scope, FormsService) {
                    
        
                   
        });
});