define(['app','angularAMD'], function (app, loginModule) {

    loginModule.controller('LoginController', 
        function ($scope, $rootScope, $state, AuthService, AUTH_EVENTS) {
			
	  $scope.credentials = {
		username: '',
		password: ''
	  };
	  
	  $scope.login = function (credentials) {
		if(AuthService.login(credentials)) {
			$rootScope.$broadcast(AUTH_EVENTS.loginSuccess);
		}else {
		  $rootScope.$broadcast(AUTH_EVENTS.loginFailed);
		}
	  };
	  
	});

});

