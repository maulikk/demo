define(['app'], function (app)
{
	app.factory('AuthService', function ($http, StorageService, APP_PATH, STORAGE_TYPES, UI_ROLES, _currentUser, _uiServer, $rootScope, Restangular, RefRestangular, $state, AccessRestangular) {
	  
	  var authService = {};
	  var Session = {};
	  Session = StorageService.getData('CurrentUser', STORAGE_TYPES.session, "");
	  
    // login function Not used as it does not have custom login page
	  authService.login = function (credentials) {
		  
			/* No Manual Login Screen, HARDCODED for Dev, testing Purpose, TO BE REMOVED LATER */
			if(credentials.username === 'aurionpro' && credentials.password === 'password'){
			
				var User = {
							userId : "aurionpro",
							firstName : "John",
							lastName : "Smith",
							userUIRole : "admin"
						};
						
				StorageService.putData('CurrentUser', User, STORAGE_TYPES.session, "");
				
				Session = StorageService.getData('CurrentUser', STORAGE_TYPES.session, "");
				//console.log('Login Session',Session);
						
				//authCheck.Setup(Session);
						
				return true;
			}
		  
	  };
	 
	  authService.isAuthenticated = function () {
		 return !!_currentUser.userId;
	  };
	 
	  authService.isAuthorized = function (authorizedRoles) {
		  
		if (!angular.isArray(authorizedRoles)) {
		
			var arrAuthorizedRoles = [];
			for (roleValue in authorizedRoles) {
			   arrAuthorizedRoles.push(authorizedRoles[roleValue]);
			}
			authorizedRoles = arrAuthorizedRoles;
		}
		
		if(UI_ROLES.superadmin==Session.userUIRole){
			/* SUPERADMIN All ACCESS */
			return true;
		}else{
			return (authService.isAuthenticated() && authorizedRoles.indexOf(Session.userUIRole) !== -1);
		}
	  };
    
      // Get API user fields and create generic for application
      authService.getUserObject = function (apiUserObject) {
		  
		var userObject = {
                        userId : apiUserObject.id,
                        firstName : apiUserObject.name.givenName,
                        lastName : apiUserObject.name.familyName,
                        displayName : apiUserObject.displayName,
                        alternatePolicyRole : apiUserObject.alternatePolicyRole,
                        defaultPolicyRole : apiUserObject.defaultPolicyRole
                    }
        
        return userObject;
		 
	  };
	  
        // Set global object of logged in user for entire application
	  authService.setCurrentUser = function (Session) {
		  
		_currentUser.userId = Session.userId;
		_currentUser.firstName = Session.firstName;
		_currentUser.lastName = Session.lastName;
		_currentUser.displayName = Session.displayName;
		//_currentUser.userUIRole = Session.uiRole; // DO NOT uncomment, not required
		_currentUser.userGroups = Session.userGroups;
		_currentUser.alternatePolicyRole = Session.alternatePolicyRole;
		_currentUser.defaultPolicyRole = Session.defaultPolicyRole;
		 
	  };
	  
	  authService.setPolicyRoles = function (Session) {
		  
		/* Get global Enterprise Policy List */
		$rootScope.policyRoles = [];
                var objPolicy = {
                            "subjectName": Session.userId,
                            "attributeName": "snp.refData.policyrole.data",
                            "environmentVariables": {
                                //"returnAll": "Y", //only if you want all returned.
                                "requestedAccess": {
                                }
                            }
                        }
		var policyRolesObj = RefRestangular.all("");
		policyRolesObj.withHttpConfig({cache: true}).post(objPolicy).then(function (res) { 
			angular.forEach(res.data.children, function (policyRole, roleIndex) {
				$rootScope.policyRoles[policyRole.name] = policyRole.attributes.label;
			});
		}, function (response) {
			console.log("Error with status code", response.status);
		});
		 
	  };
        
        authService.Route =  function(Session) {
            
            if(!angular.isUndefined(Session)){
                    if (Session.userId) {
                        
                        /* If no tasks in inbox load new request wizard */
                        var taskRequests = Restangular.all('tasks');
                        taskRequests.getList().then(function(task) {
                            var tasksResponse = task.data.plain();

                            if(tasksResponse.length==0){
                                $state.go('request.beneficiary');
                            }
                        });
                    }

                } 
        };
        
        // Get UI resurce access permissions and set in global resource variable like reports, manage user links
        authService.setEntitlements = function(Session) {
            
            /* Get User's UI entitlements - Start */
            var entitledUIAccess = AccessRestangular.one("getSubjectEntitlements").withHttpConfig({ cache: true });

            /* Post JSON object */
            var entitlement = {
              "subjectName": Session.userId,
              "applicationName": "ARP",
              "filter": "UI",
              "environmentVariables": {
                "noActionMode": "true"
              }
            };

            entitledUIAccess.post("", entitlement).then(function(resp) {

               var entitlementAccessData = resp.data.plain();
               var resourceArray = [];
               var fullResource,resource;

               angular.forEach(entitlementAccessData, function (UIAccess, entlIndex) {

                fullResource = UIAccess.resource;
                resource = fullResource.replace('UI/',"");
                resourceArray[resource] = true;

               });

               // Set resource Access
                _currentUser.resource = resourceArray;

             }, function() {
                console.log("There was an error!");
             });
             /* Get User's UI entitlements - End */
        };
        
        // Get UI properties like logout URL from API
        authService.setUiProperties = function(Session) {

            /* Post JSON object */
            var uiPostObject = {
              "subjectName": Session.userId,
              "attributeName": "snp.refData.uiProperties.data",
              "environmentVariables": {
                "returnAll":"Y"
              }
            };
            
            var apiResult = RefRestangular.all("").post(uiPostObject);

            apiResult.then(function(uiResp) {

                var uiPropertiesResponse = uiResp.data.plain();
                var uiPropertiesData = uiPropertiesResponse.children;
                var uiServerProperties = [];
                
                angular.forEach(uiPropertiesData, function(uiProperty, propertyIndex) {
                    uiServerProperties[uiProperty.name] = uiProperty.attributes;
                });
               
                // Set UI Properties
                _uiServer.properties = uiServerProperties;

             }, function() {
                console.log("There was an error!");
             });

        };
	
	  return authService;
	});
	
	/* SERVICE: AuthCheck */
	app.service('AuthCheck', 
		function ($http,  $rootScope, $location, $state, $window, StorageService, APP_PATH, STORAGE_TYPES, AUTH_EVENTS, _currentUser, _uiServer, AuthService,Restangular,$cacheFactory) 
		{
			var authCheck = {};
			this.SSOUser = function () {
				
				var User = {};
					
                /* User undefined, fetch SSO ID */
                var hostname = $location.host();
                if(hostname=='localhost'){
                    var currentUser = $http.get('config/loginData.json');
                }else{
                    var currentUser = Restangular.one('me').get();
                }

                currentUser.then(function(res) {

                    User = AuthService.getUserObject(res.data);

                    StorageService.putData('CurrentUser', User, STORAGE_TYPES.session, "");

                    authCheck.Setup(User);

                }, function(response) {
                    console.log("Error with status code", response.status);
                    if(response.status=='403'){
                        // 
                    }
                });

                /* Clear all cached API calls */
                $rootScope.$on('$stateChangeSuccess',
                function(event, toState, toParams, fromState, fromParams) {
                  $cacheFactory.get('$http').removeAll();
                });
                
			},
			authCheck.Setup =  function(Session) {
					
					if(!angular.isUndefined(Session)){
						
						if (Session.userId) {
							
                            /* Set Global currentUser Object */
                            AuthService.setCurrentUser(Session);
                            AuthService.setPolicyRoles(Session);
                            AuthService.setEntitlements(Session);
                            AuthService.setUiProperties(Session);
                        
						}
					} 
			},
			this.Access =  function(Session) {
				
				/* Set Global currentUser Object */
				authCheck.Setup(Session);
				
				$rootScope.$on('$stateChangeStart', function (event, next) {
					/* NOT REQUIRED - Authorization done from getEntitlements API 
                    if(!angular.isUndefined(next.data)){
						var authorizedRoles = next.data.authorizedRoles;
						
						if (!AuthService.isAuthorized(authorizedRoles)) {
						  event.preventDefault();
						  if (AuthService.isAuthenticated()) {
							// user is not allowed
							$rootScope.$emit(AUTH_EVENTS.notAuthorized);
						  } else {
							// user is not logged in
							$rootScope.$broadcast(AUTH_EVENTS.notAuthenticated);
						  }
						}
					} // if(!angular.isUndefined(next.data)) */
						
					if (next.external) {
						event.preventDefault();
						$window.open(next.url, '_self');
					}
				});
			}
			
		});
	
});
