define(['app', 'angularAMD'], function (app, ReportsModule) {

    ReportsModule.controller('ReportsController', 
		function ($scope, $rootScope, $filter, $sce, $state, ReportsService,_currentUser,SCROLLBAR_DIV_HEIGHT) {
    		
			/* Get in scope */
			$scope._currentUser = _currentUser;
			
			ReportsService.getReportDetails(_currentUser.userId)
				.then(function(resp) {
					$scope.reportList = resp;
                    angular.keySort($scope.reportList,'name',false);
					//console.log("reportList: ",$scope.reportList);
				});
			
    		$scope.reportUrl = "";
    		
    		// Sample format of report API JSON
    		/*$scope.reportList = [{
	    			"label" : "Report 1",
	    			"name" : "Applications Access List",
	    			"reportURL" : "http://www.aurionpro.com"
	    		}
	    	];*/
			
			$scope.setReportUrl = function () {
	    		var value = this.selectedReport;
                
                // Check the sepected report from drop down and get reportURL from JSON API to load in iframe
	    		if ($filter('filter')($scope.reportList, {name: value}, true).length) {
	    			$scope.reportUrl = $filter('filter')($scope.reportList, {name: value}, true)[0].reportURL;
	    			$scope.reportUrl = $sce.trustAsResourceUrl($scope.reportUrl);
                }
	    		//console.log('$scope.reportUrl', $scope.reportUrl);
	    		$('#reports-iframe').attr('src',$scope.reportUrl);
	    	};
	    	
	    	// Resize window height on viewport change
            function resizePage() {
                var page_height = $(window).height() - SCROLLBAR_DIV_HEIGHT.OFFSET_INNER_PAGES;
                //console.log('page_height',page_height);
                $('.inner-page.reports .content-panel .content-panel-body').height(page_height);
            }
            setTimeout(function () {
                resizePage();
            }, 500);
            $(window).resize(resizePage);
            
        });
});
