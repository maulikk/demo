define(['app','angularAMD'], function(app, ReportsModule){
    
	ReportsModule.service('ReportsService', 
		function($q,Restangular,RefRestangular,EXCLUDE){
		
            var service = {};
        
            // Get Report details like URL, name & label from API
            service.getReportDetails = function (user) {
                
                var deferred = $q.defer();
            	var reportList = [];
				
            	var objReports = {
                        "subjectName": user,
                        "attributeName": "snp.refData.reports.attribute.data",
                        "environmentVariables": {
                            "requestedAccess": {
                            }
                        }
                    };
                
                var reportPromise = RefRestangular.all("").post(objReports);
            	reportPromise.then(
                    function (res) {
                        
                        var reportData = res.data.plain().children;
                        
                        angular.forEach(reportData, function(singleReportData){
                            //console.log(singleReportData.attributes);
                            if(singleReportData.attributes.name){
                                reportList.push(singleReportData.attributes);    
                            }
                            
                        });
                        
                        deferred.resolve(reportList);

                    }, function (response) {
                        console.log("Error with status code", response.status);
                    });
                
                return deferred.promise;
            };
			
            return service;
        });
});
