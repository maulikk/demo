define(['app'], function (app){
    app.controller('NavigationController', function ($scope, $rootScope, $state, StorageService, AuthService, $element, _currentUser) {
        $scope.$state = $state;
        
        $element.class = "navigation-folded";
        $scope.class = "notfolded";
        $rootScope.navMenuState = $scope.class;
        $rootScope.changeClass = changeClass;
        $scope.currentUser = _currentUser;
        
        $scope.reloadInbox = function () {
        	$state.go('inbox.list', {}, {reload: true});
        };
        
        $scope.reloadNewRequest = function () {
        	sessionStorage['clearUserAccessDetails'] = true;
        	if($rootScope.currentState!='request.beneficiary'){
                $state.go('request.beneficiary', {}, {reload: true});
            }
        };
        
        //Function for sidebar navigation fold and unfold
        function changeClass(event,forceTo) {
        	//console.log('event',event);
        	//console.log('currentNavStatus',$scope.class);
        	//console.log('forceTo',forceTo);
        	
        	if (angular.isDefined(forceTo)) {
        		$scope.class = forceTo;
        	} else {
        		if ($scope.class == "notfolded") {
                    $scope.class = "folded";
                } else {
                    $scope.class = "notfolded";
                }
        	}
        	
            if ($scope.class == "folded") {
            	document.getElementById('apps').classList.add('navigation-folded'); //add
                //$(event.target).addClass("navigation-folded");
            } else {
            	document.getElementById('apps').classList.remove('navigation-folded');
                //$(event.target).removeClass("navigation-folded");
            }
            
            if (event && event.type=='click') {
        		localStorage['selfCollapsibleClass'] = $scope.class;
        	}
            $rootScope.navMenuState = $scope.class;
        };
        
    });

});
