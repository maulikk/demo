define(['app'], function (app){
    
    app.controller('HeaderController', function ($scope, $rootScope,$state, StorageService,AuthService) {
        var vm = this;
        $scope.vm={};
        $scope.vm.layoutMode = 'boxed';        
        $scope.updateLayoutMode = updateLayoutMode;
        
        function updateLayoutMode(event) {
            //console.log("this.vm.layoutMode",this.vm.layoutMode);
            if (this.vm.layoutMode === 'boxed') {
                $rootScope.layoutArea = 'boxed';
                document.getElementById('apps').classList.add('boxed'); //add
            } else {
                $rootScope.layoutArea = 'wide';
                document.getElementById('apps').classList.remove('boxed'); //add
            }
        };

    }); //App Controller

}); //Define

