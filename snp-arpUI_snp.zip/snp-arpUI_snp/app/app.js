define(function (require) {

    'use strict';

    /* ANGULAR */
    var angular = require('angular');
    var uiRouter = require('uiRouter');
    var angularAMD = require('angularAMD');
    var ngcookies = require('ngCookies');
    var ngresource = require('ngResource');
    var ngaria = require('ngAria');
    var nganimate = require('ngAnimate');
    var ngmaterial = require('ngMaterial');
    var ngMessages = require('ngMessages');
    var ngSanitize = require('ngSanitize');
    var ngStorage = require('ngStorage');

    /* PLUGINS */
    var ocLazyLoad = require('ocLazyLoad');
    var multiselect = require('multiSelect');
    var DualMultiSelect = require('DualMultiSelect');
    var Formly = require('Formly');
    var formlyMaterial = require('formlyMaterial');
    var nsPopover = require('nsPopover');
    var angularStrap = require('angularStrap');
    var dirPagination = require('dirPagination');
    var restangular = require('restangular');
    //var mCustomScrollbar = require('mCustomScrollbar');
    var ngScrollbar = require('ngScrollbar');
    var checklist = require('checklist');
    var tooltips = require('tooltips');
    var istevenMultiselect = require('istevenMultiselect');
    /* **** APPLICATION MODULES **** */
    var loginModule = angular.module('LoginModule', [
        'multi-select-tree','formlyMaterial', 'ngAria', 'ngAnimate', 'ngMaterial', 'ui.router', 'oc.lazyLoad', 'ngCookies', 'ngResource','ngSanitize','nsPopover',
        'mgcrea.ngStrap','mgcrea.ngStrap.tooltip','mgcrea.ngStrap.popover','angularUtils.directives.dirPagination','ngScrollbars','DualMultiSelect',
        'checklist-model','720kb.tooltips','isteven-multi-select','ngMessages'
    ]);
    var inboxModule = angular.module('InboxModule', [
        'restangular'
    ]);
    var requestsModule = angular.module('RequestsModule', [
    ]);
    var accessModule = angular.module('AccessModule', [
    ]);
    var briefcaseModule = angular.module('BriefcaseModule', [
    ]);
    var formsModule = angular.module('FormsModule', [
    ]);
	var certificationModule = angular.module('CertificationModule', [
    ]);
    var userModule = angular.module('UserModule', ['ngCookies'
    ]);
    var reportsModule = angular.module('ReportsModule', [
    ]);
    var demoModule = angular.module('DemoModule', [
    ]);
    /* **** APPLICATION MODULES - ENDS **** */

    /* **** APP **** */
    var app = angular.module('app', [
        'LoginModule',
        'InboxModule',
        'RequestsModule',
        'AccessModule',
        'BriefcaseModule',
        'FormsModule',
        'CertificationModule',
        'UserModule',
        'ReportsModule'
    ]);

    /* **** APP CONFIG **** */
    app.config(['$stateProvider', '$urlRouterProvider',
        '$locationProvider',
        '$controllerProvider',
        '$compileProvider',
        '$filterProvider',
        '$provide',
        '$ocLazyLoadProvider',
	    'ARPStatesProvider',
		'RestangularProvider',
		'$httpProvider',
        function ($stateProvider, $urlRouterProvider,
                $locationProvider,
                $controllerProvider,
                $compileProvider,
                $filterProvider,
                $provide,
                $ocLazyLoadProvider,
                ARPStatesProvider,
                RestangularProvider,
				$httpProvider) {

            app.controller = $controllerProvider.register;
            app.directive = $compileProvider.directive;
            app.filter = $filterProvider.register;
            app.factory = $provide.factory;
            app.service = $provide.service;
			
            $locationProvider.html5Mode(false);
				
            /* Iterate States */
            var appStates = ARPStatesProvider.getStates();
            if (appStates.states !== undefined) {
                angular.forEach(appStates.states, function (stateConfig, name) {
                    $stateProvider.state(name, stateConfig);
                });
                $urlRouterProvider.otherwise(appStates.defaultState);
            }
			
            /* OcLazyLoad Config. */
            $ocLazyLoadProvider.config({
                //debug: true //$ocLazyLoad returns a promise that will be rejected when there is an error but if you set debug to true, $ocLazyLoad will also log all errors to the console
                //events: true //$ocLazyLoad can broadcast an event when you load a module, a component or a file (js/css/template). It is disabled by default, set events to true to activate it.
                //The events are ocLazyLoad.moduleLoaded, ocLazyLoad.moduleReloaded, ocLazyLoad.componentLoaded, ocLazyLoad.fileLoaded.
                //Example :
                //$scope.$on('ocLazyLoad.moduleLoaded', function(e, module) {
                //console.log('module loaded', module);
                //});
                asyncLoader: require
            });
			
			/* Restangular Configuration - Starts */
			var apiBaseUrl = "/midas/v1";
			RestangularProvider.setBaseUrl(apiBaseUrl);
			RestangularProvider.setFullResponse(true);
			
			RestangularProvider.addResponseInterceptor(function(data, operation, what, url, response, deferred) {
			  var extractedData;
			  if (operation === "getList" || operation === "get" || operation === "post") {
				
				if(url.indexOf('AccessControlService') > -1){
					extractedData = data.entitlements;
				}else{
					extractedData = (data && data.data) ? data.data : null;
				}
				
			  } else {
				extractedData = data;
			  }
			  return extractedData;
			});
			/* Restangular Configuration - Ends */
			
			$httpProvider.interceptors.push('APIInterceptor');
			
        }]);
    
    
    var runApp = function (app,objLoggedInUser) {
        
        /* **** APP RUN **** */
        app.run(['$rootScope', '$cacheFactory', '$templateCache', '$state', 'AuthCheck', 'AuthService', 'APP_PATH', 'StorageService','STORAGE_TYPES','Restangular','$location','$timeout',
            function ($rootScope, $cacheFactory, $templateCache, $state, AuthCheck, AuthService, APP_PATH, StorageService,STORAGE_TYPES,Restangular,$location,$timeout)
            {
                /* Load PATH constants */
                $rootScope.path = APP_PATH;
                
                // # SET FROM INIT FUNCTION after first /me API promise # //
                var userObject = AuthService.getUserObject(objLoggedInUser);
                
                if(!angular.isUndefined(userObject.userId)){
                    StorageService.putData('CurrentUser', userObject, STORAGE_TYPES.session, "");
                }

                var hostPath = $location.host();

                /* API Header */
                if(hostPath!='localhost'){
                    Restangular.setDefaultHeaders({
                        'Content-Type': "application/json; charset=UTF-8",
                        'Accept': 'application/json'
                    });
                }

                var Session = {};
                Session = StorageService.getData('CurrentUser', STORAGE_TYPES.session, "");

                /* Main Authentication Check */
                if(angular.isUndefined(Session)){
                    /* Get SSO User */
                    AuthCheck.SSOUser();
                }else{
                    /* Check Access for View State */
                    AuthCheck.Access(Session);
                }

                /* Check for query string and change the state */
                var routeQuery = $location.search();
                var redirectTo = routeQuery.ref;

                if(!angular.isUndefined(redirectTo)){
                    $location.url(redirectTo);
                }

                /* API localhost Header */
                if(hostPath=='localhost'){
                    $timeout(function() {
                        var Session = {};
                        Session = StorageService.getData('CurrentUser', STORAGE_TYPES.session, "");
                        Restangular.setDefaultHeaders({
                            'Content-Type': "application/json",
                            'OAM_REMOTE_USER': Session.userId
                        });
                    }, 100);
                }

                /* Clear the cache on ng-view content changes */
                $rootScope.$on('$viewContentLoaded', function() {
                  $templateCache.removeAll();
                });

                $rootScope.$on('$stateChangeSuccess', function(ev, to, toParams, from, fromParams) {
                    $rootScope.previousState = from.name;
                    $rootScope.currentState = to.name;
                });

        }]); // app.run ENDS
        
    } // EO runApp()

    /* **** APP INIT **** */
    app.init = function () {
        
        var $http = angular.injector(["ng"]).get("$http");
        
        var hostName = window.location.hostname;
        
        // Provision to have user on local environment from local json
        if(hostName=='localhost'){
            var signedUser = $http.get('config/loginData.json');
        }else{
            var signedUser = $http.get("/midas/v1/me");
        }
        
        return signedUser.then(
            function (resp) {
                var objLoggedInUser = resp.data.data;
                runApp(app,objLoggedInUser);
                angularAMD.bootstrap(app);
                
            }
        );
    };

    return app;
});