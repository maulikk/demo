require.config({
    paths: {
        'angular': '../assets/js/angular-1.4.8/angular.min',
        'uiRouter': '../assets/js/ui-router/angular-ui-router.min',
        'angularAMD': '../assets/js/angularAMD.min',
        'ngResource': '../assets/js/angular-1.4.8/angular-resource',
        'ngCookies': '../assets/js/angular-1.4.8/angular-cookies',
        'ngRoute': '../assets/js/angular-1.4.8/angular-route',
        'ngTouch': '../assets/js/angular-1.4.8/angular-touch',
        'ngAnimate': '../assets/js/angular-1.4.8/angular-animate.min',
        'ngMessages': '../assets/js/angular-1.4.8/angular-messages',
        'ngAria': '../assets/js/angular-1.4.8/angular-aria.min',
        'Jquery': '../assets/js/jquery-2.1.4.min',
        'ngMaterial': '../assets/js/angular-material',
        'bootStrap': '../assets/js/bootstrap.min',
        'ngSanitize': '../assets/js/angular-1.4.8/angular-sanitize',
        'ngStorage': '../assets/js/ngStorage',
        'treeControl': '../assets/plugins/angular-ui-tree/angular-ui-tree.min',
        'smartTable': '../assets/plugins/angular-smart-table/dist/smart-table.min',
        'ocLazyLoad': '../assets/js/ocLazyLoad',
        'multiSelect': '../assets/plugins/multiselect/angular-multi-select-tree-0.1.0',
        'DualMultiSelect': '../assets/plugins/angular-dual-multi-select/angular-dual-multi-select',
        'api-check': '../assets/plugins/mdformly/api-check',
        'Formly': '../assets/plugins/mdformly/formly',
        'formlyMaterial': '../assets/plugins/mdformly/formly-material.min',
        'nsPopover': '../assets/js/nsPopover',
        'angularStrap': '../assets/plugins/angular-strap.min',
        'dirPagination': '../assets/plugins/dirPagination',
        'underscore': '../assets/js/underscore-min',
        'restangular': '../assets/js/restangular',
        'mCustomScrollbar': '../assets/plugins/ng-scrollbars/jquery.mCustomScrollbar.concat.min',
        'ngScrollbar': '../assets/plugins/ng-scrollbars/scrollbars.min',
        'checklist': '../assets/plugins/checklist-model',
        "tooltips":'../assets/plugins/angular-tooltips/angular-tooltips',
        'istevenMultiselect':'../assets/plugins/angular-multi-select/isteven-multi-select',
    },
    shim: {
        'angularAMD': ['angular'],
        'angular-route': ['angular'],
        'smartTable': ['angular'],
        'angular-ui-select': ['angular'],
        istevenMultiselect:{
            deps: ['angular']
        },
        restangular: {
            deps: ['angular', 'underscore'],
            exports: 'restangular'
        },
        ngResource: {
            deps: ['angular']
        },
        ngCookies: {
            deps: ['angular']
        },
        ngTouch: {
            deps: ['angular']
        },
        ngAnimate: {
            deps: ['angular']
        },
        ngMessages: {
            deps: ['angular']
        },
        ngAria: {
            deps: ['angular']
        },
        ngMaterial: {
            deps: ['angular']
        },
        ngSanitize: {
            deps: ['angular']
        },
        treeControl: {
            deps: ['angular']
        },
        uiRouter: {
            deps: ['angular']
        },
        ocLazyLoad: {
            deps: ['angular']
        },
        multiSelect: {
            deps: ['angular']
        },
        DualMultiSelect: {
            deps: ['angular']
        },
        Formly: {
            exports: 'Formly',
            deps: ['angular', 'api-check']
        },
        nsPopover: {
            deps: ['angular']
        },
        formlyMaterial: {
            deps: ['angular', 'Formly']
        },
        dirPagination: {
            deps: ['angular']
        },
        angularStrap: {
            deps: ['angular']
        },
        mCustomScrollbar: {
            deps: ['Jquery']
        },
        ngScrollbar: {
            deps: ['angular', 'mCustomScrollbar']
        },
        checklist: {
            deps: ['angular']
        },
        tooltips:{
            deps: ['angular']
        },
        angular: {
            deps: ['Jquery'],
            exports: 'angular'
        }
    },
    waitSeconds: 0

});

require([
    'app',
    'lib/appServices',
    'lib/appShared',
    'lib/storageService',
    'components/auth/authService',
    'lib/appController',
    'states'
], function (app) {
    angular.element().ready(function () {
        app.init();
    });

});
