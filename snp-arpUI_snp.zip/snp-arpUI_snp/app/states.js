define(['app', 'angularAMD'], function (app, angularAMD) {

    app.provider('ARPStates', function (UI_ROLES) {
        return {
            getStates: function () {
                return {
                    defaultState: '/request/new/access',
                    states: {
                        'signin': {
                            external: true
                        },
                        /* PROHIBITED ACCESS */
                        'forbad': {
                            url: '/forbad',
                            views: {
                                'main': angularAMD.route({
                                    templateUrl: 'app/view/login/forbad.html',
                                })
                            }
                        },
                        'layout': {
                            abstract: true,
                            views: {
                                'header': angularAMD.route({
                                    templateUrl: 'app/view/shared/header.html',
                                    controller: 'HeaderController',
                                    controllerUrl: 'components/shared/headerController'
                                }),
                                'main': angularAMD.route({
                                    templateUrl: 'app/view/shared/main.html'
                                })
                            }
                        },
                        'base': {
                            parent: 'layout',
                            views: {
                                'navigation': angularAMD.route({
                                    templateUrl: 'app/view/shared/navigation.html',
                                    controller: 'NavigationController',
                                    controllerUrl: 'components/shared/navigationController'
                                }),
                                'content': angularAMD.route({
                                    template: '<div ui-view="content" layout="row" flex></div>'
                                })
                            }
                        },
                        /* INBOX */
                        'home': {
                            parent: 'base',
                            views: {
                                'content': angularAMD.route({
                                    templateUrl: 'app/view/inbox/home.html'
                                })
                            },
                            resolve: {
                                inbox: ['$ocLazyLoad', function ($ocLazyLoad) {
                                        return $ocLazyLoad.load({
                                            name: 'InboxModule',
                                            files: ['components/inbox/inboxController', 'components/inbox/inboxService']
                                        });
                                    }]
                            },
                            data: {
                                authorizedRoles: [UI_ROLES.admin, UI_ROLES.editor]
                            }
                        },
                        'inbox': {
                            parent: 'home',
                            views: {
                                'inboxcontent': angularAMD.route({
                                    templateUrl: 'app/view/inbox/inbox.html'
                                })
                            }
                        },
                        'inbox.list': {
                            url: '/inbox',
                            views: {
                            	'inboxdetails': angularAMD.route({
                                    templateUrl: 'app/view/inbox/inbox.list.html'
                                }),
                                'inboxtoolbar@inbox.list': angularAMD.route({
                                    templateUrl: 'app/view/inbox/inbox.toolbar.html'
                                }),
                                'requestcontent@inbox.list': angularAMD.route({
                                    templateUrl: 'app/view/inbox/inbox.list.requests.html',	//earlier inbox.request.content.html
                                    controller: 'DiscussionController',
                                    controllerUrl: 'components/requests/requestsController'
                                })
                            },
                            resolve: {
                                requestdetails: ['$ocLazyLoad', function ($ocLazyLoad) {
                                        return $ocLazyLoad.load({
                                            name: 'InboxModule',
                                            files: ['components/requests/requestsService', 'components/user/userService']
                                        });
                                    }]
                            },
                            params: {
                                alertType: null
                            }
                        },
                        'inbox.request': {	//earlier inbox.list.request
                            url: '/request/:requestId',
                            views: {
                            	'inboxdetails': angularAMD.route({
                                    templateUrl: 'app/view/requests/request.details.html'
                                }),
                            	'inboxtoolbar@inbox.request': angularAMD.route({
                                    templateUrl: 'app/view/requests/request.details.header.html'
                                }),
                            	'currentaccess@inbox.request': angularAMD.route({
                                    templateUrl: 'app/view/access/access.current.html'
                                })
                            },
                            resolve: {
                                requestdetails: ['$ocLazyLoad', function ($ocLazyLoad) {
                                        return $ocLazyLoad.load({
                                            name: 'RequestsModule',
                                            files: ['components/requests/requestsController', 'components/requests/requestsService', 'components/access/accessController', 'components/access/accessService', 'components/user/userService']
                                        });
                                    }]
                            }
                        },
                        'inbox.request#discussionquestion': {
                            url: '/request/:requestId#discussionquestion'
                        },
                        'inbox.action': {	//earlier inbox.list.action
                            url: '/action',
                            views: {
                            	'inboxdetails': angularAMD.route({
                                    templateUrl: 'app/view/inbox/inbox.list.action.html',
                                    controller: 'DiscussionController',
                                    controllerUrl: 'components/requests/requestsController'
                                }),
                            	'inboxtoolbar@inbox.action': angularAMD.route({
                                    templateUrl: 'app/view/inbox/inbox.action.header.html'
                                })
                            }
                        },
                        /*'inbox.certification': {
                            url: '/certification',
                            views: {
                                'list@inbox': angularAMD.route({
                                    templateUrl: 'app/view/inbox/inbox.details.certification.html'
                                })
                            }
                        },*/
                        /* REQUEST */
                        'request': {
                            parent: 'base',
                            url: '/request',
                            views: {
                                'content': angularAMD.route({
                                    templateUrl: 'app/view/requests/request.html'
                                })
                            },
                            resolve: {
                                requests: ['$ocLazyLoad', function ($ocLazyLoad) {
                                        return $ocLazyLoad.load({
                                            name: 'RequestsModule',
                                            files: ['components/requests/newRequestController', 'components/requests/newRequestService','components/forms/formsService','components/briefcase/briefcaseService','components/access/accessService']
                                        });
                                    }]
                            },
                            data: {
                                authorizedRoles: [UI_ROLES.editor]
                            }
                        },
                        'request.beneficiary': {
                            url: '/new/beneficiary',
                            views: {
                                'beneficiary': angularAMD.route({
                                    templateUrl: 'app/view/requests/request.beneficiary.html'
                                }),
                                'userprofile@request.beneficiary': angularAMD.route({
                                    templateUrl: 'app/view/requests/request.user.profile.html'
                                })
                            }
                        },
                        'request.access': {
                            url: '/new/access',
                            views: {
                                'access': angularAMD.route({
                                    templateUrl: 'app/view/requests/request.access.html'
                                }),
                                'userprofile@request.access': angularAMD.route({
                                    templateUrl: 'app/view/requests/request.user.profile.html'
                                })
                            }
                        },
                        'request.optapplications': {
                            url: '/new/optapplications',
                            views: {
                                'optapplications': angularAMD.route({
                                    templateUrl: 'app/view/requests/request.optional.applications.html'
                                })
                            }
                        },
                        'request.optfunctions': {
                            url: '/new/optfunctions',
                            views: {
                                'optfunctions': angularAMD.route({
                                    templateUrl: 'app/view/requests/request.optional.functions.html'
                                })
                            },
                            resolve: {
                                forms: ['$ocLazyLoad', function ($ocLazyLoad) {
                                        return $ocLazyLoad.load({
                                            name: 'RequestsModule',
                                            files: ['components/forms/formsController', 'components/forms/formsService']
                                        });
                                    }]
                            }
                        },
                        'request.summary': {
                            url: '/new/summary',
                            views: {
                                'summary': angularAMD.route({
                                    templateUrl: 'app/view/requests/request.summary.html'
                                })
                            }
                        },
                        /* ACCESS */
                        'access': {
                            parent: 'base',
                            url: '/access',
                            views: {
                                'content': angularAMD.route({
                                    templateUrl: 'app/view/access/access.html'
                                })
                            },
                            resolve: {
                                access: ['$ocLazyLoad', function ($ocLazyLoad) {
                                        return $ocLazyLoad.load({
                                            name: 'AccessModule',
                                            files: ['components/access/accessController', 'components/access/accessService', 'components/requests/requestsService']
                                        });
                                    }]
                            }
                        },
                        'access.current': {
                            url: '/current',
                            views: {
                                'current': angularAMD.route({
                                    templateUrl: 'app/view/access/access.current.html'
                                })
                            }
                        },
                        'access.history': {
                            url: '/history',
                            views: {
                                'history': angularAMD.route({
                                    templateUrl: 'app/view/access/access.history.html'
                                })
                            }
                        },
                        /* User Access */
                        'access.user': {
                            parent: 'base',
                            url: '/access/user',
                            views: {
                                'content': angularAMD.route({
                                    templateUrl: 'app/view/access/user.access.html'
                                })/*,
                                'managecontent@access.user': angularAMD.route({
                                    templateUrl: 'app/view/user/manageaccess.html'
                                })*/
                            },
                            resolve: {
                            	access: ['$ocLazyLoad', function ($ocLazyLoad) {
                                        return $ocLazyLoad.load({
                                            name: 'AccessModule',
                                            files: ['components/access/accessController', 'components/access/accessService', 'components/requests/requestsService']
                                        });
                                    }]
                            }
                        },
                        /* BRIEFCASE */
                        'briefcase': {
                            parent: 'base',
                            url: '/briefcase',
                            views: {
                                'content': angularAMD.route({
                                    templateUrl: 'app/view/briefcase/briefcase.html'
                                }),
                                'briefcaselist@briefcase': angularAMD.route({
                                    templateUrl: 'app/view/briefcase/briefcaselist.html'
                                })
                            },
                            resolve: {
                                briefcase: ['$ocLazyLoad', function ($ocLazyLoad) {
                                        return $ocLazyLoad.load({
                                            name: 'RequestsModule',
                                            files: ['components/briefcase/briefcaseController', 'components/briefcase/briefcaseService']
                                        });
                                    }]
                            }
                        },
                        /* CERTIFICATION */
                        'certification': {
                            parent: 'base',
                            url: '/certification',
                            views: {
                                'content': angularAMD.route({
                                    templateUrl: 'app/view/certification/certification.html'
                                })
                            },
                            resolve: {
                                certification: ['$ocLazyLoad', function ($ocLazyLoad) {
                                        return $ocLazyLoad.load({
                                            name: 'CertificationModule',
                                            files: ['components/certification/certificationController', 'components/certification/certificationService']
                                        });
                                    }]
                            }
                        },
                        /* REPORTS */
                        'reports': {
                            parent: 'base',
                            url: '/reports',
                            views: {
                                'content': angularAMD.route({
                                    templateUrl: 'app/view/reports/reports.html'
                                })
                            },
                            resolve: {
                                reports: ['$ocLazyLoad', function ($ocLazyLoad) {
                                        return $ocLazyLoad.load({
                                            //cache: false,//The parameter cache: false works for all native loaders (all requests are cached by default by the browser).
                                            //timeout: 5000, // If you use it, the loaders will append a timestamp to the url in order to bypass the browser cache.
                                            //serie: true, //By default the native loaders will load your files in parallel. If you need to load your files in serie, you can use this.
                                            name: 'ReportsModule',
                                            files: ['components/reports/reportsController', 'components/reports/reportsService']
                                        });
                                    }]
                            }
                        },
						/* USER PROFILE */
                        'profile': {
                            parent: 'base',
                            url: '/profile',
                            views: {
                                'content': angularAMD.route({
                                    templateUrl: 'app/view/user/user.html'
                                }),
                                'userprofile@profile': angularAMD.route({
                                    templateUrl: 'app/view/user/user.profile.html'
                                })
                            },
                            resolve: {
                                reports: ['$ocLazyLoad', function ($ocLazyLoad) {
                                        return $ocLazyLoad.load({
                                            name: 'UserModule',
                                            files: ['components/user/userController','components/user/userService']
                                        });
                                    }]
                            }
                        }
                    }
                } // return getStates()
            },
            $get: function () {
                return {}
            }
        }

    });

});
