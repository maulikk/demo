/*jshint indent: 2 *//*global angular: false */
(function () {
    'use strict';
    angular.module('multi-select-tree', []);
}());
(function () {
    'use strict';
    var mainModule = angular.module('multi-select-tree');
    /**
     * Controller for multi select tree.
     */
    mainModule.controller('multiSelectTreeCtrl', [
        '$scope',
        '$document',
        function ($scope, $document) {
            var activeItem;
            $scope.showTree = false;
            $scope.selectedItems = [];
            $scope.multiSelect = $scope.multiSelect || false;
            //$scope.level = true;
            /**
             * Clicking on document will hide the tree.
             */
            function docClickHide() {
                closePopup();
                $scope.$apply();
            }
            /**
             * Closes the tree popup.
             */
            function closePopup() {
                $scope.showTree = false;
                if (activeItem) {
                    activeItem.isActive = false;
                    activeItem = undefined;
                }
                $document.off('click', docClickHide);
            }
            /**
             * Sets the active item.
             *
             * @param item the item element.
             */
            $scope.onActiveItem = function (item) {
                if (activeItem !== item) {
                    if (activeItem) {
                        activeItem.isActive = false;
                    }
                    activeItem = item;
                    activeItem.isActive = true;
                }
            };

            /**
             * Copies the selectedItems in to output model.
             */
            $scope.refreshOutputModel = function () {
                $scope.outputModel = angular.copy($scope.selectedItems);
            };
            /**
             * Refreshes the selected Items model.
             */
            $scope.refreshSelectedItems = function () {
                if (angular.isDefined($scope.outputModel) && angular.isArray($scope.outputModel)) {
                    $scope.selectedItems = [];
                    $scope.selectedItems = angular.copy($scope.outputModel);
                    if ($scope.inputModel) {
                        setSelectedChildren($scope.inputModel);
                    }
                } else {
                    $scope.selectedItems = [];
                    if ($scope.inputModel) {
                        setSelectedChildren($scope.inputModel);
                    }
                }

            };
            /**
             * Iterates over children and sets the selected items.
             *
             * @param children the children element.
             */
            function setSelectedChildren(children) {
                for (var i = 0, len = children.length; i < len; i++) {
                    if (!isItemSelected(children[i]) && children[i].selected === true) {
                        //$scope.selectedItems.push(children[i]);
                        //} else if (isItemSelected(children[i]) && children[i].selected === false && angular.isUndefined(children[i].selected)) {
                    } else if (isItemSelected(children[i]) && children[i].selected === undefined) {
                        children[i].selected = true;
                    }
                    if (children[i] && children[i].children) {
                        setSelectedChildren(children[i].children);
                    }

                }
            }
            /**
             * Checks of the item is already selected.
             *
             * @param item the item to be checked.
             * @return {boolean} if the item is already selected.
             */
            function isItemSelected(item) {
                var isSelected = false;
                if ($scope.selectedItems) {
                    for (var i = 0; i < $scope.selectedItems.length; i++) {
                        if ($scope.selectedItems[i].name === item.name) {
                            isSelected = true;
                            break;
                        }
                    }
                }
                return isSelected;
            }
            /**
             * Deselect the item.
             *
             * @param item the item element
             * @param $event
             */
            $scope.deselectItem = function (item, $event) {
                $event.stopPropagation();
                $scope.selectedItems.splice($scope.selectedItems.indexOf(item), 1);
                item.selected = false;
                this.refreshOutputModel();
            };
            /**
             * Swap the tree popup on control click event.
             *
             * @param $event the click event.
             */
            $scope.onControlClicked = function ($event) {
                $event.stopPropagation();
                //console.log("$scope.showDisable",$scope.showDisable);
                if ($scope.showDisable) {
                    $scope.showTree = !$scope.showDisable;
                } else {
                    $scope.showTree = !$scope.showTree;
                }
                if ($scope.showTree) {
                    $document.on('click', docClickHide);
                }
            };
            /**
             * Stop the event on filter clicked.
             *
             * @param $event the click event
             */
            $scope.onFilterClicked = function ($event) {
                $event.stopPropagation();
            };
            /**
             * Clears the filter text.
             *
             * @param $event the click event
             */
            $scope.clearFilter = function ($event) {
                $event.stopPropagation();
                $scope.filterKeyword = '';
            };
            /**
             * Wrapper function for can select item callback.
             *
             * @param item the item
             */
            $scope.canSelectItem = function (item) {
                return $scope.callback({
                    item: item,
                    selectedItems: $scope.selectedItems
                });
            };
            /**
             * The callback is used to switch the views.
             * based on the view type.
             *
             * @param $event the event object.
             */
            $scope.switchCurrentView = function ($event) {
                $event.stopPropagation();
                $scope.switchViewCallback({scopeObj: $scope});
            };
            /**
             * Handles the item select event.
             *
             * @param item the selected item.
             */
            $scope.itemSelected = function (item) {


                if ($scope.useCallback && $scope.canSelectItem(item) === false || $scope.selectOnlyLeafs && item.children && item.children.length > 0) {
                    return;
                }

                if (!$scope.multiSelect) {

                    closePopup();
                    for (var i = 0; i < $scope.selectedItems.length; i++) {
                        $scope.selectedItems[i].selected = false;
                    }
                    item.selected = true;
                    $scope.selectedItems = [];
                    $scope.selectedItems.push(item);
                } else {
                    //console.log($scope.inputModel.);
                    item.selected = true;                    
                    var indexOfItem = $scope.selectedItems.indexOf(item);                   
                    if (isItemSelected(item)) {
                        $scope.unmarkSelected(item);
                        item.selected = false;
                        $scope.selectedItems.splice(indexOfItem, 1);
                    } else {
                        $scope.markSelected(item);
                        $scope.selectedItems.push(item);
                    }
                }
                this.refreshOutputModel();
            };

            $scope.markSelected = function (item) {
                if (!angular.isUndefinedOrNull(item.children) && item.children.length) {
                    angular.forEach(item.children, function (innerchilditem) {
                        if (innerchilditem.children.length) {
                            innerchilditem.selected = true;
                            //console.log(innerchilditem.children);
                            $scope.markSelected(innerchilditem.children);
                            //innerchilditem.children[0].selected = true;
                        } else {
                            innerchilditem.selected = true;
                        }
                    });

                } else {
                    
                    angular.forEach(item, function (innerchilditem) {
                        if(angular.isObject(innerchilditem)){
                            innerchilditem.selected = true;
                            ///$scope.selectedItems.push(innerchilditem);
                        }else{
                           item.selected = true; 
                           //$scope.selectedItems.push(item);
                        }
                        
                    })

                }

            };

            $scope.unmarkSelected = function (item) {
                if (!angular.isUndefinedOrNull(item.children) && item.children.length) {
                    angular.forEach(item.children, function (innerchilditem) {
                        if (innerchilditem.children.length) {
                            innerchilditem.selected = false;
                            //$scope.selectedItems.splice($scope.selectedItems.indexOf(innerchilditem), 1);
                            //console.log(innerchilditem.children);
                            $scope.unmarkSelected(innerchilditem.children);
                            //innerchilditem.children[0].selected = true;
                        } else {                            
                            //$scope.selectedItems.splice($scope.selectedItems.indexOf(innerchilditem), 1);
                            innerchilditem.selected = false;
                        }
                    });

                } else {
                    
                    angular.forEach(item, function (innerchilditem) {
                        if(angular.isObject(innerchilditem)){                            
                            //$scope.selectedItems.splice($scope.selectedItems.indexOf(innerchilditem), 1);
                            innerchilditem.selected = false;
                        }else{                            
                            //$scope.selectedItems.splice($scope.selectedItems.indexOf(item), 1);
                           item.selected = false; 
                        }
                        
                    })

                }

            };

        }
    ]);
    /**
     * sortableItem directive.
     */
    mainModule.directive('multiSelectTree', function () {
        return {
            restrict: 'E',
            templateUrl: 'assets/plugins/multiselect/templates/multi-select-tree.tpl.html',
            scope: {
                inputModel: '=',
                outputModel: '=?',
                multiSelect: '=?',
                switchView: '=?',
                switchViewLabel: '@',
                switchViewCallback: '&',
                selectOnlyLeafs: '=?',
                callback: '&',
                defaultLabel: '@'
            },
            link: function (scope, element, attrs) {
                if (attrs.callback) {
                    scope.useCallback = true;
                }
                scope.showTree = true;
                // watch for changes in input model as a whole
                // this on updates the multi-select when a user load a whole new input-model.
                scope.$watch('inputModel', function (newVal) {
                    if (newVal) {
                        scope.refreshSelectedItems();
                        scope.refreshOutputModel();
                    }
                });
                /**
                 * Checks whether any of children match the keyword.
                 *
                 * @param item the parent item
                 * @param keyword the filter keyword
                 * @returns {boolean} false if matches.
                 */
                function isChildrenFiltered(item, keyword) {
                    var childNodes = getAllChildNodesFromNode(item, []);
                    //if (angular.isUndefined(childNodes)) {
                    for (var i = 0, len = childNodes.length; i < len; i++) {
                        if (childNodes[i].name.toLowerCase().indexOf(keyword.toLowerCase()) !== -1) {
                            return false;
                        }
                    }
                    //}
                    return true;
                }
                /**
                 * Return all childNodes of a given node (as Array of Nodes)
                 */
                function getAllChildNodesFromNode(node, childNodes) {
                    if (!angular.isUndefinedOrNull(node.children)) {
                        for (var i = 0; i < node.children.length; i++) {
                            childNodes.push(node.children[i]);
                            // add the childNodes from the children if available
                            getAllChildNodesFromNode(node.children[i], childNodes);
                        }
                    }
                    return childNodes;

                }
                scope.$watch('filterKeyword', function () {
                    if (scope.filterKeyword !== undefined) {
                        angular.forEach(scope.inputModel, function (item) {
                            if (item.attributes.label.toLowerCase().indexOf(scope.filterKeyword.toLowerCase()) !== -1) {
                                item.isFiltered = false;
                            }
                            else if (!isChildrenFiltered(item, scope.filterKeyword)) {
                                item.isFiltered = false;
                            }
                            else {
                                item.isFiltered = true;
                            }
                        });
                    }
                });
            },
            controller: 'multiSelectTreeCtrl'
        };
    });
    mainModule.directive('multiSelectTreeDropdown', function () {
        return {
            restrict: 'E',
            templateUrl: 'assets/plugins/multiselect/templates/multi-select-tree-dropdown.tpl.html',
            scope: {
                inputModel: '=',
                outputModel: '=?',
                multiSelect: '=?',
                switchView: '=?',
                switchViewLabel: '@',
                switchViewCallback: '&',
                selectOnlyLeafs: '=?',
                callback: '&',
                defaultLabel: '=',
                showDisable: '=?'
            },
            link: function (scope, element, attrs) {
                if (attrs.callback) {
                    scope.useCallback = true;
                }
                //console.log(scope.showDisable);
                scope.showTree = false;
                // watch for changes in input model as a whole
                // this on updates the multi-select when a user load a whole new input-model.
                scope.$watch('inputModel', function (newVal) {
                    if (newVal) {
                        scope.refreshSelectedItems();
//                        scope.refreshOutputModel();
                    }
                });
                /**
                 * Checks whether any of children match the keyword.
                 *
                 * @param item the parent item
                 * @param keyword the filter keyword
                 * @returns {boolean} false if matches.
                 */
                function isChildrenFiltered(item, keyword) {
                    var childNodes = getAllChildNodesFromNode(item, []);
                    //if (angular.isUndefined(childNodes)) {
                    for (var i = 0, len = childNodes.length; i < len; i++) {
                        if (childNodes[i].name.toLowerCase().indexOf(keyword.toLowerCase()) !== -1) {
                            return false;
                        }
                    }
                    //}
                    return true;
                }
                /**
                 * Return all childNodes of a given node (as Array of Nodes)
                 */
                function getAllChildNodesFromNode(node, childNodes) {
                    if (!angular.isUndefinedOrNull(node.children)) {
                        for (var i = 0; i < node.children.length; i++) {
                            childNodes.push(node.children[i]);
                            // add the childNodes from the children if available
                            getAllChildNodesFromNode(node.children[i], childNodes);
                        }
                    }
                    return childNodes;

                }
                scope.$watch('filterKeyword', function () {
                    if (scope.filterKeyword !== undefined) {
                        angular.forEach(scope.inputModel, function (item) {
                            if (item.name.toLowerCase().indexOf(scope.filterKeyword.toLowerCase()) !== -1) {
                                item.isFiltered = false;
                            }
                            else if (!isChildrenFiltered(item, scope.filterKeyword)) {
                                item.isFiltered = false;
                            }
                            else {
                                item.isFiltered = true;
                            }
                        });
                    }
                });
            },
            controller: 'multiSelectTreeCtrl'
        };
    });
}());
/*jshint indent: 2 */
/*global angular: false */
(function () {
    'use strict';
    var mainModule = angular.module('multi-select-tree');
    /**
     * Controller for sortable item.
     *
     * @param $scope - drag item scope
     */
    mainModule.controller('treeItemCtrl', [
        '$scope','$filter',
        function ($scope,$filter) {
            $scope.item.isExpanded = false;
            /**
             * Shows the expand option.
             *
             * @param item the item
             * @returns {*|boolean}
             */
            $scope.showExpand = function (item) {
                if(!angular.isUndefinedOrNull(item.children)){
                    var filter = $filter('filter')(item.children, {"selected":true}, true);
                    if(filter.length){
                        item.isExpanded = true;
                        //return true;
                    }
                }
                
               
                return item.children && item.children.length > 0;
            };
            /**
             * On expand clicked toggle the option.
             *
             * @param item the item
             * @param $event
             */
            $scope.onExpandClicked = function (item, $event) {
                $event.stopPropagation();                
                item.isExpanded = !item.isExpanded;
            };
            /**
             * Event on click of select item.
             *
             * @param item the item
             * @param $event
             */
            $scope.clickSelectItem = function (item, $event) {

                $event.stopPropagation();
                if ($scope.itemSelected) {
                    $scope.itemSelected({item: item});
                }
            };
            /**
             * Is leaf selected.
             *
             * @param item the item
             * @param $event
             */
            $scope.subItemSelected = function (item, $event) {
                if ($scope.itemSelected) {
                    $scope.itemSelected({item: item});
                }
            };
            /**
             * Active sub item.
             *
             * @param item the item
             * @param $event
             */
            $scope.activeSubItem = function (item, $event) {
                if ($scope.onActiveItem) {
                    $scope.onActiveItem({item: item});
                }
            };
            /**
             * On mouse over event.
             *
             * @param item the item
             * @param $event
             */
            $scope.onMouseOver = function (item, $event) {
                $event.stopPropagation();
                if ($scope.onActiveItem) {
                    $scope.onActiveItem({item: item});
                }
            };
            /**
             * Can select item.
             *
             * @returns {*}
             */
            
            $scope.showCheckbox = function () {
                 if (!$scope.multiSelect) {
          return false;
        }
        if ($scope.useCallback) {
          return $scope.canSelectItem($scope.item);
        }
        return true;
//                if (!$scope.multiSelect) {
//                    return false;
//                }
//                if ($scope.selectOnlyLeafs) {
//                    return false;
//                }
//                if ($scope.useCallback) {
//                    //return $scope.canSelectItem($scope.item);
//                    return true;
//                }
            };
        }
    ]);
    /**
     * sortableItem directive.
     */
    mainModule.directive('treeItem', [
        '$compile',
        function ($compile) {
            return {
                restrict: 'E',
                templateUrl: 'assets/plugins/multiselect/templates/tree-item.tpl.html',
                scope: {
                    item: '=',
                    itemSelected: '&',
                    onActiveItem: '&',
                    multiSelect: '=?',
                    selectOnlyLeafs: '=?',
                    isActive: '=',
                    useCallback: '=',
                    canSelectItem: '='
                },
                controller: 'treeItemCtrl',
                compile: function (element, attrs, link) {
                    // Normalize the link parameter
                    if (angular.isFunction(link)) {
                        link = {post: link};
                    }
                    // Break the recursion loop by removing the contents
                    var contents = element.contents().remove();
                    var compiledContents;
                    return {
                        pre: link && link.pre ? link.pre : null,
                        post: function (scope, element, attrs) {
                            // Compile the contents
                            if (!compiledContents) {
                                compiledContents = $compile(contents);
                            }
                            // Re-add the compiled contents to the element
                            compiledContents(scope, function (clone) {
                                element.append(clone);
                            });
                            // Call the post-linking function, if any
                            if (link && link.post) {
                                link.post.apply(null, arguments);
                            }
                        }
                    };
                }
            };
        }
    ]);


    /**
     * sortableItem directive.
     */
    mainModule.directive('treeItemDropdown', [
        '$compile',
        function ($compile) {
            return {
                restrict: 'E',
                templateUrl: 'assets/plugins/multiselect/templates/tree-item-dropdown.tpl.html',
                scope: {
                    item: '=',
                    itemSelected: '&',
                    onActiveItem: '&',
                    multiSelect: '=?',
                    selectOnlyLeafs: '=?',
                    isActive: '=',
                    useCallback: '=',
                    canSelectItem: '='
                },
                controller: 'treeItemCtrl',
                compile: function (element, attrs, link) {
                    // Normalize the link parameter
                    if (angular.isFunction(link)) {
                        link = {post: link};
                    }
                    // Break the recursion loop by removing the contents
                    var contents = element.contents().remove();
                    var compiledContents;
                    return {
                        pre: link && link.pre ? link.pre : null,
                        post: function (scope, element, attrs) {
                            // Compile the contents
                            if (!compiledContents) {
                                compiledContents = $compile(contents);
                            }
                            // Re-add the compiled contents to the element
                            compiledContents(scope, function (clone) {
                                element.append(clone);
                            });
                            // Call the post-linking function, if any
                            if (link && link.post) {
                                link.post.apply(null, arguments);
                            }
                        }
                    };
                }
            };
        }
    ]);
}());